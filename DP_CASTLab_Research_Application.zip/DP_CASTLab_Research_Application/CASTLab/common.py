"""Shared validation and result helpers. No data leaves the local application."""
import os,json,hashlib,math,io,csv,re,uuid,platform,importlib.metadata
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
META=json.loads((ROOT/'app.json').read_text())
WORK=Path(os.environ.get('RESEARCH_APP_WORKSPACE',str(ROOT/'workspace'))).resolve()

def now():return datetime.now(timezone.utc).isoformat()
def clean(v):
 if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [clean(x) for x in v]
 if isinstance(v,np.ndarray):return clean(v.tolist())
 if isinstance(v,np.generic):return clean(v.item())
 if isinstance(v,float) and not math.isfinite(v):return None
 if isinstance(v,Path):return str(v)
 return v
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.tmp')
 tmp.write_text(json.dumps(clean(v),indent=2,allow_nan=False),encoding='utf-8');tmp.replace(p)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(clean(v),sort_keys=True,separators=(',',':')).encode()).hexdigest()
def ident(value):
 if not re.fullmatch('[a-f0-9]{12}',str(value)):raise ValueError('Invalid workspace identifier.')
 return str(value)
def environment():return {'python':platform.python_version(),'platform':platform.platform(),'packages':{p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','matplotlib','threadpoolctl']}}
def csv_frame(text):
 if len(text.encode('utf-8'))>50*1024*1024:raise ValueError('Please use a CSV or TSV of at most 50 MB.')
 sep='\t' if '\t' in text.splitlines()[0] else ','
 headers=next(csv.reader(io.StringIO(text),delimiter=sep))
 headers=[c.strip() for c in headers]
 if len(headers)!=len(set(headers)) or any(not c for c in headers):raise ValueError('Column names must be unique and nonempty.')
 if any(len(c)>160 for c in headers):raise ValueError('Column names must be at most 160 characters.')
 frame=pd.read_csv(io.StringIO(text),sep=sep,na_values=['?','--','NA','N/A',''],low_memory=False)
 frame.columns=headers
 if not 40<=len(frame)<=300000 or not 2<=len(headers)<=150:raise ValueError('Use 40–300,000 records and 2–150 columns, including the target.')
 return frame
def profile(frame,filename):
 cols=[]
 for c in frame:
  s=frame[c];numeric=pd.to_numeric(s,errors='coerce');finite=numeric[np.isfinite(numeric)]
  isnum=numeric.notna().sum()==s.notna().sum()
  vals=s.dropna().astype(str).str.strip().unique()
  cols.append(dict(name=c,kind='numeric' if isnum else 'category',missing=int(s.isna().sum()),unique=int(s.nunique()),values=sorted(vals.tolist()) if len(vals)<=20 else [],low=float(finite.min()) if len(finite) else 0.,high=float(finite.max()) if len(finite) else 1.,suspected_id=bool(re.search(r'(^id$|_id$|name|email|phone|address)',c,re.I))))
 targets=[c for c in ['outcome','target','Biopsy','Diabetes_binary','Grade','hospdead','label'] if c in frame]
 return clean(dict(filename=Path(filename).name,rows=len(frame),columns=cols,missing=int(frame.isna().sum().sum()),duplicates=int(frame.duplicated().sum()),suggested_target=targets[0] if targets else frame.columns[-1],preview=frame.head(8).replace({np.nan:None}).to_dict('records')))

NUMERIC_MAP={'MUTATED':1,'NOT_MUTATED':0,'Male':0,'Female':1}
def age_years(value):
 if pd.isna(value):return np.nan
 text=str(value).strip().lower()
 match=re.fullmatch(r'(\d+(?:\.\d+)?)\s*years?(?:\s+(\d+(?:\.\d+)?)\s*days?)?',text)
 if match:
  days=float(match[2] or 0)
  if days>=366:raise ValueError('Invalid age day remainder: '+text)
  age=float(match[1])+days/365.25
 else:
  try:age=float(text)
  except ValueError as exc:raise ValueError('Unrecognized age: '+text) from exc
 if not math.isfinite(age) or not 0<=age<=120:raise ValueError('Age must be in [0,120] years.')
 return age
def validate_data(frame,schema,clients=8):
 target=schema.get('target');positive=str(schema.get('positive','')).strip()
 if target not in frame:raise ValueError('Choose an outcome column.')
 if frame[target].isna().any():raise ValueError('The outcome has missing values. Correct these before running; no rows are silently removed.')
 labels=frame[target].astype(str).str.strip()
 if labels.nunique()!=2:raise ValueError('Both applications require exactly two outcome classes. Choose a binary outcome.')
 if positive not in set(labels):raise ValueError('Choose the positive outcome label explicitly.')
 features=schema.get('features',[])
 if not features or len({x['name'] for x in features})!=len(features):raise ValueError('Select one or more distinct predictors.')
 if target in [x['name'] for x in features]:raise ValueError('The outcome cannot also be a predictor.')
 if len(frame)<max(100,clients*12):raise ValueError('Use at least max(100, 12 × clients) records for the disjoint research splits.')
 y=(labels==positive).to_numpy(int)
 if min(y.sum(),len(y)-y.sum())<20:raise ValueError('At least 20 records in each outcome class are required. No oversampling or favorable split retries are performed.')
 warnings=[]
 for f in features:
  c=f['name']
  if c not in frame:raise ValueError('A selected predictor is missing: '+c)
  if f['kind'] not in ['numeric','category','age']:raise ValueError('Unknown predictor type.')
  if f['kind'] in ['numeric','age']:
   a=frame[c].map(age_years) if f['kind']=='age' else pd.to_numeric(frame[c].map(lambda x:NUMERIC_MAP.get(x,x)),errors='coerce')
   if (frame[c].notna()&a.isna()).any() or np.isinf(a.to_numpy(float)).any():raise ValueError(c+': contains nonnumeric or infinite values. Change its type or correct the file.')
   lo,hi=float(f['low']),float(f['high'])
   if not math.isfinite(lo+hi) or hi<=lo:raise ValueError(c+': upper bound must be greater than lower bound.')
  if frame[c].nunique(dropna=True)<2:warnings.append(c+': constant or all missing; it carries no discrimination information.')
  if re.search(r'(^id$|_id$|name|email|phone|address)',c,re.I):warnings.append(c+': looks like an identifier. Confirm that it is a valid predictor.')
 if frame.duplicated().sum():warnings.append('Exact duplicate records detected. Acquisition keeps encoded profiles together; sparse feedback removes exact feature-and-label duplicates before splitting.')
 return {'rows':len(frame),'features':len(features),'positive_count':int(y.sum()),'negative_count':int(len(y)-y.sum()),'prevalence':float(y.mean()),'warnings':warnings,'ready':True}

def defaults():
 a=META['engine']=='acquisition'
 return dict(name='My research experiment',methods=['gate_learned','gate_frozen','fixed_dp'] if a else ['proposed','fixed','random'],seeds=[142] if a else [42],rounds=10 if a else 8,clients=8,participation=1.,alpha=.5,epsilon=16. if a else 8.,delta=1e-5,local_lr=.05 if a else .001,local_steps=1 if a else 2,batch_size=256,encoder=[32,16] if a else [12,8],head=16 if a else 4,dropout=.1,focal_alpha=.75 if a else .5,focal_gamma=2. if a else 0.,base_clip=1. if a else .1,context_fraction=.15,clip_fraction=.05,evaluation_fraction=.1 if a else .05,learning_batch=32 if a else 4,pretrain_epochs=2,holdout_seed=842019 if a else 20261117,bootstrap_reps=1000)

def validate_config(c):
 extra=set(c)-set(defaults())
 if extra:raise ValueError('Unknown configuration keys: '+', '.join(sorted(extra)))
 d={**defaults(),**c}
 d['name']=str(d['name']).strip()[:100] or 'Research experiment'
 ranges={'rounds':(10 if META['engine']=='acquisition' else 2,500),'clients':(2,32),'local_steps':(1,20),'batch_size':(8,4096),'head':(1,128),'learning_batch':(2,256),'pretrain_epochs':(1,200),'holdout_seed':(0,2**32-1),'bootstrap_reps':(100,10000)}
 for k,(lo,hi) in ranges.items():
  v=float(d[k])
  if not math.isfinite(v) or int(v)!=v or not lo<=v<=hi:raise ValueError(f'{k}: choose an integer from {lo} to {hi}.')
  d[k]=int(v)
 for k,lo,hi in [('participation',.05,1.),('alpha',.01,100.),('epsilon',.1,1000.),('delta',1e-12,.1),('local_lr',1e-6,1.),('dropout',0.,.8),('focal_alpha',.01,.99),('focal_gamma',0.,5.),('base_clip',.005,2.),('context_fraction',.01,.6),('clip_fraction',.01,.3),('evaluation_fraction',.01,.4)]:
  v=float(d[k])
  if not math.isfinite(v) or not lo<=v<=hi:raise ValueError(f'{k}: use a value between {lo:g} and {hi:g}.')
  d[k]=v
 if META['engine']=='acquisition':
  if d['context_fraction']+d['clip_fraction']>=.9:raise ValueError('Reserve at least 10% of each training slot for gradients and feedback.')
 elif d['context_fraction']+d['clip_fraction']+d['evaluation_fraction']>=.9:raise ValueError('Reserve at least 10% of the budget for training updates.')
 if not isinstance(d['methods'],list) or not d['methods'] or len(set(d['methods']))!=len(d['methods']) or not set(d['methods'])<=set(META['methods']):raise ValueError('Choose distinct methods from the list.')
 if not isinstance(d['seeds'],list) or not 1<=len(d['seeds'])<=20 or len(set(d['seeds']))!=len(d['seeds']):raise ValueError('Choose 1–20 distinct integer seeds.')
 if any(isinstance(x,bool) or not isinstance(x,int) or not 0<=x<2**32 for x in d['seeds']):raise ValueError('Seeds must be integers between 0 and 4,294,967,295.')
 if len(d['encoder'])!=2 or any(not isinstance(x,int) or not 2<=x<=128 for x in d['encoder']):raise ValueError('Use two encoder widths, each between 2 and 128.')
 if len(d['methods'])*len(d['seeds'])>200:raise ValueError('Limit one desktop study to 200 method–seed combinations.')
 return d

def safe_csv(frame,path):
 # Avoid spreadsheet formula interpretation in descriptive text fields.
 out=frame.copy()
 for c in out.select_dtypes(include=['object','string']).columns:
  out[c]=out[c].map(lambda v:"'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v)
 out.to_csv(path,index=False)
