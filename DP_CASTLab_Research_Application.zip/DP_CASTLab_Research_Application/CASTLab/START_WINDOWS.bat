@echo off
cd /d "%~dp0"
py -3.12 --version >nul 2>&1
if %errorlevel% equ 0 (
  py -3.12 launch.py
) else (
  python launch.py
)
pause
