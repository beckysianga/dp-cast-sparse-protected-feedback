# Licensing and attribution

No new license is imposed on the authors' research code or manuscript by
packaging these files. The authors should select a code license before
inviting reuse beyond the applicable default rights. No publication DOI,
repository URL, acceptance status, or author ORCID has been invented.

The bundled, unmodified IEEEtran class retains its original copyright and
LaTeX Project Public License notices. Dataset terms remain those of their
original providers; a code license does not relicense third-party data.
Existing attribution and source links remain in the archived documentation.
