# DP CAST with Sparse Protected Feedback for Adaptive Federated Learning

Reproducibility package for the formatted **six-page** IConAECC manuscript.
Suggested GitHub repository name: `dp-cast-sparse-protected-feedback`.

## Evidence provided

The paper contains two distinct single-seed evidence sets: **four earlier
Cervical development runs** (20 rounds) and **nine revised synthetic
verification runs** (eight rounds). These are not a controlled before-and-after
utility comparison. This is separate from the 560-run acquisition study.

`code/earlier/` and `code/revised/` contain the corresponding implementations,
notebooks, requirements, tests, and documentation. Their six and 15 executable
files respectively match the archived protocol hashes. `configs/` contains
the exact configurations recovered from the reported experiment locks.

`evidence_audit/` preserves the earlier manuscript's complete audit package:
both result archives, executed-source snapshots, saved models/predictions,
ledgers, source hashes, figure-generation code, derived tables, and claim maps.
Its ten-page historical manuscript is retained for provenance; the submission
version is the six-page PDF in `manuscript/compiled/`.

`provenance/` retains the complete original input ZIP files, including original
code validation material. Those broader software-check files and prospective
configurations are not additional research evidence for this manuscript.

Packaging re-ran the original audit: **462 consistency checks**, **21 source
hashes**, and **nine model hashes** passed. No separate large release assets
are required for this repository.

The earlier secret noise root and development-reference prediction arrays
were not exported, so its exact training trajectory cannot be reconstructed
from seed 42 and its reference AP cannot be independently recomputed. The
synthetic export omits raw input arrays but supplies its generator/configuration
and auditable predictions. Numerical versions can affect retraining results.


## Repository contents

`manuscript/` contains the formatted LaTeX paper, bibliography, vector figures,
IEEE template, and the verified PDF. `requirements.txt` records the numerical
versions used for audit validation. `tools/` provides convenient entry points;
`validation/` records checks run when this package was assembled. `CITATION.cff`
contains author metadata. `GITHUB_UPLOAD.md` explains publication.

Install the numerical tools in an isolated environment (Python 3.12 is the
audit environment used during packaging):

```text
python -m venv .venv
```

Activate on Windows PowerShell with `.\.venv\Scripts\Activate.ps1`, or on
macOS/Linux with `source .venv/bin/activate`, then run:

```text
python -m pip install -r requirements.txt
python tools/verify_checksums.py
```

The tests and audits run on CPU. A GPU is not required. LaTeX compilation
separately requires pdfLaTeX/TeX Live (locally verified with TeX Live 2023).

```text
python tools/reproduce.py test
python tools/reproduce.py audit
python tools/reproduce.py paper
```

New outputs go into `reproduced/`, which is excluded from Git. Original evidence
and locked source files remain unchanged. The archived readme/configuration files
retain their historical wording; this top-level README defines the evidence
scope of the present manuscript. No new scientific training study was executed
to assemble this package. Integration tests may run small temporary simulations.

The repositories contain public-benchmark diagnostics. Seeded randomness,
exact labels, scores, and diagnostic archives are outside the papers' ideal
confidential-release boundaries. Passing numerical audits does not certify
privacy, security, external validity, or clinical effectiveness.

Read `REPRODUCIBILITY.md` for the detailed commands and limits.
