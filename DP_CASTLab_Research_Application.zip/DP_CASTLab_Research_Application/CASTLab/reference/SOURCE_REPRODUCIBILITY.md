# Reproducing the sparse-feedback paper

## 1. Audit saved predictions and ledgers

From the repository root, after installing requirements:

```text
python tools/verify_checksums.py
python tools/reproduce.py audit
```

This invokes the unmodified `evidence_audit/audit_evidence.py` on the archived
`evidence_audit/evidence/` directory and writes `reproduced/audit/`. Expected:
462 consistency checks, 21 matching source files, and nine matching model
hashes. Earlier common-reference predictions are absent, so their AP can only
be cross-checked between logs and summaries. All nine synthetic selected/final
prediction files permit metric recomputation. The audit does not train models
or open an unreported test set.

## 2. Run tests, regenerate figures, and compile

```text
python tools/reproduce.py test
python tools/reproduce.py figures
python tools/reproduce.py paper
```

The two original correctness suites contain 19 earlier and 32 revised tests.
Some tests train small temporary synthetic models; they are not added research
experiments. Figure regeneration uses copies of the original scripts/evidence
and writes `reproduced/figures/`. Plot typography or PDF metadata can vary with
Matplotlib. The current manuscript preserves vector crops of the supplied
figures. The paper command compiles twice in `reproduced/manuscript/`; expected
length is six pages, including the figures, tables, and references.

## 3. Run a fresh synthetic verification study

```text
python tools/reproduce.py smoke
```

This sequentially prepares, trains, evaluates, audits, and analyzes the exact
reported synthetic configuration from `configs/reported_synthetic.json` in a
new `reproduced/synthetic_study/` directory. It uses nine methods, eight rounds,
400 synthetic records, training seed 42, generator seed 812, split seed 20261117,
eight clients, and the archived epsilon/delta settings. The split seed is an
integer, not an experiment date. The reference study used Python 3.13.16,
NumPy 2.3.5, SciPy 1.17.0, and scikit-learn 1.8.0; packaging audits used Python
3.12.14. Use the recorded environment when seeking the closest numerical match.
Saved-output auditing is the direct check of the reported numbers.

## 4. Earlier Cervical development rerun

```text
python tools/reproduce.py development
```

This trains and analyzes four methods in a separate new directory with
`configs/reported_cervical.json`; it does not invoke common-test evaluation.
Downloading the UCI input requires internet access. The source records its
original URL and hash in the archived partition provenance. The unpublished
secret noise root prevents reproducing the exact reported trajectory. Do not
replace the archived results with a new realization or present it as identical.
The earlier record uses Python 3.13.16, NumPy 2.1.3, and scikit-learn 1.6.1;
see `evidence_audit/evidence/results_development/environment*.json` and its
freeze file for the complete environment.

The original Colab notebooks remain in `code/earlier/` and `code/revised/`.
They default to their original profiles. For the paper-specific settings use
the supplied commands/configurations. Larger confirmatory, robustness, tuning,
and mechanism plans are prospective; their presence is not completed evidence.

## Missing and non-releasable state

The exports omit the old secret noise root, old reference prediction arrays,
some raw input arrays, and local restart state. These omissions are disclosed
in the manuscript and are not filled with invented files. Public seeded
synthetic noise is reproducible benchmark randomness, not a confidential-data
release mechanism. The two datasets and software versions must not be pooled
into one efficacy comparison.
