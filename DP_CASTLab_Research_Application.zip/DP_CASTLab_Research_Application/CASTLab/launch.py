"""First-run installer and launcher. Uses only Python's standard library."""
from pathlib import Path
import sys,subprocess,venv,hashlib
ROOT=Path(__file__).resolve().parent
def main():
 if not (3,12)<=sys.version_info[:2]<=(3,13):
  print('Please install Python 3.12 or 3.13 (64-bit), then run this launcher again. Python 3.12 matches the validation environment.');return 1
 env=ROOT/'.venv';python=env/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
 if not python.exists():
  print('Creating an isolated Python environment…',flush=True);venv.EnvBuilder(with_pip=True).create(env)
 requirements=ROOT/'requirements.txt';signature=hashlib.sha256(requirements.read_bytes()).hexdigest();marker=env/'research_requirements.sha256'
 if not marker.exists() or marker.read_text()!=signature:
  print('Installing pinned research dependencies. This first launch needs internet access and may take a few minutes.',flush=True)
  subprocess.run([str(python),'-m','pip','install','-r',str(requirements)],check=True,cwd=ROOT);marker.write_text(signature)
 return subprocess.call([str(python),str(ROOT/'run.py'),*sys.argv[1:]],cwd=ROOT)
if __name__=='__main__':
 try:sys.exit(main())
 except subprocess.CalledProcessError:print('Dependency installation failed. Check your connection, then run the launcher again.');sys.exit(1)
