"""Focused tests of age parsing, explicit labels, and source-schema adaptation."""
from pathlib import Path
import sys,os,tempfile,subprocess,time,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
temp=tempfile.TemporaryDirectory(prefix='research-data-test-');os.environ['RESEARCH_APP_WORKSPACE']=temp.name
from common import *
import run as app
def main():
 checks=[]
 def check(name,ok):
  if not ok:raise AssertionError(name)
  checks.append(name)
 try:
  check('Age days preserve numerical information',abs(age_years('50 years 183 days')-(50+183/365.25))<1e-12)
  try:age_years('50 years 900 days');raise AssertionError('Invalid age accepted')
  except ValueError:checks.append('Malformed age rejected')
  frame=csv_frame((ROOT/'sample_data.csv').read_text());frame['age_years']=frame['age_years'].map(lambda x:f'{x} years 180 days');frame['mutation']=np.where(np.arange(len(frame))%2,'MUTATED','NOT_MUTATED')
  dataset=app.register_dataset(frame.to_csv(index=False),'mixed_age_benchmark.csv',True)
  schema={'target':'outcome','positive':'positive','features':[{'name':c['name'],'kind':'age' if c['name']=='age_years' else 'numeric' if c['name']=='mutation' else c['kind'],'low':0 if c['name'] in ['age_years','mutation'] else c['low'],'high':120 if c['name']=='age_years' else 1 if c['name']=='mutation' else c['high'] if c['high']>c['low'] else c['low']+1} for c in dataset['columns'] if c['name']!='outcome']}
  check('Mixed source data validates',validate_data(frame,schema,4)['ready'])
  cfg=defaults();cfg.update(name='Age and schema regression',methods=['gate_learned','fixed_dp'] if META['engine']=='acquisition' else ['proposed','fixed'],clients=4,participation=1.,encoder=[8,4],head=4,learning_batch=4)
  started=app.start_run({'dataset_id':dataset['id'],'schema':schema,'config':cfg});i=started['id'];worker=app.PROCESSES[i];worker.wait(timeout=180)
  folder=app.run_folder(i);status=read(folder/'status.json')
  if status['stage']!='completed':raise AssertionError((status,(folder/'run.log').read_text()))
  check('Both comparison methods execute on age strings',len(read(folder/'results.json')['runs'])==2)
  check('Source benchmark leakage exclusions retained','Dx:Cancer' in META['schemas']['Biopsy']['exclude'])
  save(ROOT/'validation/data_regression_report.json',{'app':META['name'],'passed':True,'checks':checks,'runs_tested':2,'time':now()});print(json.dumps({'app':META['name'],'checks':checks,'passed':True}))
 finally:
  for p in app.PROCESSES.values():
   if p.poll() is None:p.terminate();p.wait()
  temp.cleanup()
if __name__=='__main__':main()
