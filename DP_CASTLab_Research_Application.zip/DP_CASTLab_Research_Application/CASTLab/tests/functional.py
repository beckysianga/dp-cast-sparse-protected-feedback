"""End-to-end tests using temporary data and the actual NumPy training engines."""
from pathlib import Path
import os,sys,tempfile,time,json,threading,urllib.request,urllib.error,zipfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
TEMP=tempfile.TemporaryDirectory(prefix='research-studio-test-');os.environ['RESEARCH_APP_WORKSPACE']=TEMP.name
import run as app
from common import *
def main():
 checks=[]
 def check(name,value):
  if not value:raise AssertionError(name)
  checks.append(name);print('PASS',name,flush=True)
 server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();base=f'http://127.0.0.1:{server.server_port}'
 def call(path,data=None,token=app.TOKEN,origin=None):
  headers={'Content-Type':'application/json','X-Research-Token':token}
  if origin:headers['Origin']=origin
  req=urllib.request.Request(base+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
  with urllib.request.urlopen(req,timeout=30) as response:return json.loads(response.read())
 def fails(name,fn,code):
  try:fn();raise AssertionError(name)
  except urllib.error.HTTPError as e:check(name,e.code==code)
 try:
  b=call('/api/bootstrap');check('Bootstrap metadata and CSRF token',b['meta']['name']==META['name'] and bool(b['token']))
  fails('Cross-origin mutations rejected',lambda:call('/api/datasets/sample',{},origin='https://untrusted.example'),403)
  fails('Missing CSRF token rejected',lambda:call('/api/datasets/sample',{},token=''),403)
  fails('Duplicate column names rejected',lambda:call('/api/datasets/upload',{'filename':'bad.csv','csv':'a,a\n1,0\n'}),400)
  d=call('/api/datasets/sample',{});check('CSV ingestion and profiling',d['rows']==800 and d['synthetic'])
  schema={'target':'outcome','positive':'positive','features':[{'name':c['name'],'kind':c['kind'],'low':c['low'],'high':c['high'] if c['high']>c['low'] else c['low']+1} for c in d['columns'] if c['name']!='outcome']}
  validated=call('/api/validate',{'dataset_id':d['id'],'schema':schema,'clients':4});check('Positive label and category schema validation',validated['ready'] and 0<validated['prevalence']<1)
  bad={**schema,'positive':'unknown'};fails('Unknown positive class rejected',lambda:call('/api/validate',{'dataset_id':d['id'],'schema':bad}),400)
  cfg=defaults();cfg.update(name='All-method executable validation',methods=list(META['methods']),seeds=[142,152] if META['engine']=='acquisition' else [42,52],clients=4,rounds=10 if META['engine']=='acquisition' else 8,participation=1.,encoder=[8,4],head=4,learning_batch=4,pretrain_epochs=2,delta=1e-4)
  started=call('/api/runs',{'dataset_id':d['id'],'schema':schema,'config':cfg});i=started['id'];check('Worker starts',started['stage'] in ['queued','preparing'])
  fails('Concurrent experiment rejected',lambda:call('/api/runs',{'dataset_id':d['id'],'schema':schema,'config':cfg}),400)
  seen=set();deadline=time.monotonic()+600
  while time.monotonic()<deadline:
   status=call(f'/api/runs/{i}/status');seen.add(status['stage'])
   if status['stage'] not in ['queued','preparing','training','evaluating']:break
   time.sleep(.2)
  if status['stage']!='completed':
   print(call(f'/api/runs/{i}/log')['text']);raise AssertionError(status)
  check('Actual training and evaluation finish',status['percent']==100)
  result=call(f'/api/runs/{i}/results');check('Every method and seed produced a result',len(result['runs'])==len(cfg['methods'])*2)
  check('Finite AP for every run',all(r['ap'] is not None and 0<=r['ap']<=1 for r in result['runs']))
  check('Independent prediction audit passes',result['prediction_audit']['all_passed'])
  check('Paired seed intervals produced',all(x['paired_seeds']==2 and x['ci95_low'] is not None for x in result['paired']))
  check('Undefined privacy targets retained as null',any(r['epsilon'] is None for r in result['runs']))
  folder=app.run_folder(i);gate='EVALUATION_OPENED.json' if META['engine']=='acquisition' else 'TEST_OPENED.json';check('Final model commitment gate preserved',(folder/'study'/gate).exists())
  import numpy as np
  if META['engine']=='acquisition':
   for p in (folder/'study/runs').glob('*/final_accounting.csv'):
    if p.stat().st_size>2:
     import pandas as pd
     ledger=pd.read_csv(p);check('Nondefault delta respected '+p.parent.name,bool(np.allclose(ledger.epsilon,cfg['epsilon'])))
  else:
   prep=read(folder/'preprocessing.json');check('Category declaration honored',any(x['kind']=='category' for x in prep['specs']))
  with urllib.request.urlopen(base+f'/download/{i}/experiment.zip') as response:content=response.read()
  import io
  with zipfile.ZipFile(io.BytesIO(content)) as z:
   names=z.namelist();check('Downloadable ZIP is intact',z.testzip() is None)
   check('Raw upload and restart secrets excluded',not any(n.endswith('/input.csv') or 'LOCAL_RESTART' in n or '/bundles/' in n or '/normalized/' in n for n in names))
   check('Reports, source and prediction audit exported',all(any(n.endswith('/'+x) for n in names) for x in ['results.csv','comparison.svg','report.html','request.json','metric_audit.json','source/app.json']))
  fails('Arbitrary file download blocked',lambda:call(f'/download/{i}/input.csv'),403)
  cfg.update(rounds=500,methods=cfg['methods'][:1],seeds=cfg['seeds'][:1]);new=call('/api/runs',{'dataset_id':d['id'],'schema':schema,'config':cfg});cancelled=call(f'/api/runs/{new["id"]}/cancel',{});check('Cancellation terminates the worker',cancelled['stage']=='cancelled' and app.PROCESSES[new['id']].poll() is not None)
  save(ROOT/'validation/integration_report.json',{'app':META['name'],'passed':True,'checks':checks,'observed_stages':sorted(seen),'runs_tested':len(result['runs']),'environment':environment(),'time':now(),'scope':'Functional API and real training verification on synthetic data; no browser visual inspection.'})
  # Preserve only synthetic QA results, outside the distribution, for renderer checks.
  qa=ROOT.parent.parent/'qa'/META['name'];qa.mkdir(parents=True,exist_ok=True)
  for filename in ['results.json','comparison.png','comparison.svg','report.html','request.json','run.log']:
   import shutil
   shutil.copy2(folder/filename,qa/filename)
  print(json.dumps({'passed':True,'app':META['name'],'runs':len(result['runs']),'checks':len(checks)}),flush=True)
 finally:
  server.shutdown();server.server_close()
  for p in app.PROCESSES.values():
   if p.poll() is None:p.terminate();p.wait(timeout=15)
  TEMP.cleanup()
if __name__=='__main__':main()
