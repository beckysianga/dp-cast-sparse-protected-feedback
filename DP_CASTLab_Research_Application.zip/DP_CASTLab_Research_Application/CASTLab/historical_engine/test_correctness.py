"""Deterministic correctness tests, including mathematical and protocol invariants."""
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from core import (Config,metrics,PrivacyFilter,project_l2,MLP,focal_loss_gradient,
    DoubleDQN,make_context,keyed_rng,ACTIONS,method_spec)
from data import PublicPreprocessor,encode_target,prepare,EXCLUSIONS
from experiment import train,evaluate_common_test,allocations,action_costs
from analyze import paired_interval,holm

def small_config(**kw):
    opts=dict(profile='smoke',datasets=['synthetic'],methods=['dpcast'],seeds=[17],alphas=[.5],
        epsilon_targets=[8.],clients=4,rounds=8,local_epochs=1,batch_size=64,
        encoder_dims=[8,4],head_hidden=4,dropout=0.,max_rows=240,
        rl_batch=4,rl_warmup=4,rl_updates_per_round=2,benchmark_diagnostics=False,
        bootstrap_reps=100)
    opts.update(kw); return Config(**opts).validate()

class MetricsTests(unittest.TestCase):
    def test_constant_scores_equal_prevalence(self):
        y=np.array([0,1,0,0,1,0]); self.assertAlmostEqual(metrics(y,np.ones(6)*.3)['ap'],y.mean())

    def test_ties_permutation_invariance(self):
        y=np.array([0,1,0,1,0,1,1]); p=np.array([.2,.2,.8,.8,.8,.3,.3]); base=metrics(y,p)['ap']
        rng=keyed_rng(1)
        for _ in range(30):
            ix=rng.permutation(len(y)); self.assertAlmostEqual(metrics(y[ix],p[ix])['ap'],base)

    def test_undefined_and_empty(self):
        self.assertTrue(np.isnan(metrics([0,0],[.1,.2])['ap']))
        self.assertTrue(np.isnan(metrics([1,1],[.1,.2])['auroc']))
        self.assertEqual(metrics([],[])['undefined_reason'],'empty')

class PrivacyTests(unittest.TestCase):
    def test_gaussian_cost_and_fixed_bound(self):
        f=PrivacyFilter(3,8.,1e-5); c=f.capacity/10
        z=f.release(np.zeros(2),0,'test',c,0,2.,keyed_rng(1),reserve=f.capacity/2)
        self.assertEqual(z.shape,(2,)); self.assertAlmostEqual(f.events[-1]['noise_sd'],2/np.sqrt(2*c))
        self.assertAlmostEqual(f.certificate()['bound_at_fixed_order'],8.)

    def test_refusal_before_rng_or_ledger_change(self):
        class ForbiddenRNG:
            def normal(self,*args): raise AssertionError('Noise was drawn before the budget guard')
        f=PrivacyFilter(2,1.,1e-5)
        with self.assertRaises(RuntimeError): f.release(1.,0,'test',f.capacity*2,0,1.,ForbiddenRNG())
        self.assertEqual(len(f.events),0); self.assertEqual(f.spent.sum(),0)

    def test_reservation_and_exact_boundary(self):
        f=PrivacyFilter(2,4.,1e-5)
        self.assertTrue(f.feasible(0,.6*f.capacity,.4*f.capacity))
        self.assertFalse(f.feasible(0,.6*f.capacity,.401*f.capacity))
        f.charge(0,'a',.9*f.capacity,0,1.)
        f.charge(0,'final',.1*f.capacity,1,1.)
        self.assertFalse(f.feasible(0,.01*f.capacity))

    def test_replacement_sensitivities(self):
        rng=keyed_rng(99)
        for _ in range(30):
            a=project_l2(rng.normal(size=100),.05); b=project_l2(rng.normal(size=100),.05)
            self.assertLessEqual(np.linalg.norm(a-b),.1+1e-12)
        self.assertAlmostEqual(np.linalg.norm(np.ones(5)-np.zeros(5)),np.sqrt(5))

    def test_adaptive_budget_actions_and_reserve(self):
        f=PrivacyFilter(2,8.,1e-5); c=small_config(); pool=allocations(c,method_spec('dpcast'),f.capacity)
        spent=0.; n=10
        for remaining in reversed(range(1,n+1)):
            candidates=action_costs(pool['update'],spent,remaining)
            minimum_future=(remaining-1)*pool['update']/n*.5
            valid=candidates+spent+minimum_future<=pool['update']+1e-12
            self.assertTrue(valid.any()); cost=candidates[np.flatnonzero(valid)[-1]]; spent+=cost
        self.assertLessEqual(spent,pool['update']+1e-12)

class NeuralTests(unittest.TestCase):
    def test_focal_gradient_finite_difference(self):
        z=np.array([[-2.],[.4],[1.2]]); y=np.array([0,1,0]); _,grad=focal_loss_gradient(z,y)
        h=1e-5
        for i in range(3):
            a=z.copy();b=z.copy();a[i]+=h;b[i]-=h
            numerical=(focal_loss_gradient(a,y)[0]-focal_loss_gradient(b,y)[0])/(2*h)
            self.assertAlmostEqual(numerical,grad[i,0],places=7)

    def test_network_backprop_finite_difference(self):
        m=MLP([2,3,1],keyed_rng(9)); x=np.array([[.3,.8],[.7,-.2]]); y=np.array([0,1])
        z,cache=m.forward(x); _,grad=focal_loss_gradient(z,y); actual=m.backward(grad,cache)
        h=1e-5
        for p,g in zip(m.params,actual):
            for ix in np.ndindex(p.shape):
                old=p[ix];p[ix]=old+h;a=focal_loss_gradient(m.forward(x)[0],y)[0]
                p[ix]=old-h;b=focal_loss_gradient(m.forward(x)[0],y)[0];p[ix]=old
                self.assertAlmostEqual((a-b)/(2*h),g[ix],places=6)

    def test_focal_extreme_logits_finite(self):
        loss,g=focal_loss_gradient(np.array([[-1e4],[1e4]]),[1,0])
        self.assertTrue(np.isfinite(loss)); self.assertTrue(np.isfinite(g).all())

    def test_dqn_updates_and_masks(self):
        cfg=small_config(); q=DoubleDQN(cfg,2); s=np.ones(8)*.2; mask=np.zeros(15,bool); mask[4]=True
        self.assertEqual(q.greedy(s,mask),4)
        before=q.q.vector().copy()
        for _ in range(8): q.add(s,4,1.,s,False,mask)
        self.assertTrue(np.isfinite(q.learn())); self.assertGreater(np.linalg.norm(q.q.vector()-before),0)
        self.assertTrue(np.array_equal(q.frozen.vector(),before))

class DataTests(unittest.TestCase):
    def test_mapping_is_strict(self):
        self.assertTrue(np.array_equal(encode_target(pd.Series(['LGG','GBM']),'Glioma'),[0,1]))
        with self.assertRaises(ValueError): encode_target(pd.Series([1,2]),'Cervical')

    def test_reference_only_and_unknown_categories(self):
        a=pd.DataFrame({'n':[1.,2.,np.nan],'c':['A','B',None]})
        p=PublicPreprocessor().fit(a,['c']); before=json.dumps(p.specs)
        b=pd.DataFrame({'n':[1e20],'c':['PRIVATE_ONLY_CATEGORY']}); x=p.transform(b)
        self.assertEqual(json.dumps(p.specs),before); self.assertTrue(np.isfinite(x).all())
        self.assertEqual(x[0,-2],1.)

    def test_partition_disjoint_and_fixed_test(self):
        cfg=small_config()
        with tempfile.TemporaryDirectory() as d:
            a=prepare('synthetic',cfg,1,.1,d,Path(d)/'a')
            b=prepare('synthetic',cfg,2,.1,d,Path(d)/'b')
            self.assertTrue(np.array_equal(a.public_test,b.public_test))
            self.assertNotEqual(a.partition_hash,b.partition_hash)
            allidx=np.concatenate([a.public_val,a.public_test,*a.client_train,*a.client_test])
            self.assertEqual(len(np.unique(allidx)),len(a.y))
            self.assertFalse((Path(d)/'a/dataset_audit_BENCHMARK_ONLY.json').exists())

    def test_leakage_exclusions(self):
        self.assertIn('death',EXCLUSIONS['SUPPORT2']); self.assertIn('d.time',EXCLUSIONS['SUPPORT2'])
        self.assertIn('Case_ID',EXCLUSIONS['Glioma']); self.assertIn('Hinselmann',EXCLUSIONS['Cervical'])

class InferenceTests(unittest.TestCase):
    def test_holm_and_paired_interval(self):
        self.assertTrue(np.allclose(holm([.01,.04,.03]),[.03,.06,.06]))
        a=paired_interval([.01,.02,.03,.04,.05],keyed_rng(2),200)
        self.assertAlmostEqual(a['mean'],.03); self.assertGreater(a['ci_width'],0)
        self.assertEqual(a['n'],5)

class IntegrationTests(unittest.TestCase):
    def test_protected_transcript_replay_and_no_test_peeking(self):
        cfg=small_config()
        with tempfile.TemporaryDirectory() as d:
            p=prepare('synthetic',cfg,17,.5,d,Path(d)/'partition'); out=Path(d)/'run'
            s=train(p,cfg,'dpcast',17,.5,8.,out)
            self.assertGreater(s['controller_updates'],0)
            self.assertGreater(s['decisions_after_first_update'],0)
            self.assertFalse((out/'public_test_predictions.npz').exists())
            self.assertFalse((out/'BENCHMARK_ONLY_NOT_PRIVATE').exists())
            ledger=pd.read_csv(out/'ledger.csv')
            self.assertLessEqual(ledger.cumulative_charged_rho.max(),s['rho_capacity']+1e-12)
            self.assertEqual(int((ledger.mechanism=='local_evaluation').sum()),cfg.clients)
            action=pd.read_csv(out/'actions.csv'); replay=pd.read_csv(out/'replay_index.csv')
            for _,r in replay.iterrows():
                match=action[(action.client==r.client)&(action['round']==r.source_round)]
                self.assertEqual(int(match.iloc[0].executed_action),r.executed_action)
            e=evaluate_common_test(p,cfg,out)
            self.assertTrue(0<=e['mean_head_ap']<=1)

    def test_all_controls_and_empty_rounds(self):
        cfg=small_config(rounds=2,participation=.00001,benchmark_diagnostics=True,reproducible_noise=True)
        methods=['fixed','adaptive_clip','rule','random','frozen','dpcast','constant','noise_only',
                 'constant_realloc','noise_only_realloc','drop_0','drop_2_realloc','raw_context','nonprivate']
        with tempfile.TemporaryDirectory() as d:
            p=prepare('synthetic',cfg,17,.5,d,Path(d)/'partition')
            for method in methods:
                s=train(p,cfg,method,17,.5,8.,Path(d)/method)
                self.assertEqual(s['executed_releases'],0); self.assertEqual(s['empty_rounds'],2)

if __name__=='__main__': unittest.main(verbosity=2)

