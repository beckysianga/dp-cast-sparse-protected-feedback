# DP CAST research implementation

This package implements a corrected experimental successor to the supplied DP-CAST paper and its review suggestions. It studies whether protected client context helps adaptive privacy control at a common, predeclared privacy bound. It does not reproduce the manuscript's old numerical results, certify novelty, or guarantee journal acceptance.

The implementation is a CPU NumPy reference implementation with explicit neural-network gradients and Adam. It does not need PyTorch, CUDA, an API key, or a paid service. The default model follows the manuscript: shared encoder 128–64–32, client head 32–1, dropout 0.10, focal loss alpha 0.75 and gamma 2, eight clients, Bernoulli participation 0.75, two local epochs and batch size 256. The controller is Double-DQN 8–64–32–15. Finite-difference tests check both focal-loss and network gradients.

## Start in Google Colab

Open **DP_CAST_Colab.ipynb** in Colab and run its setup/run cell. The notebook contains the source files, so you do not need to upload the ZIP. Alternatively, paste the contents of **DP_CAST_Single_Cell.py** into one Colab cell. Start with `PROFILE = "development"`. This trains four methods on Cervical Cancer for twenty rounds. `RUN_FINAL_TEST = False` leaves the common test set unevaluated.

After finalising your protocol using validation results, choose the appropriate publication configuration and a new output directory. Set `RUN_FINAL_TEST = True` only when ready to run the locked final evaluation. `DOWNLOAD_RESULTS = True` downloads a ZIP when the cell finishes. The same output directory resumes **completed runs**; an interrupted run restarts from its beginning. Set `WORKDIR` to a mounted Google Drive folder yourself if you need results to survive a Colab reset. The code does not mount an account or overwrite a different protocol.

The full main design contains **1,260 runs**: four datasets × seven methods × three heterogeneity levels × five seeds × three privacy targets. The optional ten-seed configuration contains 2,520 runs. Full runs may require substantial CPU time, especially CDC Diabetes. Benchmark the development run on your machine before scheduling the full study. GPU selection does not accelerate this NumPy implementation. The profiles marked smoke/validation are software checks, not publication evidence.

## Run locally

Use Python 3.10 or later. From this directory:

```bash
python -m pip install -r requirements.txt
python run.py test
python run.py lock --config configs/development.json --out results_development
python run.py train --config configs/development.json --out results_development
```

When the protocol is final, use a new directory and an agreed configuration:

```bash
python run.py lock --config configs/publication.json --out results_main
python run.py train --config configs/publication.json --out results_main
python run.py evaluate --config configs/publication.json --out results_main
python run.py analyze --config configs/publication.json --out results_main
python run.py package --out results_main
```

Every command verifies the locked configuration and source hashes. Changing source code or a configuration requires a new output directory. Input and partition hashes are also checked between training and evaluation. The test set remains separate from training and the controller; the `evaluate` command is the explicit evaluation gate. This is an auditable software gate, not a substitute for external preregistration or an untouched cohort.

## What changed scientifically

| Issue in the supplied paper | Implemented repair |
| --- | --- |
| AP depends on tie order | `sklearn.metrics.average_precision_score`; constant-score and permutation tests |
| Raw validation feedback from private heads | Feedback uses the released encoder and **protected head proxies** on public reference data |
| Unprotected released personalised models | Joint encoder/head update clipped once and protected before release; raw heads stay client-local |
| Raw reward terms | Reward uses public evaluation of protected models and already protected context |
| Raw cross-client median | Context uses the previous protected aggregate norm as its public reference |
| Pooled private preprocessing | Transform fitted only on the designated public reference features |
| Central ledger double-counting | Optional central noise is post-processing, assigned zero additional server privacy cost |
| Sampling mismatch | Genuine Bernoulli participation, empty rounds retained, no amplification claimed |
| Late budget checks and unchecked fallback | Fixed-order adaptive RDP filter before each message; future auxiliary costs, minimum update costs and final local evaluation reserved |
| Replay records proposal | Replay uses the actual executed action and the next feasible-action mask |
| Unequal privacy comparisons | Same epsilon cap, delta, client-replacement adjacency, observer, horizon and output scope across private methods |
| Weak learning controls | Random, frozen and rule-based policies share the same feasible 15-action set |
| No context information controls | Constant, noise-only and all five leave-one-coordinate-out variants, with distinct budget-reallocation variants |
| No controller learning evidence | Reward components, Q-loss, updates before decisions, and trained/frozen/before/after greedy decisions on identical protected states |
| Missing predictions and trajectories | Prediction arrays, controller replay, model snapshots, per-release ledger, source/configuration/data/partition hashes |
| Too few/pooled replications | Five-seed main design; optional ten; paired seed effects separately within each heterogeneity setting |

These are substantive methodology changes. Update the manuscript's algorithm, model release definition, privacy theorem, data preparation, action interpretation, reward and evaluation sections before reporting this code's results. In particular, the main common-test endpoint now measures **protected personalised-head proxies**, whereas raw local heads are assessed separately. Do not mix the old paper's results with the corrected experiments.

## Methods and action interpretation

| Method | Controller information and policy | Role |
| --- | --- | --- |
| `nonprivate` | No DP; fixed training policy | Nonprivate benchmark reference |
| `fixed` | Fixed clipping; fixed update allocation | Primary private baseline |
| `adaptive_clip` | Private clipping indicator; fixed update allocation | Private clipping baseline |
| `rule` | Protected context, deterministic rule over the same 15 actions | Policy baseline |
| `random` | Protected context, uniformly random feasible action | Learning control |
| `frozen` | Protected context, frozen initial Q-network, same exploration schedule | Learning control |
| `dpcast` | Protected context, trained Double-DQN | Proposed experimental method |
| `constant`, `noise_only` | Public constant context or independent clipped Gaussian context; same reserved context allocation | Information-removal controls |
| `constant_realloc`, `noise_only_realloc` | Same public controls; unused context allocation moved to updates | Resource-reallocation controls |
| `drop_0` … `drop_4` | One input coordinate replaced by 0.5; same allocation and perturbation for remaining coordinates | Coordinate information controls |
| `drop_0_realloc` … `drop_4_realloc` | Four-coordinate mechanism with sensitivity sqrt(4); removed coordinate's one-fifth context allocation moved to updates | Coordinate resource controls |
| `raw_context` | Raw context; same nominal resource allocation as DP-CAST | **Unprotected diagnostic**, never a privacy-equivalent comparator |

Actions are `(update rho factor, clipping multiplier)` in `{0.5, 0.75, 1, 1.5, 2} × {0.75, 1, 1.25}`. They are **not stand-alone epsilon values**. For each client, the factor applies to the average remaining update allocation per remaining participation. The filter masks infeasible choices. The rule, random, frozen and trained policies see the same 15 candidate actions. Fixed baselines intentionally use one prescribed action. Privacy adaptation is distinct from estimating mathematical sensitivity: the context's “sensitivity score” is only a feature; it never replaces the proved bound `2C`.

The exploration schedule declines from 1 to 0.05 during the first 70% of rounds. It depends on public time, not the number of successful updates. The main candidate horizon is 100 rounds, with four controller updates per round after 32 transitions. These settings are hypotheses to check using the included 30/100/200-round development configurations, not claims of convergence or optimality.

## Privacy model and output scope

Read **PRIVACY_PROTOCOL.md** for the exact conditional proposition and release sequence. The protected unit is the entire local dataset/state of one of eight fixed, enrolled clients, including its private held-out evaluation records. Adjacency replaces that client's dataset; it is not patient-level DP-SGD. The observer sees every protected client message, the model, policy and their derived scores. There is no secure aggregation, hostile-server defence, collusion analysis, communication timing protection, or process isolation.

Each private run uses a preselected Renyi order and a fixed-order adaptive RDP filter. The reported guarantee is the **configured epsilon cap**. The observed `rho` ledger is reported separately; the code does not turn a realised adaptive expenditure into a smaller certified epsilon. The accountant deliberately makes no sampling-amplification claim.

The reference implementation uses ordinary floating-point Gaussian sampling. The mathematics assumes ideal independent Gaussian noise; this package is not a hardened finite-precision DP library. Normal runs use an OS-seeded, undisclosed noise root. `reproducible_noise=true` publishes enough information to reconstruct noise and therefore marks that run as a **public benchmark simulation only**. Model/partition seeds may be public; DP noise seeds must not be disclosed for sensitive-data releases.

`benchmark_diagnostics=true` saves raw context distortion, local predictions, true local metrics, dataset counts and partitions under **BENCHMARK_ONLY_NOT_PRIVATE** labels. Those files allow research auditing on these public datasets. **The complete benchmark ZIP has no privacy guarantee.** A “protocol-eligible” entry refers only to the designated idealised protocol transcript within one run. The raw-context and nonprivate methods have no such claim. Setting diagnostics to false suppresses raw diagnostic files but does not convert this single-process benchmark loader into a clinical deployment system.

Running many methods/seeds on the same genuinely sensitive data would itself require an additional experiment-level composition analysis, including preprocessing, partition construction, model selection and all released results. A per-run epsilon is not a privacy budget for the entire study. This study uses public UCI benchmark data and states privacy conditionally for the implemented release protocol.

## Dataset semantics and leakage controls

| Dataset | Positive target | Exclusions and interpretation |
| --- | --- | --- |
| CDC Diabetes | `Diabetes_binary=1`: prediabetes or diabetes according to the UCI schema | ID and alternative target excluded; do not silently reinterpret as diabetes alone |
| Cervical Cancer | `Biopsy=1` | Other diagnostic targets and `Dx` indicators removed conservatively |
| Glioma | `Grade=1`: GBM; `0`: LGG | Case/project/diagnosis identifiers removed; clinical and mutation features, **not MRI images** |
| SUPPORT2 | `hospdead=1`: in-hospital death | Death/follow-up time, length of stay, costs, model survival scores and DNR/prognosis variables removed; **static retrospective benchmark, not a 24-hour landmark** |

The UCI API metadata resolves the current official CSV endpoint. Downloads retry three times, cache exact bytes and record SHA-256. A failed clinical download raises an error; it never substitutes synthetic observations. A local official CSV can be placed at `data_cache/<dataset>.csv`. Unknown target encodings fail closed. The explicit synthetic dataset is only for tests.

The public reference and common test splits each receive 10% using a fixed split seed shared across replications. The remaining 80% is distributed with class-wise Dirichlet allocation, then each client's pool is split locally into training and held-out data. This changes the paper's effective training fraction. Some small non-IID clients may contain one class or no records; no resampling hides that fact. Empty clients remain enrolled and send data-independent bounded messages if selected. The audit reports true sizes/class counts for public benchmark research. AP is undefined without positives; AUROC and balanced accuracy require both classes. Undefined values remain missing with validity counts and reasons.

Preprocessing learns numeric imputation/scaling and category vocabularies only from the public reference split. A fixed unknown category handles unseen values. The reference data must truly be available independently of the protected clients for the conditional privacy statement. Constructing that public split from a sensitive pooled database is not covered.

## Experiments and inference

1. Use `horizon_development_30.json`, `horizon_development_100.json` and `horizon_development_200.json` for validation-only controller development. Their seeds differ from the proposed final replication seeds. Review reward scales, Q-loss, decisions after updates and trained-versus-frozen actions.
2. Fix the horizon, clipping/projection settings, reward, feature exclusions and privacy targets before final evaluation. The code locks exact source/configuration hashes. It does not hide prior inspection of these benchmarks.
3. Run `publication.json` for the main matched-cap comparison. Five seeds are a minimum starting design, not a power guarantee. Use `ten_seeds.json` if resources and planned precision justify it.
4. Run `context_controls.json` for information and resource controls. The three `context_budget_*.json` profiles test context allocations of 5%, 15% and 30% at fixed total epsilon. Use separate output directories for each profile.
5. Set a scientifically justified AP non-inferiority margin and its written justification **before locking** if that claim is wanted. The default is `null`; no equivalence or preservation claim is generated. The reported interval-based margin check is descriptive and not multiplicity-adjusted confirmatory inference.
6. Evaluate and regenerate the tables/plots with `evaluate` and `analyze`. Report negative findings and uncertainty. Similar raw/protected controller performance alone does not establish useful learning.

The primary endpoint is arithmetic mean positive-class AP across protected personalised heads on the **same** common test distribution. Worst-head AP and head dispersion describe model variation, not demographic/clinical fairness. Local held-out raw-head scores answer a different question and are clearly marked benchmark-only. The protected local score release has substantial noise under whole-client adjacency; its noisy validity values must not be treated as true valid-client counts.

Paired differences use seed as the replication unit within each dataset, alpha and epsilon. Analyses report 95% Student t intervals, their widths and percentile bootstrap intervals as a sensitivity check. Two-sided sign-flip tests rely on symmetry/exchangeability; Holm adjustment covers all configured private comparisons against DP-CAST. The package does not pool heads or heterogeneity levels as independent replicates. Shared fixed test cohorts mean these intervals describe training/partition variability, not external-cohort uncertainty. The smoke analysis with one seed intentionally has no confidence interval.

## Output files

| Output | Purpose |
| --- | --- |
| `protocol_lock.json`, `executed_source/`, `environment*` | Exact source, configuration, package versions and study lock |
| `partitions/` | Input provenance, public transform, and explicitly labelled benchmark partition/data audits |
| `runs/*/ledger.csv` | Every charged mechanism, noise SD, sensitivity, reserve and fixed-order RDP cost |
| `rounds.csv`, `actions.csv`, `controller_learning.csv` | Validation trajectory, executed decisions, exploration, reward components, losses and learning diagnostics |
| `protected_context.csv`, `private_clipping.csv` | Released context, coordinate saturation and protected clipping messages |
| `protected_replay.npz`, `replay_index.csv`, `controller.npz` | Replay with executed actions, Q-network and target/frozen snapshots |
| `released_model.npz` | Final protected encoder and per-client head proxies; raw heads are not checkpointed |
| `client_*_protected_local_metrics.json` | Accounted, bounded local metric and validity-vector release |
| `public_test_predictions.npz`, `common_test_head_metrics.csv` | Recomputable final common-test endpoints, created only by `evaluate` |
| `BENCHMARK_ONLY_NOT_PRIVATE/` | Raw-context distortion and local prediction/metric evidence for public benchmark study |
| `analysis/` | Per-run and stratified CSVs, paired differences, intervals, LaTeX table, PDF/PNG figures and plot source data |
| `train_completion.json`, `evaluate_completion.json` | Expected/completed configuration counts |

## A defensible contribution

A potential paper can establish the cost and usefulness of **fully protected controller feedback under an explicit server-visible release protocol**, using budget-matched information-removal and reallocation controls. The fixed-order filter and Gaussian mechanisms are established methods, not new privacy theorems. Jointly protecting head proxies is an implementation correction that changes the evaluated model. The utility benefit of the controller, the best allocation and the value of each context component are open empirical questions until the complete experiments are run.

This package includes executed software-validation evidence only. A journal submission still needs the complete agreed experiment matrix, a reviewed privacy argument, a specific related-work comparison, a coherent manuscript and reproducibility disclosure. No scores or results have been invented to support publication.

