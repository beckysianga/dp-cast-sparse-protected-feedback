"""Audited UCI loading and benchmark-only partition construction.

Public reference/test membership and client membership are fixed conditioning
information for the protocol. Label-based partition construction is NOT itself DP.
No trained preprocessing statistic is fitted on pooled private training records.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError
import json
import hashlib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification
from core import keyed_rng, save_json, digest

SPECS = {
 'CDC_Diabetes': dict(id=891, target='Diabetes_binary', positive='prediabetes or diabetes'),
 'Cervical': dict(id=383, target='Biopsy', positive='positive cervical biopsy'),
 'Glioma': dict(id=759, target='Grade', positive='GBM glioblastoma'),
 'SUPPORT2': dict(id=880, target='hospdead', positive='in-hospital death'),
}
EXCLUSIONS = {
 'CDC_Diabetes': ['ID', 'Diabetes_012'],
 'Cervical': ['ID','Hinselmann','Schiller','Citology','Cytology','Dx:Cancer','Dx:CIN','Dx:HPV','Dx'],
 'Glioma': ['ID','Project','Case_ID','Primary_Diagnosis'],
 # Conservative static clinical benchmark. Do NOT claim an hour-24 landmark.
 'SUPPORT2': ['id','ID','death','d.time','slos','charges','totcst','totmcst','sfdm2',
              'avtisst','aps','sps','surv2m','surv6m','prg2m','prg6m','dnr','dnrday'],
}
MISSING = ['?','--','not reported','unknown','NA','N/A','']

def fetch_bytes(url):
    error = None
    for attempt in range(3):
        try:
            with urlopen(Request(url, headers={'User-Agent':'DP-CAST-research/1.0'}), timeout=45) as response:
                return response.read()
        except (URLError, TimeoutError, OSError) as exc: error = exc
    raise RuntimeError(f'Download failed: {url}. Supply the matching CSV in data_cache; no synthetic fallback. {error}')

def fetch_dataset(name, cache):
    cache = Path(cache); cache.mkdir(parents=True, exist_ok=True)
    spec = SPECS[name]; csv = cache/f'{name}.csv'; meta = cache/f'{name}_metadata.json'
    if not csv.exists():
        m = json.loads(fetch_bytes(f'https://archive.ics.uci.edu/api/dataset?id={spec["id"]}'))
        if m.get('status') != 200 or not m.get('data',{}).get('data_url'):
            raise RuntimeError(f'UCI dataset {spec["id"]} is unavailable; provide an official CSV.')
        metadata = m['data']; save_json(meta,metadata)
        csv.write_bytes(fetch_bytes(metadata['data_url']))
    metadata = json.loads(meta.read_text()) if meta.exists() else {'source':'user-provided CSV'}
    frame = pd.read_csv(csv, na_values=MISSING, low_memory=False)
    return frame, dict(metadata=metadata, csv_sha256=hashlib.sha256(csv.read_bytes()).hexdigest())

def encode_target(series, name):
    s = series.astype(str).str.strip().str.lower()
    maps = {'0':0,'0.0':0,'1':1,'1.0':1}
    if name == 'Glioma': maps.update(lgg=0, gbm=1)
    unknown = sorted(set(s.dropna())-set(maps))
    if unknown: raise ValueError(f'{name}: ambiguous target labels {unknown}; do not infer a positive class.')
    y = s.map(maps).to_numpy(dtype=np.int64)
    if len(np.unique(y)) != 2: raise ValueError(f'{name}: both target classes are required for the benchmark split.')
    return y

class PublicPreprocessor:
    """Fit on public reference features only; fixed schema, missing indicators.

    Numeric features use reference medians/means/SDs. All-missing columns use 0/1.
    Categories outside the reference vocabulary map to a fixed unknown bucket.
    Schema is public metadata; no feature selection based on private columns.
    """
    def __init__(self): self.specs=[]; self.feature_names=[]

    def fit(self, reference, categorical=()):
        cats = set(categorical)
        for col in reference.columns:
            s = reference[col]
            numeric = pd.to_numeric(s, errors='coerce')
            is_numeric = col not in cats and (pd.api.types.is_numeric_dtype(s) or numeric.notna().sum()==s.notna().sum())
            if is_numeric:
                a = numeric.to_numpy(float); missing = ~np.isfinite(a)
                med = float(np.median(a[~missing])) if (~missing).any() else 0.
                a[missing] = med; mean=float(a.mean()); scale=max(float(a.std()),1e-8)
                self.specs.append(dict(col=col, kind='numeric',median=med,mean=mean,scale=scale))
                self.feature_names += [col, col+'__missing']
            else:
                vals = sorted(set(s.dropna().astype(str)))
                self.specs.append(dict(col=col,kind='category',values=vals))
                self.feature_names += [col+'='+v for v in vals]+[col+'=__UNKNOWN__',col+'=__MISSING__']
        return self

    def transform(self, frame):
        parts=[]
        for spec in self.specs:
            s=frame[spec['col']]
            if spec['kind']=='numeric':
                a=pd.to_numeric(s,errors='coerce').to_numpy(float); missing=~np.isfinite(a)
                a[missing]=spec['median']
                parts += [np.clip((a-spec['mean'])/spec['scale'],-10,10)[:,None],missing.astype(float)[:,None]]
            else:
                vals=spec['values']; a=np.zeros((len(s),len(vals)+2)); mapping={v:i for i,v in enumerate(vals)}
                idx=[len(vals)+1 if pd.isna(v) else mapping.get(str(v),len(vals)) for v in s]
                a[np.arange(len(s)),idx]=1.; parts.append(a)
        out=np.concatenate(parts,axis=1)
        if not np.isfinite(out).all(): raise ValueError('Non-finite preprocessing output')
        return out

@dataclass
class Prepared:
    name: str
    x: np.ndarray
    y: np.ndarray
    public_val: np.ndarray
    public_test: np.ndarray
    client_train: list
    client_test: list
    audit: dict
    preprocessor: PublicPreprocessor
    partition_hash: str

def prepare(name, cfg, seed, alpha, cache, destination):
    if name == 'synthetic':
        # This path is explicit, never a fallback for unavailable clinical data.
        xx,yy=make_classification(n_samples=cfg.max_rows or 800,n_features=10,
            n_informative=6,weights=[.75,.25],random_state=812)
        frame=pd.DataFrame(xx,columns=[f'x{i}' for i in range(10)]); frame['outcome']=yy
        source={'csv_sha256':digest({'synthetic':812,'n':len(yy)})}; target='outcome'; positive='synthetic class 1'
    else:
        frame,source=fetch_dataset(name,cache); target=SPECS[name]['target']; positive=SPECS[name]['positive']
    frame.columns=[c.strip() for c in frame.columns]
    if target not in frame: raise ValueError(f'{name}: target {target!r} absent; found {list(frame.columns)}')
    initial_n=len(frame); missing_target=int(frame[target].isna().sum())
    frame=frame.loc[frame[target].notna()].reset_index(drop=True)
    y=encode_target(frame[target],name)
    selected=np.arange(len(frame))
    if cfg.max_rows is not None and len(frame)>cfg.max_rows:
        selected,_=train_test_split(selected,train_size=cfg.max_rows,stratify=y,random_state=cfg.split_seed)
        selected=np.sort(selected); frame=frame.iloc[selected].reset_index(drop=True); y=y[selected]
    removed=[c for c in EXCLUSIONS.get(name,[]) if c in frame]
    features=frame.drop(columns=[target]+removed)
    # Account for UCI role labels so IDs/secondary targets can never enter features.
    for var in source.get('metadata',{}).get('variables',[]):
        if var.get('role','').lower() in ['id','target'] and var.get('name') in features:
            removed.append(var['name']); features=features.drop(columns=[var['name']])
    ix=np.arange(len(y))
    rest,test=train_test_split(ix,test_size=cfg.public_test_fraction,stratify=y,random_state=cfg.split_seed)
    pool,val=train_test_split(rest,test_size=cfg.public_val_fraction/(1-cfg.public_test_fraction),
                             stratify=y[rest],random_state=cfg.split_seed+1)
    categorical=[]
    for var in source.get('metadata',{}).get('variables',[]):
        if str(var.get('type','')).lower() in ['categorical','binary']: categorical.append(var['name'])
    if name=='Glioma': categorical += [c for c in features if c!='Age_at_diagnosis']
    transform=PublicPreprocessor().fit(features.iloc[val],categorical)
    x=transform.transform(features)
    rng=keyed_rng(seed,name,alpha,'partition'); clients=[[] for _ in range(cfg.clients)]
    # Class-wise multinomial Dirichlet allocation. No retries to manufacture class coverage.
    for cls in [0,1]:
        records=rng.permutation(pool[y[pool]==cls]); proportions=rng.dirichlet(np.full(cfg.clients,alpha))
        counts=rng.multinomial(len(records),proportions); cursor=0
        for i,count in enumerate(counts): clients[i].extend(records[cursor:cursor+count].tolist()); cursor+=count
    train=[]; held=[]; client_audit=[]
    for i,records in enumerate(clients):
        records=rng.permutation(records).astype(int)
        nh=min(max(1,int(round(len(records)*cfg.local_test_fraction))),max(0,len(records)-1)) if len(records) else 0
        te=records[:nh]; tr=records[nh:]; train.append(tr); held.append(te)
        client_audit.append(dict(client=i,train_n=len(tr),train_positive=int(y[tr].sum()),
                                 heldout_n=len(te),heldout_positive=int(y[te].sum())))
    groups=[val,test,*train,*held]; joined=np.concatenate(groups)
    assert len(joined)==len(y) and len(np.unique(joined))==len(y), 'Split overlap or lost records'
    partition=dict(public_val=val.tolist(),public_test=test.tolist(),
                   client_train=[a.tolist() for a in train],client_test=[a.tolist() for a in held],
                   retained_source_rows=selected.tolist())
    ph=digest(partition)
    audit=dict(dataset=name,initial_rows=initial_n,missing_target_removed=missing_target,
        retained_rows=len(y),positive_label=positive,prevalence=float(y.mean()),
        raw_feature_count=features.shape[1],encoded_feature_count=x.shape[1],
        feature_names=list(features.columns),excluded_columns=removed,
        missingness={c:float(features[c].isna().mean()) for c in features},
        public_val_n=len(val),public_test_n=len(test),local_train_n=sum(map(len,train)),
        local_heldout_n=sum(map(len,held)),clients=client_audit,partition_hash=ph,
        fixed_evaluation_split_seed=cfg.split_seed,partition_seed=seed,dirichlet_alpha=alpha,
        source=source,prediction_task='static retrospective tabular classification; no prospective time landmark',
        preprocessing_fit='public validation/reference features only',
        claim_conditioning='public reference/test and fixed client membership; partition construction excluded')
    destination=Path(destination); destination.mkdir(parents=True,exist_ok=True)
    # These are benchmark-side records and are never sent to the protocol server.
    if cfg.benchmark_diagnostics:
        save_json(destination/'dataset_audit_BENCHMARK_ONLY.json',audit)
        save_json(destination/'partitions_BENCHMARK_ONLY.json',partition)
    save_json(destination/'public_preprocessing.json',dict(specs=transform.specs,features=transform.feature_names))
    return Prepared(name,x,y,val,test,train,held,audit,transform,ph)

