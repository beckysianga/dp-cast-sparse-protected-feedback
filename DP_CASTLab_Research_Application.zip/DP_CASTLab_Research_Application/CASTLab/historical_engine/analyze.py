"""Rebuild results from saved predictions; seed-level paired inference only."""
from __future__ import annotations
import itertools
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from core import save_json, keyed_rng, metrics, average_metrics

def paired_interval(differences,rng,reps=10000):
    d=np.asarray(differences,float); d=d[np.isfinite(d)]; n=len(d)
    if n<2: return dict(n=n,mean=float(d.mean()) if n else np.nan,ci_low=np.nan,ci_high=np.nan,
                        ci_width=np.nan,bootstrap_low=np.nan,bootstrap_high=np.nan,p_value=np.nan)
    estimate=float(d.mean()); se=float(d.std(ddof=1)/np.sqrt(n)); critical=float(student_t.ppf(.975,n-1))
    lo,hi=estimate-critical*se,estimate+critical*se
    boot=d[rng.integers(n,size=(reps,n))].mean(axis=1); blo,bhi=np.quantile(boot,[.025,.975])
    # Two-sided paired sign-flip test; symmetry/exchangeability is an assumption.
    if n<=16:
        signs=np.array(list(itertools.product([-1.,1.],repeat=n)))
        p=float(np.mean(np.abs(signs@d/n)>=abs(estimate)-1e-14))
    else:
        signs=rng.choice([-1.,1.],size=(reps,n))
        p=float((1+np.sum(np.abs(signs@d/n)>=abs(estimate)-1e-14))/(reps+1))
    return dict(n=n,mean=estimate,ci_low=lo,ci_high=hi,ci_width=hi-lo,
                bootstrap_low=float(blo),bootstrap_high=float(bhi),p_value=p)

def holm(pvalues):
    p=np.asarray(pvalues,float); result=np.full(len(p),np.nan); valid=np.flatnonzero(np.isfinite(p))
    ordered=valid[np.argsort(p[valid])]; previous=0.
    for rank,index in enumerate(ordered):
        previous=max(previous,min(1.,(len(ordered)-rank)*p[index])); result[index]=previous
    return result

def analyze(root,cfg):
    root=Path(root); records=[]; context=[]; source_integrity=[]
    for f in sorted((root/'runs').glob('*/training_summary.json')):
        row=json.loads(f.read_text()); folder=f.parent
        if not (folder/'common_test_summary.json').exists(): continue
        row.update(json.loads((folder/'common_test_summary.json').read_text()))
        # Recompute the central AP endpoint directly from archived predictions.
        pred=np.load(folder/'public_test_predictions.npz',allow_pickle=False)
        recalculated=average_metrics([metrics(pred['y'],p) for p in pred['probabilities']])
        if not np.isclose(row['mean_head_ap'],recalculated['mean_ap'],atol=1e-12):
            raise RuntimeError(f'Prediction/summary mismatch in {folder.name}')
        records.append(row); source_integrity.append(dict(run=folder.name,predictions_recomputed=True))
        ctx_file=folder/'BENCHMARK_ONLY_NOT_PRIVATE/context_distortion.csv'
        if ctx_file.exists() and ctx_file.stat().st_size>5:
            df=pd.read_csv(ctx_file)
            for coordinate,g in df.groupby('coordinate'):
                context.append(dict(dataset=row['dataset'],method=row['method'],seed=row['seed'],
                    alpha=row['alpha'],epsilon_target=row['epsilon_target'],coordinate=coordinate,
                    mae=float(g.absolute_error.mean()),boundary_saturation=float(g.protected.isin([0.,1.]).mean()),
                    decision_change_rate=float(g.action_changed.mean()),n_releases=len(g)))
    if not records: raise RuntimeError('No evaluated runs. Run evaluate after train.')
    out=root/'analysis'; out.mkdir(exist_ok=True)
    df=pd.DataFrame(records); df.to_csv(out/'run_results.csv',index=False)
    keys=['dataset','alpha','epsilon_target','method']
    summary=[]
    for key,g in df.groupby(keys):
        vals=g.mean_head_ap.dropna().to_numpy(); ci=paired_interval(vals,keyed_rng(72,*key),cfg.bootstrap_reps)
        summary.append(dict(zip(keys,key),mean_head_ap=float(vals.mean()),n_seeds=len(vals),
            seed_sd=float(vals.std(ddof=1)) if len(vals)>1 else np.nan,
            ci_low=ci['ci_low'],ci_high=ci['ci_high'],ci_width=ci['ci_width'],
            worst_head_ap=float(g.worst_head_ap.mean()),head_dispersion=float(g.head_ap_dispersion.mean()),
            mean_recorded_rho=float(g.max_recorded_rho.mean()),mean_controller_updates=float(g.controller_updates.mean())))
    summary=pd.DataFrame(summary); summary.to_csv(out/'summary_by_heterogeneity.csv',index=False)
    secondary=[c for c in df if c.startswith('common_') and c!='common_test_evaluated']
    secondary += [c for c in df if c.startswith('benchmark_local_')]
    if secondary:
        df.groupby(keys)[secondary].agg(['mean','std','count']).to_csv(out/'secondary_metrics_by_heterogeneity.csv')
    pairs=[]
    # Predeclared comparisons: DP-CAST against every configured control. Raw context
    # stays in a separate diagnostic family, never a privacy-equivalent comparator.
    for (dataset,alpha,eps),g in df.groupby(['dataset','alpha','epsilon_target']):
        target=g[g.method=='dpcast']
        for method in sorted(set(g.method)-{'dpcast'}):
            a=target[['seed','mean_head_ap','partition_hash']]
            b=g[g.method==method][['seed','mean_head_ap','partition_hash']]
            matched=a.merge(b,on='seed',suffixes=('_dpcast','_control'),validate='one_to_one')
            if len(matched) and (matched.partition_hash_dpcast!=matched.partition_hash_control).any():
                raise RuntimeError('Paired inference attempted on unmatched partitions')
            d=(matched.mean_head_ap_dpcast-matched.mean_head_ap_control).to_numpy()
            result=paired_interval(d,keyed_rng(971,dataset,alpha,eps,method),cfg.bootstrap_reps)
            result.update(dataset=dataset,alpha=alpha,epsilon_target=eps,comparison='dpcast - '+method,
                comparison_family='diagnostic' if method in ['raw_context','nonprivate'] else 'matched_cap_private',
                complete_pairs=len(matched)==len(cfg.seeds),
                interpretation='conditional training/partition variability on fixed benchmark test cohort')
            margin=cfg.noninferiority_margin
            result['noninferiority_margin']=margin
            result['noninferiority_descriptive_pass']=(bool(result['ci_low']>-margin)
                if margin is not None and np.isfinite(result['ci_low']) and len(d)>=5 else None)
            pairs.append(result)
            pd.DataFrame(dict(seed=matched.seed,paired_ap_difference=d)).to_csv(
                out/f'paired_{dataset}_alpha{alpha}_eps{eps}_{method}.csv',index=False)
    pairdf=pd.DataFrame(pairs)
    if len(pairdf):
        pairdf['holm_p']=np.nan
        # One family across all requested datasets, alpha levels, budgets and private controls.
        mask=pairdf.comparison_family=='matched_cap_private'
        pairdf.loc[mask,'holm_p']=holm(pairdf.loc[mask,'p_value'])
        pairdf.to_csv(out/'paired_effects.csv',index=False)
    if context: pd.DataFrame(context).to_csv(out/'context_diagnostics.csv',index=False)
    save_json(out/'analysis_audit.json',dict(runs=len(records),prediction_checks=source_integrity,
        primary_endpoint='arithmetic mean of personalised-head non-interpolated positive-class AP',
        independent_unit='training/partition seed within dataset, heterogeneity, budget; fixed common test cohort',
        interval='95% paired Student t; percentile bootstrap supplied as sensitivity analysis',
        pvalues='paired sign-flip, exact through 16 seeds; Holm across private primary comparisons',
        caveats=['Small-seed intervals can be wide or unstable.','No head-level pseudo-replication.',
        'Repeated seeds do not create independent patient cohorts.','Non-inferiority check is descriptive, not multiplicity-adjusted.',
        'Do not pool heterogeneity settings as independent seeds.','Matched configured bound is not equal realised spend.']))
    make_figures(root,out,df,summary)
    # Simple LaTeX supplementary table, generated from the computed CSV.
    cols=['dataset','alpha','epsilon_target','method','mean_head_ap','n_seeds','ci_low','ci_high']
    lines=['\\begin{tabular}{llrlrrrr}','Dataset & Alpha & $\\epsilon$ & Method & Mean AP & Seeds & CI low & CI high \\\\', '\\hline']
    for _,r in summary[cols].iterrows():
        vals=[str(r[c]).replace('_','\\_') if c in ['dataset','method'] else
              str(int(r[c])) if c=='n_seeds' else f'{r[c]:.4f}' for c in cols]
        lines.append(' & '.join(vals)+' \\\\')
    lines.append('\\end{tabular}'); (out/'results_table.tex').write_text('\n'.join(lines))
    return dict(evaluated_runs=len(records),summary=str(out/'summary_by_heterogeneity.csv'))

def make_figures(root,out,df,summary):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    for dataset,g in summary.groupby('dataset'):
        alphas=sorted(g.alpha.unique()); fig,axes=plt.subplots(1,len(alphas),figsize=(4*len(alphas),3.5),squeeze=False)
        for ax,alpha in zip(axes[0],alphas):
            for method,m in g[g.alpha==alpha].groupby('method'):
                m=m.sort_values('epsilon_target')
                ax.plot(m.epsilon_target,m.mean_head_ap,marker='o',label=method)
                if m.ci_low.notna().all():
                    ax.fill_between(m.epsilon_target.to_numpy(float),m.ci_low.to_numpy(float),
                                    m.ci_high.to_numpy(float),alpha=.10)
            ax.set(xlabel='Configured epsilon bound',ylabel='Mean personalised-head AP',title=f'alpha = {alpha}',ylim=(0,1))
            ax.grid(alpha=.2)
        handles,labels=axes[0,0].get_legend_handles_labels(); fig.legend(handles,labels,loc='lower center',ncol=4,fontsize=7)
        fig.suptitle(dataset); fig.tight_layout(rect=(0,.17,1,.95))
        fig.savefig(out/f'privacy_utility_{dataset}.pdf'); fig.savefig(out/f'privacy_utility_{dataset}.png',dpi=180); plt.close(fig)
    # Average round trajectories within EACH dataset/alpha/epsilon, never pooling strata.
    trajectories=[]; rewards=[]
    for f in sorted((root/'runs').glob('*/training_summary.json')):
        s=json.loads(f.read_text()); r=pd.read_csv(f.parent/'rounds.csv')
        for key in ['dataset','method','alpha','epsilon_target','seed']: r[key]=s[key]
        trajectories.append(r)
        q=pd.read_csv(f.parent/'controller_learning.csv')
        for key in ['dataset','method','alpha','epsilon_target','seed']: q[key]=s[key]
        rewards.append(q)
    if trajectories: pd.concat(trajectories).to_csv(out/'round_trajectories.csv',index=False)
    if rewards: pd.concat(rewards).to_csv(out/'controller_trajectories.csv',index=False)
    if rewards:
        allreward=pd.concat(rewards)
        for (dataset,alpha,eps),g in allreward.groupby(['dataset','alpha','epsilon_target']):
            fig,axes=plt.subplots(1,3,figsize=(11,3.3))
            for method,m in g.groupby('method'):
                z=m.groupby('round').mean(numeric_only=True)
                axes[0].plot(z.index+1,z.reward,label=method)
                if z.q_loss.notna().any(): axes[1].plot(z.index+1,z.q_loss,label=method)
                axes[2].plot(z.index+1,z.trained_frozen_greedy_disagreement,label=method)
            for ax,label in zip(axes,['Protected reward','Double-DQN Huber loss','Trained/frozen disagreement']):
                ax.set(xlabel='Round',ylabel=label); ax.grid(alpha=.2)
            axes[0].legend(fontsize=5,ncol=2); fig.suptitle(f'{dataset}; alpha={alpha}; epsilon={eps}')
            fig.tight_layout(); fig.savefig(out/f'controller_{dataset}_{alpha}_{eps}.pdf'); plt.close(fig)
    if trajectories:
        allrounds=pd.concat(trajectories)
        for (dataset,alpha,eps),g in allrounds.groupby(['dataset','alpha','epsilon_target']):
            fig,ax=plt.subplots(figsize=(6,3.5))
            for method,m in g.groupby('method'):
                z=m.groupby('round').validation_mean_head_ap.mean(); ax.plot(z.index+1,z.values,label=method)
            ax.set(xlabel='Round',ylabel='Public validation mean head AP',title=f'{dataset}; alpha={alpha}; epsilon={eps}')
            ax.legend(fontsize=6,ncol=3); fig.tight_layout(); fig.savefig(out/f'validation_{dataset}_{alpha}_{eps}.pdf'); plt.close(fig)

