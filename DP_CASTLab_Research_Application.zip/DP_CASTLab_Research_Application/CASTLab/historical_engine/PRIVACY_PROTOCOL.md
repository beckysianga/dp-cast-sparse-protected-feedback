# DP CAST conditional privacy protocol

## Protected unit and observer

Fix K enrolled client identities, their disjoint memberships, a public participation schedule, public reference/test data, feature schema, model architecture, horizon, configuration and initial public model. Neighbouring inputs replace **all** local training and evaluation records of one client, while all other clients' records and the public information stay fixed. Local hidden state may be an arbitrary function of that client's data and the transcript. This is a whole-client replacement claim conditional on fixed membership, not privacy of the benchmark's partition-construction process.

The server observes released client messages, its own actions and policy state, aggregate/model parameters, protected head proxies, public-reference/test predictions and protected local evaluation vectors. The server does not observe client memory, raw heads, unprotected context, local class counts, unprotected local predictions, local computation time or data audit files. The simulator does not enforce those boundaries cryptographically or with processes.

## Fixed order and filter

Let epsilon_star and delta be fixed before interaction. From a public grid of orders a>1 choose the order maximising the positive capacity

`R = (epsilon_star - log(1/delta)/(a-1)) / a`.

A Gaussian mechanism with L2 sensitivity Delta and noise standard deviation s has order-a RDP cost `a * rho`, where `rho = Delta^2/(2s^2)`. Each client's filter checks `spent_rho + next_rho + reserved_rho <= R` **before** executing the next mechanism. It refuses otherwise. Cost and mechanism parameters may depend on the protected history. Mechanisms cannot access an unprotected value to set their noise scale or clip bound for that release. The controller chooses update costs only after receiving protected context. The clip used now is fixed by the prior transcript and the chosen protected action; the new clipping indicator changes the **next** round's base clip.

This directly instantiates the fixed-order filter of Lécuyer (2021), Theorem 1. No claim depends on adaptive minimisation over RDP orders after observing data. No sampling amplification is used. Remaining context/clipping costs, final evaluation cost and a minimum update cost per remaining visit are reservations, not already-executed releases.

## Sensitivity and release order

| Message or output | Bound and treatment |
| --- | --- |
| Protected five-dimensional context | Each coordinate lies in [0,1]; arbitrary replacement changes the vector by at most sqrt(5). Gaussian SD = sqrt(5)/sqrt(2 rho_context). Clipping the noisy vector to [0,1] is post-processing. |
| Four-dimensional reallocation ablation | Removed coordinate is a public constant; retained vector has sensitivity sqrt(4). Its context allocation is 4/5 of the full allocation, with the remainder moved to updates. |
| Private clipping indicator | One client's `1{norm(joint_update) <= C_base}` is in [0,1], sensitivity 1. Each client perturbs its own bit before the server sees it. This is not a raw-bit secure-aggregate mechanism. |
| Joint model update | Concatenate encoder delta and local-head delta relative to the server's head proxy; clip the **whole vector** to radius C. Replacement sensitivity is 2C. Gaussian SD = 2C/sqrt(2 rho_update). A second public norm projection is post-processing. |
| Server aggregation and optional extra Gaussian noise | Functions only of already protected updates. Zero additional privacy cost for this server observer; no independent central mechanism claim. |
| Validation feedback and reward | Evaluate released encoder/head proxies on fixed public reference records. Compute reward from those scores, charged public costs, and protected context. Post-processing. |
| Private local evaluation | Six metrics in [0,1] plus six validity bits. Undefined scores mapped internally to zero and paired with validity 0. The 12-vector has sensitivity at most sqrt(12). Add one Gaussian vector; no raw validity flags are released. |
| Common-test predictions and metrics | Functions of released encoder/head proxies and fixed public records. Post-processing. |
| Policy, replay, proposed/executed actions | Functions of protected history and independent/public randomness. Post-processing. |
| Constant/noise-only information control | Independent of client data. Conservatively charged the same context reservation for resource matching. Actual query cost is zero; charging more is safe. |
| Raw-context reference | Exposes unprotected context; no end-to-end privacy claim, even if hypothetical allocation is recorded. |

For each nonempty round:

1. Before any release, check affordability of current context, current clipping indicator, a feasible current update, all remaining auxiliary costs, minimum future updates and final local evaluation.
2. Train locally with the public encoder and the retained local raw head. Construct bounded raw context inside the client.
3. Release protected context after charging its checked cost.
4. Release the protected clipping bit after its own checked charge. It cannot change the current update's pre-established base clip.
5. Build state from protected context, public time, the charged fraction and public validation AP of released models. Compute feasible actions. Complete a prior replay transition using its **executed** action.
6. Choose an action from the feasible set; check again. Release the jointly clipped and perturbed encoder/head update. Keep the raw head locally. The server updates the protected head proxy and aggregates encoder messages.
7. Use protected clipping bits to update the next base clip. Compute feedback from released models and public reference records. Store the reward with the executed action. Train the controller using Double-DQN targets and feasible next-action masks.
8. Empty rounds release no client query. At the fixed end, charge/release each client's reserved local evaluation vector. Subsequent common-test evaluation uses released models only.

## Conditional proposition

Under ideal independent Gaussian sampling, fixed public conditioning information, disjoint clients, the stated observer, correct enforcement of the filter, and the absence of the excluded raw diagnostic channels, the designated server-visible transcript for one private run is `(epsilon_star, delta)` differentially private under replacement of one enrolled client's local dataset.

**Argument.** Fix neighbouring inputs that differ at client j. Conditional on the previous transcript, context has the stated bounded diameter, the clipping bit has diameter one, the clipped joint update has diameter 2C, and the bounded local evaluation vector has diameter sqrt(12). All their Gaussian costs are at most `a*rho` at the order chosen before interaction. Their choices and costs depend only on previously released protected information and public settings. Client j's fixed-order filter enforces a pathwise sum of costs at most `a*R`; therefore the adaptive interaction is `(a,a*R)`-RDP by the fixed-order filter theorem. Other clients' raw datasets stay fixed and their dependence on client j is only through the transcript; all subsequent aggregation, model evaluation on fixed public data and controller computation are post-processing of this interaction. RDP conversion gives `(a*R+log(1/delta)/(a-1),delta) = (epsilon_star,delta)`. The claim holds for each possible replaced client, so the system bound uses the common cap; it does not sum all K client ledgers when only one client changes.

This is an application of existing composition theory, not a novel theorem. The argument should receive independent specialist review before a journal makes a formal claim. A proof of the abstract Gaussian protocol is not certification of the NumPy floating-point implementation or the single-process simulator.

## What the ledger does not establish

- A realised adaptive sum is **not** automatically a valid smaller end-to-end epsilon. Report the predeclared filter cap as the guarantee and rho spend as a diagnostic. Do not sum component epsilon values.
- Published/reconstructible DP noise seeds defeat the protected-release interpretation. Reproducible benchmark noise mode is labelled accordingly.
- The raw-context/nonprivate controls, private-state memory, full benchmark diagnostic archive, data-dependent benchmark partitions, audit hashes of sensitive inputs, real-time communication side channels and publication across repeated private-data experiments are outside this proposition.
- The public reference and common test cohorts must remain fixed when one client is replaced. Calling a pooled private validation set “public” does not meet that condition.
- Protected common-test head proxies and raw local heads are different evaluated objects. Strong local performance does not imply that releasing the raw local head is safe.
- Eight whole-client-protected participants, a high-dimensional neural update and repeated context releases can impose severe utility loss. The software must report it honestly, rather than shrink sensitivities without justification.

## Sources

- I. Mironov. Renyi Differential Privacy. IEEE CSF, 2017. https://arxiv.org/abs/1702.07476
- M. Lécuyer. Practical Privacy Filters and Odometers with Renyi Differential Privacy and Applications to Differentially Private Deep Learning. 2021. Theorem 1, fixed-order filter. https://arxiv.org/abs/2103.01379
- G. Andrew, O. Thakkar, H. B. McMahan and S. Ramaswamy. Differentially Private Learning with Adaptive Clipping. NeurIPS, 2021. https://arxiv.org/abs/1905.03871

