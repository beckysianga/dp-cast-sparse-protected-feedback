"""Federated protocol and evaluation. Raw client state never enters server logs.

Benchmark-only diagnostics are deliberately separate, with no privacy claim.
All protocol messages are explicit Gaussian releases or their post-processing.
"""
from __future__ import annotations
import math
import time
import secrets
from pathlib import Path
import numpy as np
import pandas as pd
from core import (ACTIONS, DEFAULT_ACTION, CONTEXT_NAMES, METRIC_NAMES, PrivacyFilter,
    MLP, DoubleDQN, keyed_rng, project_l2, make_context, metrics, average_metrics,
    method_spec, save_json, digest)

def allocations(cfg, spec, capacity):
    ctx=cfg.context_fraction if spec['context']!='none' else 0.
    clp=cfg.clip_fraction if spec['adaptive'] else 0.
    if spec['reallocate']:
        ctx = ctx*.8 if spec['drop'] is not None else 0.
    ev=cfg.evaluation_fraction
    return dict(context=capacity*ctx,clipping=capacity*clp,evaluation=capacity*ev,
                update=capacity*(1-ctx-clp-ev))

def action_costs(update_budget, spent_update, remaining):
    if remaining < 1: return np.full(len(ACTIONS),np.inf)
    # Adaptively spend around the remaining average, while retaining a predeclared
    # minimum per future visit. The filter, not this schedule, enforces the bound.
    average=max(0.,update_budget-spent_update)/remaining
    return np.array([factor*average for factor,_ in ACTIONS])

def select_action(kind, state, mask, dqn, epsilon, rng):
    feasible=np.flatnonzero(mask)
    if not len(feasible): return None
    if kind=='fixed':
        return DEFAULT_ACTION if mask[DEFAULT_ACTION] else int(feasible[np.argmin(abs(feasible-DEFAULT_ACTION))])
    if kind=='random' or (kind in ['trained','frozen'] and rng.random()<epsilon):
        return int(rng.choice(feasible))
    if kind=='rule':
        # Same 15 feasible actions as the learned/random/frozen policies.
        level=min(4,int(np.floor(5*np.clip(.5*state[0]+.5*state[2],0,.999999))))
        clip_level=min(2,int(np.floor(3*np.clip(state[1],0,.999999))))
        proposed=level*3+clip_level
        return proposed if mask[proposed] else int(feasible[np.argmin(abs(feasible-proposed))])
    return dqn.greedy(state,mask,dqn.frozen if kind=='frozen' else dqn.q)

def epsilon_exploration(cfg, round_id):
    frac=min(1.,round_id/max(1.,cfg.rounds*cfg.exploration_decay_fraction))
    return cfg.exploration_start+(cfg.exploration_end-cfg.exploration_start)*frac

def server_models(template, encoder, heads, cut):
    models=[]
    for head in heads:
        m=template.copy(); m.set_vector(encoder,stop=cut); m.set_vector(head,start=cut); models.append(m)
    return models

def public_scores(template, encoder, heads, cut, prepared, idx):
    preds=np.stack([m.predict(prepared.x[idx]) for m in server_models(template,encoder,heads,cut)])
    rows=[metrics(prepared.y[idx],p) for p in preds]
    return average_metrics(rows),rows,preds

def train(prepared,cfg,method,seed,alpha,epsilon,out):
    started=time.perf_counter(); out=Path(out); out.mkdir(parents=True,exist_ok=True)
    spec=method_spec(method)
    if not cfg.benchmark_diagnostics and (not spec['private'] or spec['context']=='raw'):
        raise ValueError('Raw-context/nonprivate controls require benchmark_diagnostics=True.')
    k=cfg.clients; schedule=keyed_rng(seed,prepared.name,alpha,'participation').random((cfg.rounds,k))<cfg.participation
    # Empty rounds remain empty. No forced participant and no amplification claim.
    counts=schedule.sum(axis=0)
    template=MLP([prepared.x.shape[1],*cfg.encoder_dims,cfg.head_hidden,1],
                 keyed_rng(seed,prepared.name,'model_init'),cfg.dropout,range(min(2,len(cfg.encoder_dims))))
    cut=2*len(cfg.encoder_dims)
    encoder=template.vector(stop=cut); heads=[template.vector(start=cut).copy() for _ in range(k)]
    raw_heads=[h.copy() for h in heads]; previous_means=[None]*k
    previous_aggregate=np.zeros_like(encoder)
    previous_context=np.zeros((k,5)); clip_base=cfg.clip_init
    dqn=DoubleDQN(cfg,seed); pending={}; finished=np.zeros(k,dtype=int)
    filt=PrivacyFilter(k,epsilon,cfg.delta); pools=allocations(cfg,spec,filt.capacity)
    spent_update=np.zeros(k); participation_position=np.zeros(k,dtype=int)
    # Noise roots are not saved in protected runs. Benchmark reproducibility is
    # explicit and removes any claim about those artifacts as private releases.
    noise_root=seed if cfg.reproducible_noise else secrets.randbits(128)
    def noise_rng(t,i,label): return keyed_rng(noise_root,prepared.name,method,alpha,epsilon,t,i,label)
    val=prepared.public_val
    if cfg.max_public_eval_rows is not None: val=val[:cfg.max_public_eval_rows]
    prev_val,_,_=public_scores(template,encoder,heads,cut,prepared,val)
    rounds=[]; actions=[]; contexts=[]; raw_diagnostics=[]; controller_logs=[]; clip_logs=[]; replay_log=[]
    local_final=[]; last_states=[]
    for t in range(cfg.rounds):
        round_start=time.perf_counter(); selected=np.flatnonzero(schedule[t]); before=filt.spent.copy()
        protected_updates=[]; clip_observations=[]; decision_records=[]; reward_changes=[]; risks=[]
        for i0 in selected:
            i=int(i0); total=int(counts[i]); pos=int(participation_position[i]); remaining=total-pos
            ctx_cost=pools['context']/total if total else 0.
            clip_cost=pools['clipping']/total if total else 0.
            future_min=(remaining-1)*(pools['update']/total)*.5
            all_aux=remaining*(ctx_cost+clip_cost)
            eval_reserve=pools['evaluation']
            update_options=action_costs(pools['update'],spent_update[i],remaining)
            min_update=float(update_options.min())
            if spec['private'] and not filt.feasible(i,ctx_cost+clip_cost+min_update,
                        (remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min):
                # Stop BEFORE the first message. No attempt to expose raw values.
                actions.append(dict(round=t,client=i,status='pre_release_filter_stop'))
                participation_position[i]+=1
                continue
            client=template.copy(); client.set_vector(encoder,stop=cut); client.set_vector(raw_heads[i],start=cut)
            tr=prepared.client_train[i]; x=prepared.x[tr]; y=prepared.y[tr]
            client.fit_local(x,y,cfg,keyed_rng(seed,prepared.name,alpha,t,i,'local_training'))
            de=client.vector(stop=cut)-encoder
            dh=client.vector(start=cut)-heads[i]
            joint=np.concatenate([de,dh]); raw_heads[i]=client.vector(start=cut).copy()
            raw,previous_means[i]=make_context(client,x,y,de,clip_base,previous_means[i],previous_aggregate)
            observed=np.zeros(5); before_clip=np.zeros(5); sd=0.
            reserve=clip_cost+min_update+(remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min
            if spec['context'] in ['constant','noise_only']:
                observed=np.full(5,.5)
                if ctx_cost:
                    # Conservative budget-matched information ablation: debit the
                    # same allocation despite no access to private context.
                    filt.charge(i,'context_public_control_reservation',ctx_cost,t,math.sqrt(5),reserve,False)
                if spec['context']=='noise_only':
                    nominal=ctx_cost or cfg.context_fraction*filt.capacity/max(total,1)
                    sd=math.sqrt(5)/math.sqrt(2*nominal)
                    observed=np.clip(.5+noise_rng(t,i,'context').normal(0,sd,5),0,1)
                before_clip=observed.copy()
            elif spec['context']=='raw':
                observed=raw.copy(); before_clip=raw.copy()
                # Hypothetical charge ONLY to keep update allocation matched.
                filt.charge(i,'UNPROTECTED_context_hypothetical_charge',ctx_cost,t,math.sqrt(5),reserve,False)
            elif spec['context']=='protected':
                active=np.ones(5,dtype=bool)
                if spec['drop'] is not None and spec['reallocate']: active[spec['drop']]=False
                dimension=int(active.sum()); sd=math.sqrt(dimension)/math.sqrt(2*ctx_cost)
                released=filt.release(raw[active],i,'context',ctx_cost,t,math.sqrt(dimension),
                                      noise_rng(t,i,'context'),reserve)
                observed=np.full(5,.5); before_clip=np.full(5,.5)
                before_clip[active]=released; observed[active]=np.clip(released,0,1)
                if spec['drop'] is not None: observed[spec['drop']]=.5
            if spec['adaptive']:
                bit=float(np.linalg.norm(joint)<=clip_base)
                reserved_after_clip=min_update+(remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min
                q=float(filt.release(bit,i,'clipping_indicator',clip_cost,t,1.,
                        noise_rng(t,i,'clipping'),reserved_after_clip))
                clip_observations.append(q)
                clip_logs.append(dict(round=t,client=i,protected_indicator=q,clip_base=clip_base))
            state=np.r_[observed,t/max(cfg.rounds-1,1),filt.spent[i]/filt.capacity,prev_val['mean_ap']]
            reserves=(remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min
            mask=np.array([filt.feasible(i,c,reserves) and
                c+spent_update[i]+future_min <= pools['update']+1e-12*filt.capacity
                for c in update_options]) if spec['private'] else np.ones(len(ACTIONS),bool)
            if i in pending:
                old=pending.pop(i)
                dqn.add(old['state'],old['action'],old['reward'],state,not mask.any(),mask,t-old['round'])
                replay_log.append(dict(client=i,source_round=old['round'],next_round=t,
                                       executed_action=old['action'],terminal=not mask.any()))
            exploration=epsilon_exploration(cfg,t)
            proposal=select_action(spec['controller'],state,mask,dqn,exploration,
                        keyed_rng(seed,prepared.name,alpha,t,i,'exploration'))
            if proposal is None:
                actions.append(dict(round=t,client=i,status='no_feasible_update_after_aux'))
                participation_position[i]+=1; continue
            # Recheck fallback AND its reservation. Nothing is released on refusal.
            executed=proposal
            if spec['private'] and not filt.feasible(i,update_options[executed],reserves):
                feasible=np.flatnonzero(mask)
                executed=int(feasible[np.argmin(update_options[feasible])]) if len(feasible) else None
                if executed is None or not filt.feasible(i,update_options[executed],reserves):
                    raise RuntimeError('Verified action mask and filter disagree')
            cost=float(update_options[executed]) if spec['private'] else 0.
            c=float(np.clip(clip_base*ACTIONS[executed][1],cfg.clip_min,cfg.clip_max))
            if spec['private']:
                released=filt.release(project_l2(joint,c),i,'joint_encoder_head_update',cost,t,2*c,
                                      noise_rng(t,i,'update'),reserves)
                # Public post-processing stabilizes parameter magnitudes. This
                # projection is identical across private comparison methods.
                released=project_l2(released,cfg.release_projection_radius*c)
                spent_update[i]+=cost
            else: released=joint
            protected_updates.append(released[:len(encoder)])
            heads[i]=heads[i]+released[len(encoder):]
            participation_position[i]+=1; finished[i]+=1
            reward_changes.append(abs(observed[0]-previous_context[i,0])); risks.append(observed[4])
            previous_context[i]=observed
            decision_records.append(dict(client=i,state=state,action=executed,mask=mask,round=t))
            last_states.append((state.copy(),mask.copy()))
            row=dict(round=t,client=i,status='released',proposed_action=proposal,executed_action=executed,
                rho_factor=ACTIONS[executed][0],clip_multiplier=ACTIONS[executed][1],clip=c,
                update_rho=cost,remaining_visits=remaining,exploration=exploration,
                controller_updates_before_decision=dqn.updates,
                greedy_trained=dqn.greedy(state,mask),greedy_frozen=dqn.greedy(state,mask,dqn.frozen))
            actions.append(row)
            for j,label in enumerate(CONTEXT_NAMES):
                contexts.append(dict(round=t,client=i,coordinate=label,observed=float(observed[j]),
                    boundary=float(observed[j] in [0.,1.]),noise_sd=sd,
                    masked=spec['drop']==j,context_mode=spec['context']))
            if cfg.benchmark_diagnostics:
                raw_state=state.copy(); raw_state[:5]=raw
                raw_action=dqn.greedy(raw_state,mask)
                for j,label in enumerate(CONTEXT_NAMES):
                    raw_diagnostics.append(dict(round=t,client=i,coordinate=label,raw=float(raw[j]),
                        protected=float(observed[j]),absolute_error=float(abs(observed[j]-raw[j])),
                        pre_clip=float(before_clip[j]),same_policy_raw_action=raw_action,
                        same_policy_protected_action=dqn.greedy(state,mask),
                        action_changed=raw_action!=dqn.greedy(state,mask)))
        if protected_updates:
            aggregate=np.mean(protected_updates,axis=0)
            if spec['private'] and cfg.central_postprocess_sigma:
                # The server already sees every protected message. This is ONLY
                # post-processing; it adds no extra server-privacy guarantee/cost.
                aggregate+=noise_rng(t,-1,'central_postprocess').normal(0,
                    cfg.central_postprocess_sigma*2*cfg.clip_max/len(protected_updates),len(encoder))
                aggregate=project_l2(aggregate,cfg.release_projection_radius*cfg.clip_max)
            encoder+=cfg.server_lr*aggregate; previous_aggregate=aggregate
        if clip_observations:
            fraction=float(np.clip(np.mean(clip_observations),0,1))
            clip_base=float(np.clip(clip_base*np.exp(cfg.clip_lr*(cfg.clip_quantile-fraction)),
                                    cfg.clip_min,cfg.clip_max))
        current,_,_=public_scores(template,encoder,heads,cut,prepared,val)
        gain=float(np.clip((current['mean_ap']-prev_val['mean_ap'])/cfg.gain_scale,-1,1))
        priv=float(np.mean(filt.spent-before)/filt.capacity)
        change=float(np.mean(reward_changes)) if reward_changes else 0.
        risk=float(np.mean(risks)) if risks else 0.
        recall_drop=max(0.,prev_val['mean_recall']-current['mean_recall'])
        reward=float(np.clip(cfg.reward_gain_weight*gain-cfg.reward_privacy_weight*priv
            -cfg.reward_change_weight*change-cfg.reward_recall_weight*recall_drop-cfg.reward_risk_weight*risk,-1,1))
        for rec in decision_records:
            i=rec['client']; pending[i]=dict(state=rec['state'],action=rec['action'],reward=reward,round=t)
        losses=[]; probes=last_states[-128:]
        before_actions=[dqn.greedy(s,m) for s,m in probes]
        if spec['controller']=='trained':
            for _ in range(cfg.rl_updates_per_round):
                loss=dqn.learn()
                if loss is not None: losses.append(loss)
        after_actions=[dqn.greedy(s,m) for s,m in probes]
        frozen_actions=[dqn.greedy(s,m,dqn.frozen) for s,m in probes]
        controller_logs.append(dict(round=t,updates=dqn.updates,buffer_size=len(dqn.memory),
            q_loss=float(np.mean(losses)) if losses else None,
            same_state_before_after_disagreement=float(np.mean(np.array(before_actions)!=np.array(after_actions))) if probes else None,
            trained_frozen_greedy_disagreement=float(np.mean(np.array(after_actions)!=np.array(frozen_actions))) if probes else None,
            exploration=epsilon_exploration(cfg,t),reward=reward,
            reward_gain=gain,reward_privacy=priv,reward_context_change=change,
            reward_recall_drop=recall_drop,reward_risk=risk))
        rounds.append(dict(round=t,selected=len(selected),released=len(protected_updates),
            validation_mean_head_ap=current['mean_ap'],validation_recall=current['mean_recall'],
            max_charged_rho=float(filt.spent.max()),rho_capacity=filt.capacity,epsilon_cap=epsilon,
            clip_base=clip_base,seconds=time.perf_counter()-round_start))
        prev_val=current
    for i,old in pending.items():
        dqn.add(old['state'],old['action'],old['reward'],old['state'],True,np.zeros(len(ACTIONS),bool))
        replay_log.append(dict(client=i,source_round=old['round'],next_round=cfg.rounds,
                               executed_action=old['action'],terminal=True))
    # Terminal transitions are archived; no extra terminal-only learning is used
    # to claim influence over decisions that have already happened.
    for i in range(k):
        local=template.copy(); local.set_vector(encoder,stop=cut); local.set_vector(raw_heads[i],start=cut)
        te=prepared.client_test[i]; local_p=local.predict(prepared.x[te]); row=metrics(prepared.y[te],local_p)
        local_final.append(dict(client=i,**row))
        vals=np.array([row[m] for m in METRIC_NAMES]); valid=np.isfinite(vals).astype(float)
        bounded=np.r_[np.nan_to_num(vals,nan=0.),valid]
        if spec['private']:
            noisy=filt.release(bounded,i,'local_evaluation',pools['evaluation'],cfg.rounds,
                               math.sqrt(len(bounded)),noise_rng(cfg.rounds,i,'local_eval'))
            save_json(out/f'client_{i}_protected_local_metrics.json',dict(metric_names=METRIC_NAMES,
                noisy_scores=noisy[:len(vals)].tolist(),noisy_validity=noisy[len(vals):].tolist(),
                noise_sd=math.sqrt(len(bounded)/(2*pools['evaluation'])),
                note='Noisy scores and validity are not unbiased ratios; use raw local metrics only in public benchmark diagnostics.'))
        if cfg.benchmark_diagnostics:
            bd=out/'BENCHMARK_ONLY_NOT_PRIVATE'; bd.mkdir(exist_ok=True)
            np.savez_compressed(bd/f'client_{i}_local_predictions.npz',indices=te,y=prepared.y[te],p=local_p)
    if cfg.benchmark_diagnostics:
        pd.DataFrame(raw_diagnostics).to_csv(out/'BENCHMARK_ONLY_NOT_PRIVATE/context_distortion.csv',index=False)
        pd.DataFrame(local_final).to_csv(out/'BENCHMARK_ONLY_NOT_PRIVATE/local_metrics.csv',index=False)
        save_json(out/'BENCHMARK_ONLY_NOT_PRIVATE/README.json',dict(
            warning='These raw contexts, local scores and labels are NOT private releases. Public benchmark research only.'))
    np.savez_compressed(out/'released_model.npz',encoder=encoder,heads=np.stack(heads),dims=template.dims)
    np.savez_compressed(out/'controller.npz',online=dqn.q.vector(),target=dqn.target.vector(),initial=dqn.frozen.vector())
    # Store complete, protected replay transitions without any raw context.
    replay_arrays={}
    if dqn.memory:
        fields=['state','executed_action','reward','next_state','done','next_mask','gap']
        replay_arrays={name:np.asarray([r[j] for r in dqn.memory]) for j,name in enumerate(fields)}
    np.savez_compressed(out/'protected_replay.npz',**replay_arrays)
    for filename,table in [('rounds',rounds),('actions',actions),('protected_context',contexts),
                           ('controller_learning',controller_logs),('private_clipping',clip_logs),
                           ('ledger',filt.events),('replay_index',replay_log)]:
        pd.DataFrame(table).to_csv(out/(filename+'.csv'),index=False)
    protocol_eligible=spec['private'] and spec['context']!='raw' and not cfg.reproducible_noise
    cert=filt.certificate(); cert.update(protocol_eligible=protocol_eligible,
        artifact_bundle_is_private=False,
        bundle_scope_note='Benchmark preparation/provenance is outside the protocol claim even when raw diagnostics are suppressed.',
        protocol_scope='ideal Gaussian, fixed enrollment/client-replacement, fixed public data and partitions; no systems certification',
        noise_seeds_published=cfg.reproducible_noise,
        central_noise_is_postprocessing=True,raw_personal_heads_released=False,
        raw_context_diagnostic=spec['context']=='raw',allocation=pools)
    save_json(out/'privacy_certificate.json',cert)
    summary=dict(dataset=prepared.name,method=method,seed=seed,alpha=alpha,epsilon_target=epsilon,
        delta=cfg.delta,training_rounds=cfg.rounds,partition_hash=prepared.partition_hash,
        common_test_evaluated=False,validation_mean_head_ap=prev_val['mean_ap'],
        controller_updates=dqn.updates,transitions=len(dqn.memory),
        decisions_after_first_update=sum(r.get('controller_updates_before_decision',0)>0 for r in actions),
        executed_releases=int(finished.sum()),empty_rounds=int(np.sum(schedule.sum(axis=1)==0)),
        min_client_releases=int(finished.min()),max_client_releases=int(finished.max()),
        rho_capacity=filt.capacity,max_recorded_rho=float(filt.spent.max()),
        protocol_eligible=protocol_eligible,seconds=time.perf_counter()-started)
    if cfg.benchmark_diagnostics:
        summary.update({'benchmark_local_'+key:value for key,value in average_metrics(local_final).items()})
    save_json(out/'training_summary.json',summary)
    return summary

def evaluate_common_test(prepared,cfg,out):
    """Only called by explicit evaluate command after the protocol has been locked."""
    out=Path(out); model=np.load(out/'released_model.npz',allow_pickle=False)
    template=MLP(model['dims'].tolist(),keyed_rng(0,'evaluation')); cut=2*len(cfg.encoder_dims)
    mean,rows,preds=public_scores(template,model['encoder'],list(model['heads']),cut,prepared,prepared.public_test)
    np.savez_compressed(out/'public_test_predictions.npz',indices=prepared.public_test,
                        y=prepared.y[prepared.public_test],probabilities=preds)
    pd.DataFrame([dict(client=i,**row) for i,row in enumerate(rows)]).to_csv(out/'common_test_head_metrics.csv',index=False)
    summary=dict(mean_head_ap=mean['mean_ap'],worst_head_ap=mean['worst_head_ap'],
                 head_ap_dispersion=mean['head_ap_dispersion'],common_test_evaluated=True,
                 **{'common_'+k:v for k,v in mean.items()})
    save_json(out/'common_test_summary.json',summary)
    return summary

