# Executed validation evidence

Validation completed on 11 October 2026. These are software checks, not publication experiments or evidence of a utility advantage.

- **19 automated correctness tests passed.** They cover AP ties, constant-score AP, undefined metrics, Gaussian calibration, replacement sensitivities, pre-release refusal, future reservations, focal-loss gradients, network gradients, Double-DQN updates, feasible actions, target mappings, preprocessing, partition disjointness, paired inference, replay action labels, absent test-set outputs during training and empty participation rounds.
- **14 synthetic control runs completed**, with train, final evaluation and analysis. Eight rounds, four clients, one seed, reduced network, explicitly synthetic observations. This exercises nonprivate, fixed, private adaptive clipping, rule, random, frozen, trained, constant, noise-only, reallocation, coordinate removal and raw-context diagnostic branches.
- **Eight real-data validation runs completed**: fixed and DP-CAST on each of CDC Diabetes, Cervical Cancer, Glioma and SUPPORT2. Eight rounds, eight clients, one seed, alpha 0.5, epsilon cap 8 and delta 1e-5. The original 128–64–32 encoder and 32–1 head were used. CDC and SUPPORT2 were capped at 2,000 records; Cervical retained 858 and Glioma retained 839. These caps are prohibited by the publication configuration.
- The real-data runs downloaded and parsed all four official UCI sources. The audit recorded target meaning, retained features, exclusions, missingness, prevalence and all split/client sizes.
- Archived predictions were used to recompute every final common-test AP. All recomputed values agreed with saved summaries.
- Every completed run's ledger stayed within its configured fixed-order capacity, up to floating-point tolerance. Final evaluation costs were included.
- Exact source hashes in the delivered validation runs match the delivered six executable modules.
- The embedded Colab launcher was executed end to end with its synthetic smoke profile through ZIP creation. Subsequent final source embedding was checked byte-for-byte against all 23 project files; the notebook and single-cell script contain identical code and compile successfully.
- Generated figures were inspected. The AP axis uses the full 0–1 scale; one-seed smoke figures should not be interpreted as privacy–utility findings.

The full five-seed publication matrix (1,260 runs), context/control matrix, allocation sweep and horizon-development experiments have **not** been executed. No confidence, superiority, non-inferiority, novelty or clinical-deployment conclusion is established by this validation.

## Evidence paths

- `validation/correctness_tests.txt`
- `validation/delivery_synthetic/`: complete saved predictions, ledgers, logs, source snapshots, analysis and figures for the 14 synthetic checks.
- `validation/delivery_real/`: equivalent evidence for the eight real-data checks.
- `validation/colab_launcher_check.txt`: executed launcher smoke log. This preceded final metadata/plot presentation refinements; the exact final embedding was separately validated.
- `requirements-tested.txt`: installed package versions used for validation.

The raw benchmark diagnostic folders in these runs contain information explicitly excluded from the conditional protocol privacy claim. The full ZIP is a research artifact, not a private-data release.
