# DP-CAST corrected research implementation -- complete Colab single-cell launcher.
# All source modules and configurations are embedded below as readable text.
# Software validation does not establish a utility advantage or journal acceptance.

PROFILE = "development"  # smoke, real_data_smoke, publication, context_controls, ten_seeds
RUN_FINAL_TEST = False  # Set True only after fixing the final protocol.
DOWNLOAD_RESULTS = True
WORKDIR = None  # e.g. "/content/drive/MyDrive/DP_CAST" AFTER mounting Drive yourself.

import sys, os, json, subprocess, importlib.util
from pathlib import Path
IN_COLAB = importlib.util.find_spec("google.colab") is not None if importlib.util.find_spec("google") else False
workspace = Path(WORKDIR or ("/content/DP_CAST_Work" if IN_COLAB else str(Path.cwd()/"DP_CAST_Work")))
project = workspace/"DP_CAST_Research_Code"
project.mkdir(parents=True, exist_ok=True)
MODULES = {}

MODULES['PRIVACY_PROTOCOL.md'] = r'''# DP CAST conditional privacy protocol

## Protected unit and observer

Fix K enrolled client identities, their disjoint memberships, a public participation schedule, public reference/test data, feature schema, model architecture, horizon, configuration and initial public model. Neighbouring inputs replace **all** local training and evaluation records of one client, while all other clients' records and the public information stay fixed. Local hidden state may be an arbitrary function of that client's data and the transcript. This is a whole-client replacement claim conditional on fixed membership, not privacy of the benchmark's partition-construction process.

The server observes released client messages, its own actions and policy state, aggregate/model parameters, protected head proxies, public-reference/test predictions and protected local evaluation vectors. The server does not observe client memory, raw heads, unprotected context, local class counts, unprotected local predictions, local computation time or data audit files. The simulator does not enforce those boundaries cryptographically or with processes.

## Fixed order and filter

Let epsilon_star and delta be fixed before interaction. From a public grid of orders a>1 choose the order maximising the positive capacity

`R = (epsilon_star - log(1/delta)/(a-1)) / a`.

A Gaussian mechanism with L2 sensitivity Delta and noise standard deviation s has order-a RDP cost `a * rho`, where `rho = Delta^2/(2s^2)`. Each client's filter checks `spent_rho + next_rho + reserved_rho <= R` **before** executing the next mechanism. It refuses otherwise. Cost and mechanism parameters may depend on the protected history. Mechanisms cannot access an unprotected value to set their noise scale or clip bound for that release. The controller chooses update costs only after receiving protected context. The clip used now is fixed by the prior transcript and the chosen protected action; the new clipping indicator changes the **next** round's base clip.

This directly instantiates the fixed-order filter of Lécuyer (2021), Theorem 1. No claim depends on adaptive minimisation over RDP orders after observing data. No sampling amplification is used. Remaining context/clipping costs, final evaluation cost and a minimum update cost per remaining visit are reservations, not already-executed releases.

## Sensitivity and release order

| Message or output | Bound and treatment |
| --- | --- |
| Protected five-dimensional context | Each coordinate lies in [0,1]; arbitrary replacement changes the vector by at most sqrt(5). Gaussian SD = sqrt(5)/sqrt(2 rho_context). Clipping the noisy vector to [0,1] is post-processing. |
| Four-dimensional reallocation ablation | Removed coordinate is a public constant; retained vector has sensitivity sqrt(4). Its context allocation is 4/5 of the full allocation, with the remainder moved to updates. |
| Private clipping indicator | One client's `1{norm(joint_update) <= C_base}` is in [0,1], sensitivity 1. Each client perturbs its own bit before the server sees it. This is not a raw-bit secure-aggregate mechanism. |
| Joint model update | Concatenate encoder delta and local-head delta relative to the server's head proxy; clip the **whole vector** to radius C. Replacement sensitivity is 2C. Gaussian SD = 2C/sqrt(2 rho_update). A second public norm projection is post-processing. |
| Server aggregation and optional extra Gaussian noise | Functions only of already protected updates. Zero additional privacy cost for this server observer; no independent central mechanism claim. |
| Validation feedback and reward | Evaluate released encoder/head proxies on fixed public reference records. Compute reward from those scores, charged public costs, and protected context. Post-processing. |
| Private local evaluation | Six metrics in [0,1] plus six validity bits. Undefined scores mapped internally to zero and paired with validity 0. The 12-vector has sensitivity at most sqrt(12). Add one Gaussian vector; no raw validity flags are released. |
| Common-test predictions and metrics | Functions of released encoder/head proxies and fixed public records. Post-processing. |
| Policy, replay, proposed/executed actions | Functions of protected history and independent/public randomness. Post-processing. |
| Constant/noise-only information control | Independent of client data. Conservatively charged the same context reservation for resource matching. Actual query cost is zero; charging more is safe. |
| Raw-context reference | Exposes unprotected context; no end-to-end privacy claim, even if hypothetical allocation is recorded. |

For each nonempty round:

1. Before any release, check affordability of current context, current clipping indicator, a feasible current update, all remaining auxiliary costs, minimum future updates and final local evaluation.
2. Train locally with the public encoder and the retained local raw head. Construct bounded raw context inside the client.
3. Release protected context after charging its checked cost.
4. Release the protected clipping bit after its own checked charge. It cannot change the current update's pre-established base clip.
5. Build state from protected context, public time, the charged fraction and public validation AP of released models. Compute feasible actions. Complete a prior replay transition using its **executed** action.
6. Choose an action from the feasible set; check again. Release the jointly clipped and perturbed encoder/head update. Keep the raw head locally. The server updates the protected head proxy and aggregates encoder messages.
7. Use protected clipping bits to update the next base clip. Compute feedback from released models and public reference records. Store the reward with the executed action. Train the controller using Double-DQN targets and feasible next-action masks.
8. Empty rounds release no client query. At the fixed end, charge/release each client's reserved local evaluation vector. Subsequent common-test evaluation uses released models only.

## Conditional proposition

Under ideal independent Gaussian sampling, fixed public conditioning information, disjoint clients, the stated observer, correct enforcement of the filter, and the absence of the excluded raw diagnostic channels, the designated server-visible transcript for one private run is `(epsilon_star, delta)` differentially private under replacement of one enrolled client's local dataset.

**Argument.** Fix neighbouring inputs that differ at client j. Conditional on the previous transcript, context has the stated bounded diameter, the clipping bit has diameter one, the clipped joint update has diameter 2C, and the bounded local evaluation vector has diameter sqrt(12). All their Gaussian costs are at most `a*rho` at the order chosen before interaction. Their choices and costs depend only on previously released protected information and public settings. Client j's fixed-order filter enforces a pathwise sum of costs at most `a*R`; therefore the adaptive interaction is `(a,a*R)`-RDP by the fixed-order filter theorem. Other clients' raw datasets stay fixed and their dependence on client j is only through the transcript; all subsequent aggregation, model evaluation on fixed public data and controller computation are post-processing of this interaction. RDP conversion gives `(a*R+log(1/delta)/(a-1),delta) = (epsilon_star,delta)`. The claim holds for each possible replaced client, so the system bound uses the common cap; it does not sum all K client ledgers when only one client changes.

This is an application of existing composition theory, not a novel theorem. The argument should receive independent specialist review before a journal makes a formal claim. A proof of the abstract Gaussian protocol is not certification of the NumPy floating-point implementation or the single-process simulator.

## What the ledger does not establish

- A realised adaptive sum is **not** automatically a valid smaller end-to-end epsilon. Report the predeclared filter cap as the guarantee and rho spend as a diagnostic. Do not sum component epsilon values.
- Published/reconstructible DP noise seeds defeat the protected-release interpretation. Reproducible benchmark noise mode is labelled accordingly.
- The raw-context/nonprivate controls, private-state memory, full benchmark diagnostic archive, data-dependent benchmark partitions, audit hashes of sensitive inputs, real-time communication side channels and publication across repeated private-data experiments are outside this proposition.
- The public reference and common test cohorts must remain fixed when one client is replaced. Calling a pooled private validation set “public” does not meet that condition.
- Protected common-test head proxies and raw local heads are different evaluated objects. Strong local performance does not imply that releasing the raw local head is safe.
- Eight whole-client-protected participants, a high-dimensional neural update and repeated context releases can impose severe utility loss. The software must report it honestly, rather than shrink sensitivities without justification.

## Sources

- I. Mironov. Renyi Differential Privacy. IEEE CSF, 2017. https://arxiv.org/abs/1702.07476
- M. Lécuyer. Practical Privacy Filters and Odometers with Renyi Differential Privacy and Applications to Differentially Private Deep Learning. 2021. Theorem 1, fixed-order filter. https://arxiv.org/abs/2103.01379
- G. Andrew, O. Thakkar, H. B. McMahan and S. Ramaswamy. Differentially Private Learning with Adaptive Clipping. NeurIPS, 2021. https://arxiv.org/abs/1905.03871

'''

MODULES['README.md'] = r'''# DP CAST research implementation

This package implements a corrected experimental successor to the supplied DP-CAST paper and its review suggestions. It studies whether protected client context helps adaptive privacy control at a common, predeclared privacy bound. It does not reproduce the manuscript's old numerical results, certify novelty, or guarantee journal acceptance.

The implementation is a CPU NumPy reference implementation with explicit neural-network gradients and Adam. It does not need PyTorch, CUDA, an API key, or a paid service. The default model follows the manuscript: shared encoder 128–64–32, client head 32–1, dropout 0.10, focal loss alpha 0.75 and gamma 2, eight clients, Bernoulli participation 0.75, two local epochs and batch size 256. The controller is Double-DQN 8–64–32–15. Finite-difference tests check both focal-loss and network gradients.

## Start in Google Colab

Open **DP_CAST_Colab.ipynb** in Colab and run its setup/run cell. The notebook contains the source files, so you do not need to upload the ZIP. Alternatively, paste the contents of **DP_CAST_Single_Cell.py** into one Colab cell. Start with `PROFILE = "development"`. This trains four methods on Cervical Cancer for twenty rounds. `RUN_FINAL_TEST = False` leaves the common test set unevaluated.

After finalising your protocol using validation results, choose the appropriate publication configuration and a new output directory. Set `RUN_FINAL_TEST = True` only when ready to run the locked final evaluation. `DOWNLOAD_RESULTS = True` downloads a ZIP when the cell finishes. The same output directory resumes **completed runs**; an interrupted run restarts from its beginning. Set `WORKDIR` to a mounted Google Drive folder yourself if you need results to survive a Colab reset. The code does not mount an account or overwrite a different protocol.

The full main design contains **1,260 runs**: four datasets × seven methods × three heterogeneity levels × five seeds × three privacy targets. The optional ten-seed configuration contains 2,520 runs. Full runs may require substantial CPU time, especially CDC Diabetes. Benchmark the development run on your machine before scheduling the full study. GPU selection does not accelerate this NumPy implementation. The profiles marked smoke/validation are software checks, not publication evidence.

## Run locally

Use Python 3.10 or later. From this directory:

```bash
python -m pip install -r requirements.txt
python run.py test
python run.py lock --config configs/development.json --out results_development
python run.py train --config configs/development.json --out results_development
```

When the protocol is final, use a new directory and an agreed configuration:

```bash
python run.py lock --config configs/publication.json --out results_main
python run.py train --config configs/publication.json --out results_main
python run.py evaluate --config configs/publication.json --out results_main
python run.py analyze --config configs/publication.json --out results_main
python run.py package --out results_main
```

Every command verifies the locked configuration and source hashes. Changing source code or a configuration requires a new output directory. Input and partition hashes are also checked between training and evaluation. The test set remains separate from training and the controller; the `evaluate` command is the explicit evaluation gate. This is an auditable software gate, not a substitute for external preregistration or an untouched cohort.

## What changed scientifically

| Issue in the supplied paper | Implemented repair |
| --- | --- |
| AP depends on tie order | `sklearn.metrics.average_precision_score`; constant-score and permutation tests |
| Raw validation feedback from private heads | Feedback uses the released encoder and **protected head proxies** on public reference data |
| Unprotected released personalised models | Joint encoder/head update clipped once and protected before release; raw heads stay client-local |
| Raw reward terms | Reward uses public evaluation of protected models and already protected context |
| Raw cross-client median | Context uses the previous protected aggregate norm as its public reference |
| Pooled private preprocessing | Transform fitted only on the designated public reference features |
| Central ledger double-counting | Optional central noise is post-processing, assigned zero additional server privacy cost |
| Sampling mismatch | Genuine Bernoulli participation, empty rounds retained, no amplification claimed |
| Late budget checks and unchecked fallback | Fixed-order adaptive RDP filter before each message; future auxiliary costs, minimum update costs and final local evaluation reserved |
| Replay records proposal | Replay uses the actual executed action and the next feasible-action mask |
| Unequal privacy comparisons | Same epsilon cap, delta, client-replacement adjacency, observer, horizon and output scope across private methods |
| Weak learning controls | Random, frozen and rule-based policies share the same feasible 15-action set |
| No context information controls | Constant, noise-only and all five leave-one-coordinate-out variants, with distinct budget-reallocation variants |
| No controller learning evidence | Reward components, Q-loss, updates before decisions, and trained/frozen/before/after greedy decisions on identical protected states |
| Missing predictions and trajectories | Prediction arrays, controller replay, model snapshots, per-release ledger, source/configuration/data/partition hashes |
| Too few/pooled replications | Five-seed main design; optional ten; paired seed effects separately within each heterogeneity setting |

These are substantive methodology changes. Update the manuscript's algorithm, model release definition, privacy theorem, data preparation, action interpretation, reward and evaluation sections before reporting this code's results. In particular, the main common-test endpoint now measures **protected personalised-head proxies**, whereas raw local heads are assessed separately. Do not mix the old paper's results with the corrected experiments.

## Methods and action interpretation

| Method | Controller information and policy | Role |
| --- | --- | --- |
| `nonprivate` | No DP; fixed training policy | Nonprivate benchmark reference |
| `fixed` | Fixed clipping; fixed update allocation | Primary private baseline |
| `adaptive_clip` | Private clipping indicator; fixed update allocation | Private clipping baseline |
| `rule` | Protected context, deterministic rule over the same 15 actions | Policy baseline |
| `random` | Protected context, uniformly random feasible action | Learning control |
| `frozen` | Protected context, frozen initial Q-network, same exploration schedule | Learning control |
| `dpcast` | Protected context, trained Double-DQN | Proposed experimental method |
| `constant`, `noise_only` | Public constant context or independent clipped Gaussian context; same reserved context allocation | Information-removal controls |
| `constant_realloc`, `noise_only_realloc` | Same public controls; unused context allocation moved to updates | Resource-reallocation controls |
| `drop_0` … `drop_4` | One input coordinate replaced by 0.5; same allocation and perturbation for remaining coordinates | Coordinate information controls |
| `drop_0_realloc` … `drop_4_realloc` | Four-coordinate mechanism with sensitivity sqrt(4); removed coordinate's one-fifth context allocation moved to updates | Coordinate resource controls |
| `raw_context` | Raw context; same nominal resource allocation as DP-CAST | **Unprotected diagnostic**, never a privacy-equivalent comparator |

Actions are `(update rho factor, clipping multiplier)` in `{0.5, 0.75, 1, 1.5, 2} × {0.75, 1, 1.25}`. They are **not stand-alone epsilon values**. For each client, the factor applies to the average remaining update allocation per remaining participation. The filter masks infeasible choices. The rule, random, frozen and trained policies see the same 15 candidate actions. Fixed baselines intentionally use one prescribed action. Privacy adaptation is distinct from estimating mathematical sensitivity: the context's “sensitivity score” is only a feature; it never replaces the proved bound `2C`.

The exploration schedule declines from 1 to 0.05 during the first 70% of rounds. It depends on public time, not the number of successful updates. The main candidate horizon is 100 rounds, with four controller updates per round after 32 transitions. These settings are hypotheses to check using the included 30/100/200-round development configurations, not claims of convergence or optimality.

## Privacy model and output scope

Read **PRIVACY_PROTOCOL.md** for the exact conditional proposition and release sequence. The protected unit is the entire local dataset/state of one of eight fixed, enrolled clients, including its private held-out evaluation records. Adjacency replaces that client's dataset; it is not patient-level DP-SGD. The observer sees every protected client message, the model, policy and their derived scores. There is no secure aggregation, hostile-server defence, collusion analysis, communication timing protection, or process isolation.

Each private run uses a preselected Renyi order and a fixed-order adaptive RDP filter. The reported guarantee is the **configured epsilon cap**. The observed `rho` ledger is reported separately; the code does not turn a realised adaptive expenditure into a smaller certified epsilon. The accountant deliberately makes no sampling-amplification claim.

The reference implementation uses ordinary floating-point Gaussian sampling. The mathematics assumes ideal independent Gaussian noise; this package is not a hardened finite-precision DP library. Normal runs use an OS-seeded, undisclosed noise root. `reproducible_noise=true` publishes enough information to reconstruct noise and therefore marks that run as a **public benchmark simulation only**. Model/partition seeds may be public; DP noise seeds must not be disclosed for sensitive-data releases.

`benchmark_diagnostics=true` saves raw context distortion, local predictions, true local metrics, dataset counts and partitions under **BENCHMARK_ONLY_NOT_PRIVATE** labels. Those files allow research auditing on these public datasets. **The complete benchmark ZIP has no privacy guarantee.** A “protocol-eligible” entry refers only to the designated idealised protocol transcript within one run. The raw-context and nonprivate methods have no such claim. Setting diagnostics to false suppresses raw diagnostic files but does not convert this single-process benchmark loader into a clinical deployment system.

Running many methods/seeds on the same genuinely sensitive data would itself require an additional experiment-level composition analysis, including preprocessing, partition construction, model selection and all released results. A per-run epsilon is not a privacy budget for the entire study. This study uses public UCI benchmark data and states privacy conditionally for the implemented release protocol.

## Dataset semantics and leakage controls

| Dataset | Positive target | Exclusions and interpretation |
| --- | --- | --- |
| CDC Diabetes | `Diabetes_binary=1`: prediabetes or diabetes according to the UCI schema | ID and alternative target excluded; do not silently reinterpret as diabetes alone |
| Cervical Cancer | `Biopsy=1` | Other diagnostic targets and `Dx` indicators removed conservatively |
| Glioma | `Grade=1`: GBM; `0`: LGG | Case/project/diagnosis identifiers removed; clinical and mutation features, **not MRI images** |
| SUPPORT2 | `hospdead=1`: in-hospital death | Death/follow-up time, length of stay, costs, model survival scores and DNR/prognosis variables removed; **static retrospective benchmark, not a 24-hour landmark** |

The UCI API metadata resolves the current official CSV endpoint. Downloads retry three times, cache exact bytes and record SHA-256. A failed clinical download raises an error; it never substitutes synthetic observations. A local official CSV can be placed at `data_cache/<dataset>.csv`. Unknown target encodings fail closed. The explicit synthetic dataset is only for tests.

The public reference and common test splits each receive 10% using a fixed split seed shared across replications. The remaining 80% is distributed with class-wise Dirichlet allocation, then each client's pool is split locally into training and held-out data. This changes the paper's effective training fraction. Some small non-IID clients may contain one class or no records; no resampling hides that fact. Empty clients remain enrolled and send data-independent bounded messages if selected. The audit reports true sizes/class counts for public benchmark research. AP is undefined without positives; AUROC and balanced accuracy require both classes. Undefined values remain missing with validity counts and reasons.

Preprocessing learns numeric imputation/scaling and category vocabularies only from the public reference split. A fixed unknown category handles unseen values. The reference data must truly be available independently of the protected clients for the conditional privacy statement. Constructing that public split from a sensitive pooled database is not covered.

## Experiments and inference

1. Use `horizon_development_30.json`, `horizon_development_100.json` and `horizon_development_200.json` for validation-only controller development. Their seeds differ from the proposed final replication seeds. Review reward scales, Q-loss, decisions after updates and trained-versus-frozen actions.
2. Fix the horizon, clipping/projection settings, reward, feature exclusions and privacy targets before final evaluation. The code locks exact source/configuration hashes. It does not hide prior inspection of these benchmarks.
3. Run `publication.json` for the main matched-cap comparison. Five seeds are a minimum starting design, not a power guarantee. Use `ten_seeds.json` if resources and planned precision justify it.
4. Run `context_controls.json` for information and resource controls. The three `context_budget_*.json` profiles test context allocations of 5%, 15% and 30% at fixed total epsilon. Use separate output directories for each profile.
5. Set a scientifically justified AP non-inferiority margin and its written justification **before locking** if that claim is wanted. The default is `null`; no equivalence or preservation claim is generated. The reported interval-based margin check is descriptive and not multiplicity-adjusted confirmatory inference.
6. Evaluate and regenerate the tables/plots with `evaluate` and `analyze`. Report negative findings and uncertainty. Similar raw/protected controller performance alone does not establish useful learning.

The primary endpoint is arithmetic mean positive-class AP across protected personalised heads on the **same** common test distribution. Worst-head AP and head dispersion describe model variation, not demographic/clinical fairness. Local held-out raw-head scores answer a different question and are clearly marked benchmark-only. The protected local score release has substantial noise under whole-client adjacency; its noisy validity values must not be treated as true valid-client counts.

Paired differences use seed as the replication unit within each dataset, alpha and epsilon. Analyses report 95% Student t intervals, their widths and percentile bootstrap intervals as a sensitivity check. Two-sided sign-flip tests rely on symmetry/exchangeability; Holm adjustment covers all configured private comparisons against DP-CAST. The package does not pool heads or heterogeneity levels as independent replicates. Shared fixed test cohorts mean these intervals describe training/partition variability, not external-cohort uncertainty. The smoke analysis with one seed intentionally has no confidence interval.

## Output files

| Output | Purpose |
| --- | --- |
| `protocol_lock.json`, `executed_source/`, `environment*` | Exact source, configuration, package versions and study lock |
| `partitions/` | Input provenance, public transform, and explicitly labelled benchmark partition/data audits |
| `runs/*/ledger.csv` | Every charged mechanism, noise SD, sensitivity, reserve and fixed-order RDP cost |
| `rounds.csv`, `actions.csv`, `controller_learning.csv` | Validation trajectory, executed decisions, exploration, reward components, losses and learning diagnostics |
| `protected_context.csv`, `private_clipping.csv` | Released context, coordinate saturation and protected clipping messages |
| `protected_replay.npz`, `replay_index.csv`, `controller.npz` | Replay with executed actions, Q-network and target/frozen snapshots |
| `released_model.npz` | Final protected encoder and per-client head proxies; raw heads are not checkpointed |
| `client_*_protected_local_metrics.json` | Accounted, bounded local metric and validity-vector release |
| `public_test_predictions.npz`, `common_test_head_metrics.csv` | Recomputable final common-test endpoints, created only by `evaluate` |
| `BENCHMARK_ONLY_NOT_PRIVATE/` | Raw-context distortion and local prediction/metric evidence for public benchmark study |
| `analysis/` | Per-run and stratified CSVs, paired differences, intervals, LaTeX table, PDF/PNG figures and plot source data |
| `train_completion.json`, `evaluate_completion.json` | Expected/completed configuration counts |

## A defensible contribution

A potential paper can establish the cost and usefulness of **fully protected controller feedback under an explicit server-visible release protocol**, using budget-matched information-removal and reallocation controls. The fixed-order filter and Gaussian mechanisms are established methods, not new privacy theorems. Jointly protecting head proxies is an implementation correction that changes the evaluated model. The utility benefit of the controller, the best allocation and the value of each context component are open empirical questions until the complete experiments are run.

This package includes executed software-validation evidence only. A journal submission still needs the complete agreed experiment matrix, a reviewed privacy argument, a specific related-work comparison, a coherent manuscript and reproducibility disclosure. No scores or results have been invented to support publication.

'''

MODULES['REFERENCES.md'] = r'''# Technical and data sources

These primary sources informed the implementation. They do not establish priority or novelty of this package's combined protocol. The two uploaded files are the task specifications; the corrected code deliberately changes mechanisms identified as invalid or incomplete in the supplied review.

1. Ilya Mironov. **Renyi Differential Privacy**. IEEE CSF, 2017. https://arxiv.org/abs/1702.07476
2. Mathias Lécuyer. **Practical Privacy Filters and Odometers with Renyi Differential Privacy and Applications to Differentially Private Deep Learning**. 2021. https://arxiv.org/abs/2103.01379
3. Galen Andrew, Om Thakkar, H. Brendan McMahan and Swaroop Ramaswamy. **Differentially Private Learning with Adaptive Clipping**. NeurIPS, 2021. https://arxiv.org/abs/1905.03871
4. Hado van Hasselt, Arthur Guez and David Silver. **Deep Reinforcement Learning with Double Q-learning**. AAAI, 2016. https://arxiv.org/abs/1509.06461
5. Tsung-Yi Lin, Priya Goyal, Ross Girshick, Kaiming He and Piotr Dollár. **Focal Loss for Dense Object Detection**. ICCV, 2017. https://arxiv.org/abs/1708.02002
6. scikit-learn. **average_precision_score API**. Non-interpolated AP and its distinction from trapezoidal PR-AUC. https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html
7. UCI Machine Learning Repository. **CDC Diabetes Health Indicators**, dataset 891. https://archive.ics.uci.edu/dataset/891/cdc+diabetes+health+indicators ; https://doi.org/10.24432/C53919
8. K. Fernandes, J. S. Cardoso and J. Fernandes. **Cervical Cancer Risk Factors**, dataset 383. UCI, 2017. https://archive.ics.uci.edu/dataset/383/cervical+cancer+risk+factors ; https://doi.org/10.24432/C5Z310
9. E. Tasci, K. Camphausen, A. Krauze and Y. Zhuge. **Glioma Grading Clinical and Mutation Features**, dataset 759. UCI, 2022. https://archive.ics.uci.edu/dataset/759/glioma-grading-clinical-and-mutation-features-dataset ; https://doi.org/10.24432/C5R62J
10. UCI Machine Learning Repository. **SUPPORT2**, dataset 880. https://archive.ics.uci.edu/dataset/880/support2
11. Frank Harrell's HBiostat repository. **SUPPORT dataset description**. Assessment timing, outcome variables and model/prognosis feature exclusions. https://hbiostat.org/data/repo/supportdesc

Respect the datasets' source-specific licences and acknowledgement requirements. The code downloads the official data at execution; the source ZIP does not redistribute the raw CSVs.

'''

MODULES['analyze.py'] = r'''"""Rebuild results from saved predictions; seed-level paired inference only."""
from __future__ import annotations
import itertools
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from core import save_json, keyed_rng, metrics, average_metrics

def paired_interval(differences,rng,reps=10000):
    d=np.asarray(differences,float); d=d[np.isfinite(d)]; n=len(d)
    if n<2: return dict(n=n,mean=float(d.mean()) if n else np.nan,ci_low=np.nan,ci_high=np.nan,
                        ci_width=np.nan,bootstrap_low=np.nan,bootstrap_high=np.nan,p_value=np.nan)
    estimate=float(d.mean()); se=float(d.std(ddof=1)/np.sqrt(n)); critical=float(student_t.ppf(.975,n-1))
    lo,hi=estimate-critical*se,estimate+critical*se
    boot=d[rng.integers(n,size=(reps,n))].mean(axis=1); blo,bhi=np.quantile(boot,[.025,.975])
    # Two-sided paired sign-flip test; symmetry/exchangeability is an assumption.
    if n<=16:
        signs=np.array(list(itertools.product([-1.,1.],repeat=n)))
        p=float(np.mean(np.abs(signs@d/n)>=abs(estimate)-1e-14))
    else:
        signs=rng.choice([-1.,1.],size=(reps,n))
        p=float((1+np.sum(np.abs(signs@d/n)>=abs(estimate)-1e-14))/(reps+1))
    return dict(n=n,mean=estimate,ci_low=lo,ci_high=hi,ci_width=hi-lo,
                bootstrap_low=float(blo),bootstrap_high=float(bhi),p_value=p)

def holm(pvalues):
    p=np.asarray(pvalues,float); result=np.full(len(p),np.nan); valid=np.flatnonzero(np.isfinite(p))
    ordered=valid[np.argsort(p[valid])]; previous=0.
    for rank,index in enumerate(ordered):
        previous=max(previous,min(1.,(len(ordered)-rank)*p[index])); result[index]=previous
    return result

def analyze(root,cfg):
    root=Path(root); records=[]; context=[]; source_integrity=[]
    for f in sorted((root/'runs').glob('*/training_summary.json')):
        row=json.loads(f.read_text()); folder=f.parent
        if not (folder/'common_test_summary.json').exists(): continue
        row.update(json.loads((folder/'common_test_summary.json').read_text()))
        # Recompute the central AP endpoint directly from archived predictions.
        pred=np.load(folder/'public_test_predictions.npz',allow_pickle=False)
        recalculated=average_metrics([metrics(pred['y'],p) for p in pred['probabilities']])
        if not np.isclose(row['mean_head_ap'],recalculated['mean_ap'],atol=1e-12):
            raise RuntimeError(f'Prediction/summary mismatch in {folder.name}')
        records.append(row); source_integrity.append(dict(run=folder.name,predictions_recomputed=True))
        ctx_file=folder/'BENCHMARK_ONLY_NOT_PRIVATE/context_distortion.csv'
        if ctx_file.exists() and ctx_file.stat().st_size>5:
            df=pd.read_csv(ctx_file)
            for coordinate,g in df.groupby('coordinate'):
                context.append(dict(dataset=row['dataset'],method=row['method'],seed=row['seed'],
                    alpha=row['alpha'],epsilon_target=row['epsilon_target'],coordinate=coordinate,
                    mae=float(g.absolute_error.mean()),boundary_saturation=float(g.protected.isin([0.,1.]).mean()),
                    decision_change_rate=float(g.action_changed.mean()),n_releases=len(g)))
    if not records: raise RuntimeError('No evaluated runs. Run evaluate after train.')
    out=root/'analysis'; out.mkdir(exist_ok=True)
    df=pd.DataFrame(records); df.to_csv(out/'run_results.csv',index=False)
    keys=['dataset','alpha','epsilon_target','method']
    summary=[]
    for key,g in df.groupby(keys):
        vals=g.mean_head_ap.dropna().to_numpy(); ci=paired_interval(vals,keyed_rng(72,*key),cfg.bootstrap_reps)
        summary.append(dict(zip(keys,key),mean_head_ap=float(vals.mean()),n_seeds=len(vals),
            seed_sd=float(vals.std(ddof=1)) if len(vals)>1 else np.nan,
            ci_low=ci['ci_low'],ci_high=ci['ci_high'],ci_width=ci['ci_width'],
            worst_head_ap=float(g.worst_head_ap.mean()),head_dispersion=float(g.head_ap_dispersion.mean()),
            mean_recorded_rho=float(g.max_recorded_rho.mean()),mean_controller_updates=float(g.controller_updates.mean())))
    summary=pd.DataFrame(summary); summary.to_csv(out/'summary_by_heterogeneity.csv',index=False)
    secondary=[c for c in df if c.startswith('common_') and c!='common_test_evaluated']
    secondary += [c for c in df if c.startswith('benchmark_local_')]
    if secondary:
        df.groupby(keys)[secondary].agg(['mean','std','count']).to_csv(out/'secondary_metrics_by_heterogeneity.csv')
    pairs=[]
    # Predeclared comparisons: DP-CAST against every configured control. Raw context
    # stays in a separate diagnostic family, never a privacy-equivalent comparator.
    for (dataset,alpha,eps),g in df.groupby(['dataset','alpha','epsilon_target']):
        target=g[g.method=='dpcast']
        for method in sorted(set(g.method)-{'dpcast'}):
            a=target[['seed','mean_head_ap','partition_hash']]
            b=g[g.method==method][['seed','mean_head_ap','partition_hash']]
            matched=a.merge(b,on='seed',suffixes=('_dpcast','_control'),validate='one_to_one')
            if len(matched) and (matched.partition_hash_dpcast!=matched.partition_hash_control).any():
                raise RuntimeError('Paired inference attempted on unmatched partitions')
            d=(matched.mean_head_ap_dpcast-matched.mean_head_ap_control).to_numpy()
            result=paired_interval(d,keyed_rng(971,dataset,alpha,eps,method),cfg.bootstrap_reps)
            result.update(dataset=dataset,alpha=alpha,epsilon_target=eps,comparison='dpcast - '+method,
                comparison_family='diagnostic' if method in ['raw_context','nonprivate'] else 'matched_cap_private',
                complete_pairs=len(matched)==len(cfg.seeds),
                interpretation='conditional training/partition variability on fixed benchmark test cohort')
            margin=cfg.noninferiority_margin
            result['noninferiority_margin']=margin
            result['noninferiority_descriptive_pass']=(bool(result['ci_low']>-margin)
                if margin is not None and np.isfinite(result['ci_low']) and len(d)>=5 else None)
            pairs.append(result)
            pd.DataFrame(dict(seed=matched.seed,paired_ap_difference=d)).to_csv(
                out/f'paired_{dataset}_alpha{alpha}_eps{eps}_{method}.csv',index=False)
    pairdf=pd.DataFrame(pairs)
    if len(pairdf):
        pairdf['holm_p']=np.nan
        # One family across all requested datasets, alpha levels, budgets and private controls.
        mask=pairdf.comparison_family=='matched_cap_private'
        pairdf.loc[mask,'holm_p']=holm(pairdf.loc[mask,'p_value'])
        pairdf.to_csv(out/'paired_effects.csv',index=False)
    if context: pd.DataFrame(context).to_csv(out/'context_diagnostics.csv',index=False)
    save_json(out/'analysis_audit.json',dict(runs=len(records),prediction_checks=source_integrity,
        primary_endpoint='arithmetic mean of personalised-head non-interpolated positive-class AP',
        independent_unit='training/partition seed within dataset, heterogeneity, budget; fixed common test cohort',
        interval='95% paired Student t; percentile bootstrap supplied as sensitivity analysis',
        pvalues='paired sign-flip, exact through 16 seeds; Holm across private primary comparisons',
        caveats=['Small-seed intervals can be wide or unstable.','No head-level pseudo-replication.',
        'Repeated seeds do not create independent patient cohorts.','Non-inferiority check is descriptive, not multiplicity-adjusted.',
        'Do not pool heterogeneity settings as independent seeds.','Matched configured bound is not equal realised spend.']))
    make_figures(root,out,df,summary)
    # Simple LaTeX supplementary table, generated from the computed CSV.
    cols=['dataset','alpha','epsilon_target','method','mean_head_ap','n_seeds','ci_low','ci_high']
    lines=['\\begin{tabular}{llrlrrrr}','Dataset & Alpha & $\\epsilon$ & Method & Mean AP & Seeds & CI low & CI high \\\\', '\\hline']
    for _,r in summary[cols].iterrows():
        vals=[str(r[c]).replace('_','\\_') if c in ['dataset','method'] else
              str(int(r[c])) if c=='n_seeds' else f'{r[c]:.4f}' for c in cols]
        lines.append(' & '.join(vals)+' \\\\')
    lines.append('\\end{tabular}'); (out/'results_table.tex').write_text('\n'.join(lines))
    return dict(evaluated_runs=len(records),summary=str(out/'summary_by_heterogeneity.csv'))

def make_figures(root,out,df,summary):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
    for dataset,g in summary.groupby('dataset'):
        alphas=sorted(g.alpha.unique()); fig,axes=plt.subplots(1,len(alphas),figsize=(4*len(alphas),3.5),squeeze=False)
        for ax,alpha in zip(axes[0],alphas):
            for method,m in g[g.alpha==alpha].groupby('method'):
                m=m.sort_values('epsilon_target')
                ax.plot(m.epsilon_target,m.mean_head_ap,marker='o',label=method)
                if m.ci_low.notna().all():
                    ax.fill_between(m.epsilon_target.to_numpy(float),m.ci_low.to_numpy(float),
                                    m.ci_high.to_numpy(float),alpha=.10)
            ax.set(xlabel='Configured epsilon bound',ylabel='Mean personalised-head AP',title=f'alpha = {alpha}',ylim=(0,1))
            ax.grid(alpha=.2)
        handles,labels=axes[0,0].get_legend_handles_labels(); fig.legend(handles,labels,loc='lower center',ncol=4,fontsize=7)
        fig.suptitle(dataset); fig.tight_layout(rect=(0,.17,1,.95))
        fig.savefig(out/f'privacy_utility_{dataset}.pdf'); fig.savefig(out/f'privacy_utility_{dataset}.png',dpi=180); plt.close(fig)
    # Average round trajectories within EACH dataset/alpha/epsilon, never pooling strata.
    trajectories=[]; rewards=[]
    for f in sorted((root/'runs').glob('*/training_summary.json')):
        s=json.loads(f.read_text()); r=pd.read_csv(f.parent/'rounds.csv')
        for key in ['dataset','method','alpha','epsilon_target','seed']: r[key]=s[key]
        trajectories.append(r)
        q=pd.read_csv(f.parent/'controller_learning.csv')
        for key in ['dataset','method','alpha','epsilon_target','seed']: q[key]=s[key]
        rewards.append(q)
    if trajectories: pd.concat(trajectories).to_csv(out/'round_trajectories.csv',index=False)
    if rewards: pd.concat(rewards).to_csv(out/'controller_trajectories.csv',index=False)
    if rewards:
        allreward=pd.concat(rewards)
        for (dataset,alpha,eps),g in allreward.groupby(['dataset','alpha','epsilon_target']):
            fig,axes=plt.subplots(1,3,figsize=(11,3.3))
            for method,m in g.groupby('method'):
                z=m.groupby('round').mean(numeric_only=True)
                axes[0].plot(z.index+1,z.reward,label=method)
                if z.q_loss.notna().any(): axes[1].plot(z.index+1,z.q_loss,label=method)
                axes[2].plot(z.index+1,z.trained_frozen_greedy_disagreement,label=method)
            for ax,label in zip(axes,['Protected reward','Double-DQN Huber loss','Trained/frozen disagreement']):
                ax.set(xlabel='Round',ylabel=label); ax.grid(alpha=.2)
            axes[0].legend(fontsize=5,ncol=2); fig.suptitle(f'{dataset}; alpha={alpha}; epsilon={eps}')
            fig.tight_layout(); fig.savefig(out/f'controller_{dataset}_{alpha}_{eps}.pdf'); plt.close(fig)
    if trajectories:
        allrounds=pd.concat(trajectories)
        for (dataset,alpha,eps),g in allrounds.groupby(['dataset','alpha','epsilon_target']):
            fig,ax=plt.subplots(figsize=(6,3.5))
            for method,m in g.groupby('method'):
                z=m.groupby('round').validation_mean_head_ap.mean(); ax.plot(z.index+1,z.values,label=method)
            ax.set(xlabel='Round',ylabel='Public validation mean head AP',title=f'{dataset}; alpha={alpha}; epsilon={eps}')
            ax.legend(fontsize=6,ncol=3); fig.tight_layout(); fig.savefig(out/f'validation_{dataset}_{alpha}_{eps}.pdf'); plt.close(fig)

'''

MODULES['configs/context_budget_0.05.json'] = r'''{
  "profile": "publication",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "dpcast",
    "constant",
    "noise_only"
  ],
  "seeds": [
    42,
    52,
    62,
    72,
    82
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    4.0,
    8.0,
    16.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.05,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/context_budget_0.15.json'] = r'''{
  "profile": "publication",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "dpcast",
    "constant",
    "noise_only"
  ],
  "seeds": [
    42,
    52,
    62,
    72,
    82
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    4.0,
    8.0,
    16.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/context_budget_0.30.json'] = r'''{
  "profile": "publication",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "dpcast",
    "constant",
    "noise_only"
  ],
  "seeds": [
    42,
    52,
    62,
    72,
    82
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    4.0,
    8.0,
    16.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.3,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/context_controls.json'] = r'''{
  "profile": "publication",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "dpcast",
    "constant",
    "noise_only",
    "constant_realloc",
    "noise_only_realloc",
    "drop_0",
    "drop_1",
    "drop_2",
    "drop_3",
    "drop_4",
    "drop_0_realloc",
    "drop_1_realloc",
    "drop_2_realloc",
    "drop_3_realloc",
    "drop_4_realloc",
    "raw_context"
  ],
  "seeds": [
    42,
    52,
    62,
    72,
    82
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    4.0,
    8.0,
    16.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/development.json'] = r'''{
  "profile": "development",
  "datasets": [
    "Cervical"
  ],
  "methods": [
    "fixed",
    "random",
    "frozen",
    "dpcast"
  ],
  "seeds": [
    42
  ],
  "alphas": [
    0.5
  ],
  "epsilon_targets": [
    8.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 20,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 16,
  "rl_warmup": 16,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/horizon_development_100.json'] = r'''{
  "profile": "development",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "random",
    "frozen",
    "dpcast"
  ],
  "seeds": [
    7,
    17,
    27
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    8.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/horizon_development_200.json'] = r'''{
  "profile": "development",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "random",
    "frozen",
    "dpcast"
  ],
  "seeds": [
    7,
    17,
    27
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    8.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 200,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/horizon_development_30.json'] = r'''{
  "profile": "development",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "random",
    "frozen",
    "dpcast"
  ],
  "seeds": [
    7,
    17,
    27
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    8.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 30,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/publication.json'] = r'''{
  "profile": "publication",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "nonprivate",
    "fixed",
    "adaptive_clip",
    "rule",
    "random",
    "frozen",
    "dpcast"
  ],
  "seeds": [
    42,
    52,
    62,
    72,
    82
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    4.0,
    8.0,
    16.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['configs/real_data_smoke.json'] = r'''{
  "profile": "validation_only",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "fixed",
    "dpcast"
  ],
  "seeds": [
    42
  ],
  "alphas": [
    0.5
  ],
  "epsilon_targets": [
    8.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 8,
  "local_epochs": 1,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 8,
  "rl_warmup": 8,
  "rl_updates_per_round": 2,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": 2000,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 200
}'''

MODULES['configs/smoke.json'] = r'''{
  "profile": "smoke",
  "datasets": [
    "synthetic"
  ],
  "methods": [
    "nonprivate",
    "fixed",
    "adaptive_clip",
    "rule",
    "random",
    "frozen",
    "dpcast",
    "constant",
    "noise_only",
    "constant_realloc",
    "noise_only_realloc",
    "drop_0",
    "drop_2_realloc",
    "raw_context"
  ],
  "seeds": [
    42
  ],
  "alphas": [
    0.5
  ],
  "epsilon_targets": [
    8.0
  ],
  "clients": 4,
  "participation": 0.75,
  "rounds": 8,
  "local_epochs": 1,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    8,
    4
  ],
  "head_hidden": 4,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 4,
  "rl_warmup": 4,
  "rl_updates_per_round": 2,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": 240,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": true,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 200
}'''

MODULES['configs/ten_seeds.json'] = r'''{
  "profile": "publication",
  "datasets": [
    "CDC_Diabetes",
    "Cervical",
    "Glioma",
    "SUPPORT2"
  ],
  "methods": [
    "nonprivate",
    "fixed",
    "adaptive_clip",
    "rule",
    "random",
    "frozen",
    "dpcast"
  ],
  "seeds": [
    42,
    52,
    62,
    72,
    82,
    92,
    102,
    112,
    122,
    132
  ],
  "alphas": [
    0.1,
    0.5,
    1.0
  ],
  "epsilon_targets": [
    4.0,
    8.0,
    16.0
  ],
  "clients": 8,
  "participation": 0.75,
  "rounds": 100,
  "local_epochs": 2,
  "batch_size": 256,
  "local_lr": 0.001,
  "server_lr": 1.0,
  "encoder_dims": [
    128,
    64,
    32
  ],
  "head_hidden": 32,
  "dropout": 0.1,
  "focal_alpha": 0.75,
  "focal_gamma": 2.0,
  "delta": 1e-05,
  "clip_init": 0.05,
  "clip_min": 0.005,
  "clip_max": 0.5,
  "clip_lr": 0.2,
  "clip_quantile": 0.8,
  "context_fraction": 0.15,
  "clip_fraction": 0.05,
  "evaluation_fraction": 0.1,
  "central_postprocess_sigma": 0.0,
  "release_projection_radius": 1.0,
  "rl_batch": 32,
  "rl_warmup": 32,
  "rl_updates_per_round": 4,
  "rl_lr": 0.001,
  "rl_gamma": 0.95,
  "rl_target_interval": 10,
  "rl_capacity": 10000,
  "exploration_start": 1.0,
  "exploration_end": 0.05,
  "exploration_decay_fraction": 0.7,
  "reward_gain_weight": 0.6,
  "reward_privacy_weight": 0.1,
  "reward_change_weight": 0.1,
  "reward_recall_weight": 0.1,
  "reward_risk_weight": 0.1,
  "gain_scale": 0.1,
  "public_val_fraction": 0.1,
  "public_test_fraction": 0.1,
  "local_test_fraction": 0.2,
  "split_seed": 20261011,
  "max_rows": null,
  "max_public_eval_rows": null,
  "benchmark_diagnostics": true,
  "reproducible_noise": false,
  "acknowledge_reused_benchmarks": true,
  "noninferiority_margin": null,
  "noninferiority_justification": "",
  "bootstrap_reps": 10000
}'''

MODULES['core.py'] = r'''"""DP-CAST research primitives. NumPy reference implementation, Python 3.10+.

The RDP filter certifies a PREDECLARED bound under the ideal Gaussian protocol.
The observed spend is a ledger, not an adaptively selected privacy odometer.
This single-process simulator is not a hospital deployment or secure aggregator.
"""
from __future__ import annotations
import copy
import hashlib
import json
import math
from collections import deque
from dataclasses import dataclass, asdict, field
from pathlib import Path
import numpy as np
from scipy.special import expit
from sklearn.metrics import average_precision_score, roc_auc_score

CONTEXT_NAMES = ['sensitivity_score', 'representation_change', 'uncertainty',
                 'imbalance', 'update_deviation']
METRIC_NAMES = ['ap', 'auroc', 'f1', 'recall', 'specificity', 'balanced_accuracy']
ACTION_FACTORS = np.array([.50, .75, 1., 1.50, 2.])
CLIP_FACTORS = np.array([.75, 1., 1.25])
ACTIONS = [(float(a), float(c)) for a in ACTION_FACTORS for c in CLIP_FACTORS]
DEFAULT_ACTION = ACTIONS.index((1., 1.))

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(obj):
    return hashlib.sha256(canonical(obj).encode()).hexdigest()

def keyed_rng(seed, *keys):
    key = hashlib.sha256(canonical([int(seed), *keys]).encode()).digest()
    return np.random.default_rng(int.from_bytes(key[:16], 'little'))

def jsonable(x):
    if isinstance(x, dict): return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [jsonable(v) for v in x]
    if isinstance(x, np.ndarray): return jsonable(x.tolist())
    if isinstance(x, np.generic): return jsonable(x.item())
    if isinstance(x, float) and not math.isfinite(x): return None
    return x

def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(jsonable(obj), indent=2, sort_keys=True))
    tmp.replace(path)

@dataclass
class Config:
    profile: str = 'development'
    datasets: list = field(default_factory=lambda: ['CDC_Diabetes', 'Cervical', 'Glioma', 'SUPPORT2'])
    methods: list = field(default_factory=lambda: ['nonprivate', 'fixed', 'adaptive_clip',
        'rule', 'random', 'frozen', 'dpcast'])
    seeds: list = field(default_factory=lambda: [42, 52, 62, 72, 82])
    alphas: list = field(default_factory=lambda: [.1, .5, 1.])
    epsilon_targets: list = field(default_factory=lambda: [4., 8., 16.])
    clients: int = 8
    participation: float = .75
    rounds: int = 100
    local_epochs: int = 2
    batch_size: int = 256
    local_lr: float = .001
    server_lr: float = 1.
    encoder_dims: list = field(default_factory=lambda: [128, 64, 32])
    head_hidden: int = 32
    dropout: float = .1
    focal_alpha: float = .75
    focal_gamma: float = 2.
    delta: float = 1e-5
    clip_init: float = .05
    clip_min: float = .005
    clip_max: float = .5
    clip_lr: float = .2
    clip_quantile: float = .8
    context_fraction: float = .15
    clip_fraction: float = .05
    evaluation_fraction: float = .10
    central_postprocess_sigma: float = 0.
    release_projection_radius: float = 1.
    rl_batch: int = 32
    rl_warmup: int = 32
    rl_updates_per_round: int = 4
    rl_lr: float = .001
    rl_gamma: float = .95
    rl_target_interval: int = 10
    rl_capacity: int = 10000
    exploration_start: float = 1.
    exploration_end: float = .05
    exploration_decay_fraction: float = .7
    reward_gain_weight: float = .6
    reward_privacy_weight: float = .1
    reward_change_weight: float = .1
    reward_recall_weight: float = .1
    reward_risk_weight: float = .1
    gain_scale: float = .1
    public_val_fraction: float = .1
    public_test_fraction: float = .1
    local_test_fraction: float = .2
    split_seed: int = 20261011
    max_rows: int | None = None
    max_public_eval_rows: int | None = None
    benchmark_diagnostics: bool = True
    reproducible_noise: bool = False
    acknowledge_reused_benchmarks: bool = True
    noninferiority_margin: float | None = None
    noninferiority_justification: str = ''
    bootstrap_reps: int = 10000

    def validate(self):
        assert self.clients > 1 and self.rounds > 0 and self.local_epochs > 0
        assert self.batch_size > 0 and self.rl_batch > 0 and self.rl_warmup >= self.rl_batch
        assert 0 < self.participation <= 1 and 0 < self.delta < 1
        assert 0 < self.clip_min <= self.clip_init <= self.clip_max
        assert 0 <= self.dropout < 1 and 0 < self.focal_alpha < 1
        assert 0 < self.public_val_fraction < 1 and 0 < self.public_test_fraction < 1
        assert self.public_val_fraction + self.public_test_fraction < 1
        assert 0 < self.local_test_fraction < 1
        assert self.evaluation_fraction > 0 and self.context_fraction > 0 and self.clip_fraction > 0
        assert self.evaluation_fraction + self.context_fraction + self.clip_fraction < 1
        assert all(a > 0 for a in self.alphas) and all(e > 0 for e in self.epsilon_targets)
        assert self.central_postprocess_sigma >= 0 and self.release_projection_radius > 0
        if self.noninferiority_margin is not None:
            assert 0 < self.noninferiority_margin < 1 and self.noninferiority_justification.strip()
        for method in self.methods: method_spec(method)
        if self.profile == 'publication':
            assert len(self.seeds) >= 5, 'At least five independent training/partition seeds.'
            assert self.max_rows is None, 'Publication profile must not silently truncate data.'
            assert not self.reproducible_noise, 'Published DP noise seeds invalidate a private release.'
        if self.reproducible_noise and not self.benchmark_diagnostics:
            raise ValueError('Deterministic public noise seeds are for public-benchmark diagnostics only.')
        return self

def method_spec(name):
    base = dict(private=True, adaptive=True, controller='trained', context='protected',
                drop=None, reallocate=False)
    if name == 'nonprivate': base.update(private=False, adaptive=False, controller='fixed', context='none')
    elif name == 'fixed': base.update(adaptive=False, controller='fixed', context='none')
    elif name == 'adaptive_clip': base.update(controller='fixed', context='none')
    elif name in ['rule', 'random', 'frozen']: base['controller'] = name
    elif name == 'dpcast': pass
    elif name == 'raw_context': base['context'] = 'raw'
    elif name in ['constant', 'noise_only', 'constant_realloc', 'noise_only_realloc']:
        base['context'] = name.split('_realloc')[0]; base['reallocate'] = name.endswith('_realloc')
    elif name.startswith('drop_'):
        pieces = name.split('_'); base['drop'] = int(pieces[1])
        if base['drop'] not in range(5): raise ValueError(name)
        base['reallocate'] = name.endswith('_realloc')
    else: raise ValueError(f'Unknown method: {name}')
    return base

def metrics(y, p):
    y = np.asarray(y, dtype=int); p = np.asarray(p, dtype=float)
    if len(y) != len(p) or not np.isfinite(p).all(): raise ValueError('Invalid predictions')
    if not np.isin(y, [0, 1]).all(): raise ValueError('Binary target required')
    n = len(y); pos = int(y.sum()); neg = n-pos
    pred = p >= .5
    tp = int(np.sum(pred & (y == 1))); fp = int(np.sum(pred & (y == 0)))
    fn = pos-tp; tn = neg-fp
    # AP has no positive-class retrieval interpretation if no positives exist.
    ap = float(average_precision_score(y, p)) if pos else np.nan
    auc = float(roc_auc_score(y, p)) if pos and neg else np.nan
    recall = tp/pos if pos else np.nan
    spec = tn/neg if neg else np.nan
    f1 = 2*tp/(2*tp+fp+fn) if (2*tp+fp+fn) else np.nan
    balanced = (recall+spec)/2 if pos and neg else np.nan
    reason = ('empty' if not n else 'no_positives' if not pos else 'no_negatives' if not neg else '')
    return dict(zip(METRIC_NAMES, [ap, auc, f1, recall, spec, balanced]),
                n=n, positives=pos, negatives=neg, undefined_reason=reason)

def average_metrics(rows):
    out = {}
    for k in METRIC_NAMES:
        a = np.array([r[k] for r in rows], dtype=float); a = a[np.isfinite(a)]
        out['mean_'+k] = float(a.mean()) if len(a) else np.nan
        out['valid_'+k] = int(len(a))
    a = np.array([r['ap'] for r in rows]); a = a[np.isfinite(a)]
    out['worst_head_ap'] = float(a.min()) if len(a) else np.nan
    out['head_ap_dispersion'] = float(a.std(ddof=0)) if len(a) else np.nan
    return out

class PrivacyFilter:
    """Fixed-order adaptive RDP filter (Lecuyer 2021, Theorem 1).

    Cost is rho=Delta^2/(2*s^2); RDP at the fixed order is alpha*rho.
    Alpha is selected from public epsilon/delta BEFORE any data interaction.
    Each enrolled client has its own replacement-adjacency ledger. No amplification.
    """
    def __init__(self, clients, epsilon, delta):
        self.epsilon = float(epsilon); self.delta = float(delta)
        orders = np.r_[np.arange(1.25, 10, .25), np.arange(10., 65.), [96., 128., 192., 256., 512.]]
        capacities = (epsilon - np.log(1/delta)/(orders-1))/orders
        idx = int(np.argmax(capacities)); self.order = float(orders[idx])
        self.capacity = float(capacities[idx])
        if self.capacity <= 0: raise ValueError('No positive RDP capacity')
        self.spent = np.zeros(clients, dtype=float); self.events = []

    def feasible(self, client, cost, reserve=0.):
        return (np.isfinite(cost) and cost >= 0 and np.isfinite(reserve) and reserve >= 0
                and self.spent[client] + cost + reserve <= self.capacity + 1e-12*self.capacity)

    def charge(self, client, mechanism, cost, round_id, sensitivity, reserve=0., actual_query=True):
        if not self.feasible(client, cost, reserve):
            raise RuntimeError(f'Privacy filter refused {mechanism} BEFORE release')
        if cost <= 0 or sensitivity <= 0: raise ValueError('Gaussian query requires positive cost and bound')
        self.spent[client] += cost
        self.events.append(dict(client=client, round=round_id, mechanism=mechanism,
            charged_rho=cost, ideal_gaussian_rho=cost if actual_query else 0.,
            rdp_at_fixed_order=self.order*cost, cumulative_charged_rho=self.spent[client],
            reserved_rho=reserve, sensitivity=sensitivity,
            noise_sd=sensitivity/math.sqrt(2*cost), alpha=self.order,
            epsilon_cap=self.epsilon, delta=self.delta))

    def release(self, value, client, mechanism, cost, round_id, sensitivity, rng, reserve=0., actual_query=True):
        # Charge/guard before drawing noise or exposing a value.
        self.charge(client, mechanism, cost, round_id, sensitivity, reserve, actual_query)
        return np.asarray(value, float) + rng.normal(0., sensitivity/math.sqrt(2*cost), np.shape(value))

    def certificate(self):
        return dict(epsilon_cap=self.epsilon, delta=self.delta, fixed_rdp_order=self.order,
                    rho_capacity=self.capacity, rho_spent_per_client=self.spent.tolist(),
                    bound_at_fixed_order=self.order*self.capacity+np.log(1/self.delta)/(self.order-1),
                    observed_spend_is_not_an_odometer=True, sampling_amplification=False)

def project_l2(v, radius):
    v = np.asarray(v, dtype=float)
    return v * min(1., radius/max(float(np.linalg.norm(v)), 1e-300))

def focal_loss_gradient(logit, y, alpha=.75, gamma=2.):
    y = np.asarray(y, float).reshape(-1, 1)
    z = np.asarray(logit, float).reshape(-1, 1)
    sign = 2*y-1
    pt = expit(sign*z)
    logpt = -np.logaddexp(0., -sign*z)
    weight = np.where(y == 1, alpha, 1-alpha)
    loss = -weight*(1-pt)**gamma*logpt
    # Exact stable derivative; no log(p) clipping mismatch with the loss.
    grad = weight*sign*(1-pt)**gamma*(gamma*pt*logpt-(1-pt))/max(len(y), 1)
    return float(loss.mean()), grad

class MLP:
    """Dense ReLU network with exact backpropagation and explicit Adam state."""
    def __init__(self, dims, rng, dropout=0., dropout_layers=()):
        self.dims = list(dims); self.dropout = dropout; self.dropout_layers = set(dropout_layers)
        self.params = []
        for i, (a,b) in enumerate(zip(dims[:-1], dims[1:])):
            scale = np.sqrt((2. if i < len(dims)-2 else 1.)/a)
            self.params += [rng.normal(0, scale, (a,b)), np.zeros(b)]
        self.m = [np.zeros_like(p) for p in self.params]
        self.v = [np.zeros_like(p) for p in self.params]; self.steps = 0

    def copy(self): return copy.deepcopy(self)

    def vector(self, start=0, stop=None):
        return np.concatenate([p.ravel() for p in self.params[start:stop]])

    def set_vector(self, vec, start=0, stop=None):
        chosen = self.params[start:stop]; offset = 0
        for p in chosen:
            p[:] = vec[offset:offset+p.size].reshape(p.shape); offset += p.size
        if offset != len(vec): raise ValueError('Parameter vector length mismatch')

    def forward(self, x, training=False, rng=None):
        a = np.asarray(x, float); cache = []; n_layers = len(self.params)//2
        for l in range(n_layers):
            w,b = self.params[2*l:2*l+2]; z = a@w+b; mask = None
            if l < n_layers-1:
                h = np.maximum(z, 0)
                if training and l in self.dropout_layers and self.dropout:
                    mask = (rng.random(h.shape) >= self.dropout)/(1-self.dropout); h *= mask
            else: h = z
            cache.append((a,z,mask)); a = h
        return a, cache

    def backward(self, grad, cache):
        grads = [None]*len(self.params)
        for l in reversed(range(len(cache))):
            a,z,mask = cache[l]
            if l < len(cache)-1:
                if mask is not None: grad = grad*mask
                grad = grad*(z>0)
            grads[2*l] = a.T@grad; grads[2*l+1] = grad.sum(axis=0)
            grad = grad@self.params[2*l].T
        return grads

    def adam(self, grads, lr, clip_norm=10.):
        norm = np.sqrt(sum(float(np.sum(g*g)) for g in grads))
        factor = min(1., clip_norm/max(norm, 1e-300)); self.steps += 1
        for j,g in enumerate(grads):
            g = g*factor; self.m[j] = .9*self.m[j]+.1*g; self.v[j] = .999*self.v[j]+.001*g*g
            self.params[j] -= lr*(self.m[j]/(1-.9**self.steps))/(np.sqrt(self.v[j]/(1-.999**self.steps))+1e-8)

    def fit_local(self, x, y, cfg, rng):
        if not len(y): return 0.
        loss_sum = 0.; batches = 0
        for _ in range(cfg.local_epochs):
            order = rng.permutation(len(y))
            for j in range(0, len(y), cfg.batch_size):
                ix = order[j:j+cfg.batch_size]
                z, cache = self.forward(x[ix], True, rng)
                loss, grad = focal_loss_gradient(z, y[ix], cfg.focal_alpha, cfg.focal_gamma)
                self.adam(self.backward(grad, cache), cfg.local_lr)
                loss_sum += loss; batches += 1
        return loss_sum/max(batches, 1)

    def predict(self, x, batch=4096):
        return np.concatenate([expit(self.forward(x[j:j+batch])[0][:,0])
            for j in range(0, len(x), batch)]) if len(x) else np.empty(0)

    def representation(self, x, encoder_layers=3):
        a = np.asarray(x, float)
        for l in range(encoder_layers): a = np.maximum(a@self.params[2*l]+self.params[2*l+1], 0.)
        return a

class DoubleDQN:
    def __init__(self, cfg, seed):
        self.cfg = cfg; self.q = MLP([8,64,32,len(ACTIONS)], keyed_rng(seed, 'q_init'))
        self.target = self.q.copy(); self.frozen = self.q.copy()
        self.memory = deque(maxlen=cfg.rl_capacity); self.updates = 0
        self.rng = keyed_rng(seed, 'q_replay')

    def greedy(self, state, mask, network=None):
        mask = np.asarray(mask, bool)
        if not mask.any(): return None
        scores = (network or self.q).forward(np.atleast_2d(state))[0][0]
        return int(np.argmax(np.where(mask, scores, -np.inf)))

    def add(self, state, executed_action, reward, next_state, done, next_mask, gap=1):
        assert 0 <= executed_action < len(ACTIONS)
        self.memory.append((np.asarray(state), int(executed_action), float(reward),
                            np.asarray(next_state), bool(done), np.asarray(next_mask, bool), int(gap)))

    def learn(self):
        if len(self.memory) < self.cfg.rl_warmup: return None
        ix = self.rng.choice(len(self.memory), self.cfg.rl_batch, replace=False)
        batch = [self.memory[int(i)] for i in ix]
        s = np.stack([b[0] for b in batch]); a = np.array([b[1] for b in batch])
        r = np.array([b[2] for b in batch]); ns = np.stack([b[3] for b in batch])
        done = np.array([b[4] for b in batch]); mask = np.stack([b[5] for b in batch])
        gap = np.array([b[6] for b in batch]); rows = np.arange(len(batch))
        online_next = self.q.forward(ns)[0]
        best = np.argmax(np.where(mask, online_next, -np.inf), axis=1)
        target_next = self.target.forward(ns)[0][rows, best]
        target = r + (~done & mask.any(axis=1))*(self.cfg.rl_gamma**gap)*target_next
        pred, cache = self.q.forward(s); err = pred[rows,a]-target
        loss = np.where(np.abs(err)<=1., .5*err**2, np.abs(err)-.5).mean()
        grad = np.zeros_like(pred); grad[rows,a] = np.clip(err,-1.,1.)/len(batch)
        self.q.adam(self.q.backward(grad,cache), self.cfg.rl_lr)
        self.updates += 1
        if self.updates % self.cfg.rl_target_interval == 0: self.target = self.q.copy()
        if not np.isfinite(loss): raise FloatingPointError('Non-finite Q loss')
        return float(loss)

def make_context(model, x, y, delta_encoder, clip_base, previous_mean, public_previous_update):
    if not len(y): return np.zeros(5), previous_mean
    rep = model.representation(x[:128], len(model.dims)-3)
    mean = rep.mean(axis=0); dispersion = np.linalg.norm(rep-mean, axis=1).mean()
    norm = float(np.linalg.norm(delta_encoder)); imbalance = abs(2*float(np.mean(y))-1)
    sensitivity_score = .4*min(1.,dispersion/2.)+.4*min(1.,norm/clip_base)+.2*imbalance
    change = 0. if previous_mean is None else min(1.,float(np.linalg.norm(mean-previous_mean)))
    p = np.clip(model.predict(x[:128]),1e-12,1-1e-12)
    uncertainty = float(np.mean(-(p*np.log(p)+(1-p)*np.log1p(-p))/np.log(2)))
    pn = float(np.linalg.norm(public_previous_update))
    directional = .5 if norm*pn == 0 else float(np.clip((1-np.dot(delta_encoder,public_previous_update)/(norm*pn))/2,0,1))
    # Public DP aggregate norm replaces the paper's raw cross-client median.
    deviation = .4*directional+.3*min(1.,abs(norm-pn)/.25)+.3*change
    return np.clip([sensitivity_score,change,uncertainty,imbalance,deviation],0.,1.), mean

'''

MODULES['data.py'] = r'''"""Audited UCI loading and benchmark-only partition construction.

Public reference/test membership and client membership are fixed conditioning
information for the protocol. Label-based partition construction is NOT itself DP.
No trained preprocessing statistic is fitted on pooled private training records.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError
import json
import hashlib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification
from core import keyed_rng, save_json, digest

SPECS = {
 'CDC_Diabetes': dict(id=891, target='Diabetes_binary', positive='prediabetes or diabetes'),
 'Cervical': dict(id=383, target='Biopsy', positive='positive cervical biopsy'),
 'Glioma': dict(id=759, target='Grade', positive='GBM glioblastoma'),
 'SUPPORT2': dict(id=880, target='hospdead', positive='in-hospital death'),
}
EXCLUSIONS = {
 'CDC_Diabetes': ['ID', 'Diabetes_012'],
 'Cervical': ['ID','Hinselmann','Schiller','Citology','Cytology','Dx:Cancer','Dx:CIN','Dx:HPV','Dx'],
 'Glioma': ['ID','Project','Case_ID','Primary_Diagnosis'],
 # Conservative static clinical benchmark. Do NOT claim an hour-24 landmark.
 'SUPPORT2': ['id','ID','death','d.time','slos','charges','totcst','totmcst','sfdm2',
              'avtisst','aps','sps','surv2m','surv6m','prg2m','prg6m','dnr','dnrday'],
}
MISSING = ['?','--','not reported','unknown','NA','N/A','']

def fetch_bytes(url):
    error = None
    for attempt in range(3):
        try:
            with urlopen(Request(url, headers={'User-Agent':'DP-CAST-research/1.0'}), timeout=45) as response:
                return response.read()
        except (URLError, TimeoutError, OSError) as exc: error = exc
    raise RuntimeError(f'Download failed: {url}. Supply the matching CSV in data_cache; no synthetic fallback. {error}')

def fetch_dataset(name, cache):
    cache = Path(cache); cache.mkdir(parents=True, exist_ok=True)
    spec = SPECS[name]; csv = cache/f'{name}.csv'; meta = cache/f'{name}_metadata.json'
    if not csv.exists():
        m = json.loads(fetch_bytes(f'https://archive.ics.uci.edu/api/dataset?id={spec["id"]}'))
        if m.get('status') != 200 or not m.get('data',{}).get('data_url'):
            raise RuntimeError(f'UCI dataset {spec["id"]} is unavailable; provide an official CSV.')
        metadata = m['data']; save_json(meta,metadata)
        csv.write_bytes(fetch_bytes(metadata['data_url']))
    metadata = json.loads(meta.read_text()) if meta.exists() else {'source':'user-provided CSV'}
    frame = pd.read_csv(csv, na_values=MISSING, low_memory=False)
    return frame, dict(metadata=metadata, csv_sha256=hashlib.sha256(csv.read_bytes()).hexdigest())

def encode_target(series, name):
    s = series.astype(str).str.strip().str.lower()
    maps = {'0':0,'0.0':0,'1':1,'1.0':1}
    if name == 'Glioma': maps.update(lgg=0, gbm=1)
    unknown = sorted(set(s.dropna())-set(maps))
    if unknown: raise ValueError(f'{name}: ambiguous target labels {unknown}; do not infer a positive class.')
    y = s.map(maps).to_numpy(dtype=np.int64)
    if len(np.unique(y)) != 2: raise ValueError(f'{name}: both target classes are required for the benchmark split.')
    return y

class PublicPreprocessor:
    """Fit on public reference features only; fixed schema, missing indicators.

    Numeric features use reference medians/means/SDs. All-missing columns use 0/1.
    Categories outside the reference vocabulary map to a fixed unknown bucket.
    Schema is public metadata; no feature selection based on private columns.
    """
    def __init__(self): self.specs=[]; self.feature_names=[]

    def fit(self, reference, categorical=()):
        cats = set(categorical)
        for col in reference.columns:
            s = reference[col]
            numeric = pd.to_numeric(s, errors='coerce')
            is_numeric = col not in cats and (pd.api.types.is_numeric_dtype(s) or numeric.notna().sum()==s.notna().sum())
            if is_numeric:
                a = numeric.to_numpy(float); missing = ~np.isfinite(a)
                med = float(np.median(a[~missing])) if (~missing).any() else 0.
                a[missing] = med; mean=float(a.mean()); scale=max(float(a.std()),1e-8)
                self.specs.append(dict(col=col, kind='numeric',median=med,mean=mean,scale=scale))
                self.feature_names += [col, col+'__missing']
            else:
                vals = sorted(set(s.dropna().astype(str)))
                self.specs.append(dict(col=col,kind='category',values=vals))
                self.feature_names += [col+'='+v for v in vals]+[col+'=__UNKNOWN__',col+'=__MISSING__']
        return self

    def transform(self, frame):
        parts=[]
        for spec in self.specs:
            s=frame[spec['col']]
            if spec['kind']=='numeric':
                a=pd.to_numeric(s,errors='coerce').to_numpy(float); missing=~np.isfinite(a)
                a[missing]=spec['median']
                parts += [np.clip((a-spec['mean'])/spec['scale'],-10,10)[:,None],missing.astype(float)[:,None]]
            else:
                vals=spec['values']; a=np.zeros((len(s),len(vals)+2)); mapping={v:i for i,v in enumerate(vals)}
                idx=[len(vals)+1 if pd.isna(v) else mapping.get(str(v),len(vals)) for v in s]
                a[np.arange(len(s)),idx]=1.; parts.append(a)
        out=np.concatenate(parts,axis=1)
        if not np.isfinite(out).all(): raise ValueError('Non-finite preprocessing output')
        return out

@dataclass
class Prepared:
    name: str
    x: np.ndarray
    y: np.ndarray
    public_val: np.ndarray
    public_test: np.ndarray
    client_train: list
    client_test: list
    audit: dict
    preprocessor: PublicPreprocessor
    partition_hash: str

def prepare(name, cfg, seed, alpha, cache, destination):
    if name == 'synthetic':
        # This path is explicit, never a fallback for unavailable clinical data.
        xx,yy=make_classification(n_samples=cfg.max_rows or 800,n_features=10,
            n_informative=6,weights=[.75,.25],random_state=812)
        frame=pd.DataFrame(xx,columns=[f'x{i}' for i in range(10)]); frame['outcome']=yy
        source={'csv_sha256':digest({'synthetic':812,'n':len(yy)})}; target='outcome'; positive='synthetic class 1'
    else:
        frame,source=fetch_dataset(name,cache); target=SPECS[name]['target']; positive=SPECS[name]['positive']
    frame.columns=[c.strip() for c in frame.columns]
    if target not in frame: raise ValueError(f'{name}: target {target!r} absent; found {list(frame.columns)}')
    initial_n=len(frame); missing_target=int(frame[target].isna().sum())
    frame=frame.loc[frame[target].notna()].reset_index(drop=True)
    y=encode_target(frame[target],name)
    selected=np.arange(len(frame))
    if cfg.max_rows is not None and len(frame)>cfg.max_rows:
        selected,_=train_test_split(selected,train_size=cfg.max_rows,stratify=y,random_state=cfg.split_seed)
        selected=np.sort(selected); frame=frame.iloc[selected].reset_index(drop=True); y=y[selected]
    removed=[c for c in EXCLUSIONS.get(name,[]) if c in frame]
    features=frame.drop(columns=[target]+removed)
    # Account for UCI role labels so IDs/secondary targets can never enter features.
    for var in source.get('metadata',{}).get('variables',[]):
        if var.get('role','').lower() in ['id','target'] and var.get('name') in features:
            removed.append(var['name']); features=features.drop(columns=[var['name']])
    ix=np.arange(len(y))
    rest,test=train_test_split(ix,test_size=cfg.public_test_fraction,stratify=y,random_state=cfg.split_seed)
    pool,val=train_test_split(rest,test_size=cfg.public_val_fraction/(1-cfg.public_test_fraction),
                             stratify=y[rest],random_state=cfg.split_seed+1)
    categorical=[]
    for var in source.get('metadata',{}).get('variables',[]):
        if str(var.get('type','')).lower() in ['categorical','binary']: categorical.append(var['name'])
    if name=='Glioma': categorical += [c for c in features if c!='Age_at_diagnosis']
    transform=PublicPreprocessor().fit(features.iloc[val],categorical)
    x=transform.transform(features)
    rng=keyed_rng(seed,name,alpha,'partition'); clients=[[] for _ in range(cfg.clients)]
    # Class-wise multinomial Dirichlet allocation. No retries to manufacture class coverage.
    for cls in [0,1]:
        records=rng.permutation(pool[y[pool]==cls]); proportions=rng.dirichlet(np.full(cfg.clients,alpha))
        counts=rng.multinomial(len(records),proportions); cursor=0
        for i,count in enumerate(counts): clients[i].extend(records[cursor:cursor+count].tolist()); cursor+=count
    train=[]; held=[]; client_audit=[]
    for i,records in enumerate(clients):
        records=rng.permutation(records).astype(int)
        nh=min(max(1,int(round(len(records)*cfg.local_test_fraction))),max(0,len(records)-1)) if len(records) else 0
        te=records[:nh]; tr=records[nh:]; train.append(tr); held.append(te)
        client_audit.append(dict(client=i,train_n=len(tr),train_positive=int(y[tr].sum()),
                                 heldout_n=len(te),heldout_positive=int(y[te].sum())))
    groups=[val,test,*train,*held]; joined=np.concatenate(groups)
    assert len(joined)==len(y) and len(np.unique(joined))==len(y), 'Split overlap or lost records'
    partition=dict(public_val=val.tolist(),public_test=test.tolist(),
                   client_train=[a.tolist() for a in train],client_test=[a.tolist() for a in held],
                   retained_source_rows=selected.tolist())
    ph=digest(partition)
    audit=dict(dataset=name,initial_rows=initial_n,missing_target_removed=missing_target,
        retained_rows=len(y),positive_label=positive,prevalence=float(y.mean()),
        raw_feature_count=features.shape[1],encoded_feature_count=x.shape[1],
        feature_names=list(features.columns),excluded_columns=removed,
        missingness={c:float(features[c].isna().mean()) for c in features},
        public_val_n=len(val),public_test_n=len(test),local_train_n=sum(map(len,train)),
        local_heldout_n=sum(map(len,held)),clients=client_audit,partition_hash=ph,
        fixed_evaluation_split_seed=cfg.split_seed,partition_seed=seed,dirichlet_alpha=alpha,
        source=source,prediction_task='static retrospective tabular classification; no prospective time landmark',
        preprocessing_fit='public validation/reference features only',
        claim_conditioning='public reference/test and fixed client membership; partition construction excluded')
    destination=Path(destination); destination.mkdir(parents=True,exist_ok=True)
    # These are benchmark-side records and are never sent to the protocol server.
    if cfg.benchmark_diagnostics:
        save_json(destination/'dataset_audit_BENCHMARK_ONLY.json',audit)
        save_json(destination/'partitions_BENCHMARK_ONLY.json',partition)
    save_json(destination/'public_preprocessing.json',dict(specs=transform.specs,features=transform.feature_names))
    return Prepared(name,x,y,val,test,train,held,audit,transform,ph)

'''

MODULES['experiment.py'] = r'''"""Federated protocol and evaluation. Raw client state never enters server logs.

Benchmark-only diagnostics are deliberately separate, with no privacy claim.
All protocol messages are explicit Gaussian releases or their post-processing.
"""
from __future__ import annotations
import math
import time
import secrets
from pathlib import Path
import numpy as np
import pandas as pd
from core import (ACTIONS, DEFAULT_ACTION, CONTEXT_NAMES, METRIC_NAMES, PrivacyFilter,
    MLP, DoubleDQN, keyed_rng, project_l2, make_context, metrics, average_metrics,
    method_spec, save_json, digest)

def allocations(cfg, spec, capacity):
    ctx=cfg.context_fraction if spec['context']!='none' else 0.
    clp=cfg.clip_fraction if spec['adaptive'] else 0.
    if spec['reallocate']:
        ctx = ctx*.8 if spec['drop'] is not None else 0.
    ev=cfg.evaluation_fraction
    return dict(context=capacity*ctx,clipping=capacity*clp,evaluation=capacity*ev,
                update=capacity*(1-ctx-clp-ev))

def action_costs(update_budget, spent_update, remaining):
    if remaining < 1: return np.full(len(ACTIONS),np.inf)
    # Adaptively spend around the remaining average, while retaining a predeclared
    # minimum per future visit. The filter, not this schedule, enforces the bound.
    average=max(0.,update_budget-spent_update)/remaining
    return np.array([factor*average for factor,_ in ACTIONS])

def select_action(kind, state, mask, dqn, epsilon, rng):
    feasible=np.flatnonzero(mask)
    if not len(feasible): return None
    if kind=='fixed':
        return DEFAULT_ACTION if mask[DEFAULT_ACTION] else int(feasible[np.argmin(abs(feasible-DEFAULT_ACTION))])
    if kind=='random' or (kind in ['trained','frozen'] and rng.random()<epsilon):
        return int(rng.choice(feasible))
    if kind=='rule':
        # Same 15 feasible actions as the learned/random/frozen policies.
        level=min(4,int(np.floor(5*np.clip(.5*state[0]+.5*state[2],0,.999999))))
        clip_level=min(2,int(np.floor(3*np.clip(state[1],0,.999999))))
        proposed=level*3+clip_level
        return proposed if mask[proposed] else int(feasible[np.argmin(abs(feasible-proposed))])
    return dqn.greedy(state,mask,dqn.frozen if kind=='frozen' else dqn.q)

def epsilon_exploration(cfg, round_id):
    frac=min(1.,round_id/max(1.,cfg.rounds*cfg.exploration_decay_fraction))
    return cfg.exploration_start+(cfg.exploration_end-cfg.exploration_start)*frac

def server_models(template, encoder, heads, cut):
    models=[]
    for head in heads:
        m=template.copy(); m.set_vector(encoder,stop=cut); m.set_vector(head,start=cut); models.append(m)
    return models

def public_scores(template, encoder, heads, cut, prepared, idx):
    preds=np.stack([m.predict(prepared.x[idx]) for m in server_models(template,encoder,heads,cut)])
    rows=[metrics(prepared.y[idx],p) for p in preds]
    return average_metrics(rows),rows,preds

def train(prepared,cfg,method,seed,alpha,epsilon,out):
    started=time.perf_counter(); out=Path(out); out.mkdir(parents=True,exist_ok=True)
    spec=method_spec(method)
    if not cfg.benchmark_diagnostics and (not spec['private'] or spec['context']=='raw'):
        raise ValueError('Raw-context/nonprivate controls require benchmark_diagnostics=True.')
    k=cfg.clients; schedule=keyed_rng(seed,prepared.name,alpha,'participation').random((cfg.rounds,k))<cfg.participation
    # Empty rounds remain empty. No forced participant and no amplification claim.
    counts=schedule.sum(axis=0)
    template=MLP([prepared.x.shape[1],*cfg.encoder_dims,cfg.head_hidden,1],
                 keyed_rng(seed,prepared.name,'model_init'),cfg.dropout,range(min(2,len(cfg.encoder_dims))))
    cut=2*len(cfg.encoder_dims)
    encoder=template.vector(stop=cut); heads=[template.vector(start=cut).copy() for _ in range(k)]
    raw_heads=[h.copy() for h in heads]; previous_means=[None]*k
    previous_aggregate=np.zeros_like(encoder)
    previous_context=np.zeros((k,5)); clip_base=cfg.clip_init
    dqn=DoubleDQN(cfg,seed); pending={}; finished=np.zeros(k,dtype=int)
    filt=PrivacyFilter(k,epsilon,cfg.delta); pools=allocations(cfg,spec,filt.capacity)
    spent_update=np.zeros(k); participation_position=np.zeros(k,dtype=int)
    # Noise roots are not saved in protected runs. Benchmark reproducibility is
    # explicit and removes any claim about those artifacts as private releases.
    noise_root=seed if cfg.reproducible_noise else secrets.randbits(128)
    def noise_rng(t,i,label): return keyed_rng(noise_root,prepared.name,method,alpha,epsilon,t,i,label)
    val=prepared.public_val
    if cfg.max_public_eval_rows is not None: val=val[:cfg.max_public_eval_rows]
    prev_val,_,_=public_scores(template,encoder,heads,cut,prepared,val)
    rounds=[]; actions=[]; contexts=[]; raw_diagnostics=[]; controller_logs=[]; clip_logs=[]; replay_log=[]
    local_final=[]; last_states=[]
    for t in range(cfg.rounds):
        round_start=time.perf_counter(); selected=np.flatnonzero(schedule[t]); before=filt.spent.copy()
        protected_updates=[]; clip_observations=[]; decision_records=[]; reward_changes=[]; risks=[]
        for i0 in selected:
            i=int(i0); total=int(counts[i]); pos=int(participation_position[i]); remaining=total-pos
            ctx_cost=pools['context']/total if total else 0.
            clip_cost=pools['clipping']/total if total else 0.
            future_min=(remaining-1)*(pools['update']/total)*.5
            all_aux=remaining*(ctx_cost+clip_cost)
            eval_reserve=pools['evaluation']
            update_options=action_costs(pools['update'],spent_update[i],remaining)
            min_update=float(update_options.min())
            if spec['private'] and not filt.feasible(i,ctx_cost+clip_cost+min_update,
                        (remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min):
                # Stop BEFORE the first message. No attempt to expose raw values.
                actions.append(dict(round=t,client=i,status='pre_release_filter_stop'))
                participation_position[i]+=1
                continue
            client=template.copy(); client.set_vector(encoder,stop=cut); client.set_vector(raw_heads[i],start=cut)
            tr=prepared.client_train[i]; x=prepared.x[tr]; y=prepared.y[tr]
            client.fit_local(x,y,cfg,keyed_rng(seed,prepared.name,alpha,t,i,'local_training'))
            de=client.vector(stop=cut)-encoder
            dh=client.vector(start=cut)-heads[i]
            joint=np.concatenate([de,dh]); raw_heads[i]=client.vector(start=cut).copy()
            raw,previous_means[i]=make_context(client,x,y,de,clip_base,previous_means[i],previous_aggregate)
            observed=np.zeros(5); before_clip=np.zeros(5); sd=0.
            reserve=clip_cost+min_update+(remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min
            if spec['context'] in ['constant','noise_only']:
                observed=np.full(5,.5)
                if ctx_cost:
                    # Conservative budget-matched information ablation: debit the
                    # same allocation despite no access to private context.
                    filt.charge(i,'context_public_control_reservation',ctx_cost,t,math.sqrt(5),reserve,False)
                if spec['context']=='noise_only':
                    nominal=ctx_cost or cfg.context_fraction*filt.capacity/max(total,1)
                    sd=math.sqrt(5)/math.sqrt(2*nominal)
                    observed=np.clip(.5+noise_rng(t,i,'context').normal(0,sd,5),0,1)
                before_clip=observed.copy()
            elif spec['context']=='raw':
                observed=raw.copy(); before_clip=raw.copy()
                # Hypothetical charge ONLY to keep update allocation matched.
                filt.charge(i,'UNPROTECTED_context_hypothetical_charge',ctx_cost,t,math.sqrt(5),reserve,False)
            elif spec['context']=='protected':
                active=np.ones(5,dtype=bool)
                if spec['drop'] is not None and spec['reallocate']: active[spec['drop']]=False
                dimension=int(active.sum()); sd=math.sqrt(dimension)/math.sqrt(2*ctx_cost)
                released=filt.release(raw[active],i,'context',ctx_cost,t,math.sqrt(dimension),
                                      noise_rng(t,i,'context'),reserve)
                observed=np.full(5,.5); before_clip=np.full(5,.5)
                before_clip[active]=released; observed[active]=np.clip(released,0,1)
                if spec['drop'] is not None: observed[spec['drop']]=.5
            if spec['adaptive']:
                bit=float(np.linalg.norm(joint)<=clip_base)
                reserved_after_clip=min_update+(remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min
                q=float(filt.release(bit,i,'clipping_indicator',clip_cost,t,1.,
                        noise_rng(t,i,'clipping'),reserved_after_clip))
                clip_observations.append(q)
                clip_logs.append(dict(round=t,client=i,protected_indicator=q,clip_base=clip_base))
            state=np.r_[observed,t/max(cfg.rounds-1,1),filt.spent[i]/filt.capacity,prev_val['mean_ap']]
            reserves=(remaining-1)*(ctx_cost+clip_cost)+eval_reserve+future_min
            mask=np.array([filt.feasible(i,c,reserves) and
                c+spent_update[i]+future_min <= pools['update']+1e-12*filt.capacity
                for c in update_options]) if spec['private'] else np.ones(len(ACTIONS),bool)
            if i in pending:
                old=pending.pop(i)
                dqn.add(old['state'],old['action'],old['reward'],state,not mask.any(),mask,t-old['round'])
                replay_log.append(dict(client=i,source_round=old['round'],next_round=t,
                                       executed_action=old['action'],terminal=not mask.any()))
            exploration=epsilon_exploration(cfg,t)
            proposal=select_action(spec['controller'],state,mask,dqn,exploration,
                        keyed_rng(seed,prepared.name,alpha,t,i,'exploration'))
            if proposal is None:
                actions.append(dict(round=t,client=i,status='no_feasible_update_after_aux'))
                participation_position[i]+=1; continue
            # Recheck fallback AND its reservation. Nothing is released on refusal.
            executed=proposal
            if spec['private'] and not filt.feasible(i,update_options[executed],reserves):
                feasible=np.flatnonzero(mask)
                executed=int(feasible[np.argmin(update_options[feasible])]) if len(feasible) else None
                if executed is None or not filt.feasible(i,update_options[executed],reserves):
                    raise RuntimeError('Verified action mask and filter disagree')
            cost=float(update_options[executed]) if spec['private'] else 0.
            c=float(np.clip(clip_base*ACTIONS[executed][1],cfg.clip_min,cfg.clip_max))
            if spec['private']:
                released=filt.release(project_l2(joint,c),i,'joint_encoder_head_update',cost,t,2*c,
                                      noise_rng(t,i,'update'),reserves)
                # Public post-processing stabilizes parameter magnitudes. This
                # projection is identical across private comparison methods.
                released=project_l2(released,cfg.release_projection_radius*c)
                spent_update[i]+=cost
            else: released=joint
            protected_updates.append(released[:len(encoder)])
            heads[i]=heads[i]+released[len(encoder):]
            participation_position[i]+=1; finished[i]+=1
            reward_changes.append(abs(observed[0]-previous_context[i,0])); risks.append(observed[4])
            previous_context[i]=observed
            decision_records.append(dict(client=i,state=state,action=executed,mask=mask,round=t))
            last_states.append((state.copy(),mask.copy()))
            row=dict(round=t,client=i,status='released',proposed_action=proposal,executed_action=executed,
                rho_factor=ACTIONS[executed][0],clip_multiplier=ACTIONS[executed][1],clip=c,
                update_rho=cost,remaining_visits=remaining,exploration=exploration,
                controller_updates_before_decision=dqn.updates,
                greedy_trained=dqn.greedy(state,mask),greedy_frozen=dqn.greedy(state,mask,dqn.frozen))
            actions.append(row)
            for j,label in enumerate(CONTEXT_NAMES):
                contexts.append(dict(round=t,client=i,coordinate=label,observed=float(observed[j]),
                    boundary=float(observed[j] in [0.,1.]),noise_sd=sd,
                    masked=spec['drop']==j,context_mode=spec['context']))
            if cfg.benchmark_diagnostics:
                raw_state=state.copy(); raw_state[:5]=raw
                raw_action=dqn.greedy(raw_state,mask)
                for j,label in enumerate(CONTEXT_NAMES):
                    raw_diagnostics.append(dict(round=t,client=i,coordinate=label,raw=float(raw[j]),
                        protected=float(observed[j]),absolute_error=float(abs(observed[j]-raw[j])),
                        pre_clip=float(before_clip[j]),same_policy_raw_action=raw_action,
                        same_policy_protected_action=dqn.greedy(state,mask),
                        action_changed=raw_action!=dqn.greedy(state,mask)))
        if protected_updates:
            aggregate=np.mean(protected_updates,axis=0)
            if spec['private'] and cfg.central_postprocess_sigma:
                # The server already sees every protected message. This is ONLY
                # post-processing; it adds no extra server-privacy guarantee/cost.
                aggregate+=noise_rng(t,-1,'central_postprocess').normal(0,
                    cfg.central_postprocess_sigma*2*cfg.clip_max/len(protected_updates),len(encoder))
                aggregate=project_l2(aggregate,cfg.release_projection_radius*cfg.clip_max)
            encoder+=cfg.server_lr*aggregate; previous_aggregate=aggregate
        if clip_observations:
            fraction=float(np.clip(np.mean(clip_observations),0,1))
            clip_base=float(np.clip(clip_base*np.exp(cfg.clip_lr*(cfg.clip_quantile-fraction)),
                                    cfg.clip_min,cfg.clip_max))
        current,_,_=public_scores(template,encoder,heads,cut,prepared,val)
        gain=float(np.clip((current['mean_ap']-prev_val['mean_ap'])/cfg.gain_scale,-1,1))
        priv=float(np.mean(filt.spent-before)/filt.capacity)
        change=float(np.mean(reward_changes)) if reward_changes else 0.
        risk=float(np.mean(risks)) if risks else 0.
        recall_drop=max(0.,prev_val['mean_recall']-current['mean_recall'])
        reward=float(np.clip(cfg.reward_gain_weight*gain-cfg.reward_privacy_weight*priv
            -cfg.reward_change_weight*change-cfg.reward_recall_weight*recall_drop-cfg.reward_risk_weight*risk,-1,1))
        for rec in decision_records:
            i=rec['client']; pending[i]=dict(state=rec['state'],action=rec['action'],reward=reward,round=t)
        losses=[]; probes=last_states[-128:]
        before_actions=[dqn.greedy(s,m) for s,m in probes]
        if spec['controller']=='trained':
            for _ in range(cfg.rl_updates_per_round):
                loss=dqn.learn()
                if loss is not None: losses.append(loss)
        after_actions=[dqn.greedy(s,m) for s,m in probes]
        frozen_actions=[dqn.greedy(s,m,dqn.frozen) for s,m in probes]
        controller_logs.append(dict(round=t,updates=dqn.updates,buffer_size=len(dqn.memory),
            q_loss=float(np.mean(losses)) if losses else None,
            same_state_before_after_disagreement=float(np.mean(np.array(before_actions)!=np.array(after_actions))) if probes else None,
            trained_frozen_greedy_disagreement=float(np.mean(np.array(after_actions)!=np.array(frozen_actions))) if probes else None,
            exploration=epsilon_exploration(cfg,t),reward=reward,
            reward_gain=gain,reward_privacy=priv,reward_context_change=change,
            reward_recall_drop=recall_drop,reward_risk=risk))
        rounds.append(dict(round=t,selected=len(selected),released=len(protected_updates),
            validation_mean_head_ap=current['mean_ap'],validation_recall=current['mean_recall'],
            max_charged_rho=float(filt.spent.max()),rho_capacity=filt.capacity,epsilon_cap=epsilon,
            clip_base=clip_base,seconds=time.perf_counter()-round_start))
        prev_val=current
    for i,old in pending.items():
        dqn.add(old['state'],old['action'],old['reward'],old['state'],True,np.zeros(len(ACTIONS),bool))
        replay_log.append(dict(client=i,source_round=old['round'],next_round=cfg.rounds,
                               executed_action=old['action'],terminal=True))
    # Terminal transitions are archived; no extra terminal-only learning is used
    # to claim influence over decisions that have already happened.
    for i in range(k):
        local=template.copy(); local.set_vector(encoder,stop=cut); local.set_vector(raw_heads[i],start=cut)
        te=prepared.client_test[i]; local_p=local.predict(prepared.x[te]); row=metrics(prepared.y[te],local_p)
        local_final.append(dict(client=i,**row))
        vals=np.array([row[m] for m in METRIC_NAMES]); valid=np.isfinite(vals).astype(float)
        bounded=np.r_[np.nan_to_num(vals,nan=0.),valid]
        if spec['private']:
            noisy=filt.release(bounded,i,'local_evaluation',pools['evaluation'],cfg.rounds,
                               math.sqrt(len(bounded)),noise_rng(cfg.rounds,i,'local_eval'))
            save_json(out/f'client_{i}_protected_local_metrics.json',dict(metric_names=METRIC_NAMES,
                noisy_scores=noisy[:len(vals)].tolist(),noisy_validity=noisy[len(vals):].tolist(),
                noise_sd=math.sqrt(len(bounded)/(2*pools['evaluation'])),
                note='Noisy scores and validity are not unbiased ratios; use raw local metrics only in public benchmark diagnostics.'))
        if cfg.benchmark_diagnostics:
            bd=out/'BENCHMARK_ONLY_NOT_PRIVATE'; bd.mkdir(exist_ok=True)
            np.savez_compressed(bd/f'client_{i}_local_predictions.npz',indices=te,y=prepared.y[te],p=local_p)
    if cfg.benchmark_diagnostics:
        pd.DataFrame(raw_diagnostics).to_csv(out/'BENCHMARK_ONLY_NOT_PRIVATE/context_distortion.csv',index=False)
        pd.DataFrame(local_final).to_csv(out/'BENCHMARK_ONLY_NOT_PRIVATE/local_metrics.csv',index=False)
        save_json(out/'BENCHMARK_ONLY_NOT_PRIVATE/README.json',dict(
            warning='These raw contexts, local scores and labels are NOT private releases. Public benchmark research only.'))
    np.savez_compressed(out/'released_model.npz',encoder=encoder,heads=np.stack(heads),dims=template.dims)
    np.savez_compressed(out/'controller.npz',online=dqn.q.vector(),target=dqn.target.vector(),initial=dqn.frozen.vector())
    # Store complete, protected replay transitions without any raw context.
    replay_arrays={}
    if dqn.memory:
        fields=['state','executed_action','reward','next_state','done','next_mask','gap']
        replay_arrays={name:np.asarray([r[j] for r in dqn.memory]) for j,name in enumerate(fields)}
    np.savez_compressed(out/'protected_replay.npz',**replay_arrays)
    for filename,table in [('rounds',rounds),('actions',actions),('protected_context',contexts),
                           ('controller_learning',controller_logs),('private_clipping',clip_logs),
                           ('ledger',filt.events),('replay_index',replay_log)]:
        pd.DataFrame(table).to_csv(out/(filename+'.csv'),index=False)
    protocol_eligible=spec['private'] and spec['context']!='raw' and not cfg.reproducible_noise
    cert=filt.certificate(); cert.update(protocol_eligible=protocol_eligible,
        artifact_bundle_is_private=False,
        bundle_scope_note='Benchmark preparation/provenance is outside the protocol claim even when raw diagnostics are suppressed.',
        protocol_scope='ideal Gaussian, fixed enrollment/client-replacement, fixed public data and partitions; no systems certification',
        noise_seeds_published=cfg.reproducible_noise,
        central_noise_is_postprocessing=True,raw_personal_heads_released=False,
        raw_context_diagnostic=spec['context']=='raw',allocation=pools)
    save_json(out/'privacy_certificate.json',cert)
    summary=dict(dataset=prepared.name,method=method,seed=seed,alpha=alpha,epsilon_target=epsilon,
        delta=cfg.delta,training_rounds=cfg.rounds,partition_hash=prepared.partition_hash,
        common_test_evaluated=False,validation_mean_head_ap=prev_val['mean_ap'],
        controller_updates=dqn.updates,transitions=len(dqn.memory),
        decisions_after_first_update=sum(r.get('controller_updates_before_decision',0)>0 for r in actions),
        executed_releases=int(finished.sum()),empty_rounds=int(np.sum(schedule.sum(axis=1)==0)),
        min_client_releases=int(finished.min()),max_client_releases=int(finished.max()),
        rho_capacity=filt.capacity,max_recorded_rho=float(filt.spent.max()),
        protocol_eligible=protocol_eligible,seconds=time.perf_counter()-started)
    if cfg.benchmark_diagnostics:
        summary.update({'benchmark_local_'+key:value for key,value in average_metrics(local_final).items()})
    save_json(out/'training_summary.json',summary)
    return summary

def evaluate_common_test(prepared,cfg,out):
    """Only called by explicit evaluate command after the protocol has been locked."""
    out=Path(out); model=np.load(out/'released_model.npz',allow_pickle=False)
    template=MLP(model['dims'].tolist(),keyed_rng(0,'evaluation')); cut=2*len(cfg.encoder_dims)
    mean,rows,preds=public_scores(template,model['encoder'],list(model['heads']),cut,prepared,prepared.public_test)
    np.savez_compressed(out/'public_test_predictions.npz',indices=prepared.public_test,
                        y=prepared.y[prepared.public_test],probabilities=preds)
    pd.DataFrame([dict(client=i,**row) for i,row in enumerate(rows)]).to_csv(out/'common_test_head_metrics.csv',index=False)
    summary=dict(mean_head_ap=mean['mean_ap'],worst_head_ap=mean['worst_head_ap'],
                 head_ap_dispersion=mean['head_ap_dispersion'],common_test_evaluated=True,
                 **{'common_'+k:v for k,v in mean.items()})
    save_json(out/'common_test_summary.json',summary)
    return summary

'''

MODULES['requirements-tested.txt'] = r'''numpy==2.3.5
pandas==2.2.3
scipy==1.17.0
scikit-learn==1.8.0
matplotlib==3.10.8
'''

MODULES['requirements.txt'] = r'''numpy>=1.24,<3
pandas>=1.5,<4
scipy>=1.10,<2
scikit-learn>=1.3,<2
matplotlib>=3.6,<4
'''

MODULES['run.py'] = r'''#!/usr/bin/env python3
"""Commands: test, lock, train, evaluate, analyze, package. See README.md."""
from __future__ import annotations
# Set before importing NumPy. This avoids CPU oversubscription in local/Colab runs.
import os
for _key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[_key]='1'
import sys
import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import time
from pathlib import Path
from dataclasses import asdict
import importlib.metadata
from core import Config,canonical,digest,save_json
from data import prepare, SPECS
from experiment import train,evaluate_common_test
from analyze import analyze

BASE=Path(__file__).resolve().parent
SOURCE_NAMES=['core.py','data.py','experiment.py','analyze.py','run.py','test_correctness.py']

def load_config(path): return Config(**json.loads(Path(path).read_text())).validate()

def source_hashes():
    return {p:hashlib.sha256((BASE/p).read_bytes()).hexdigest() for p in SOURCE_NAMES}

def protocol_lock(cfg,out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    body=dict(config=asdict(cfg),sources=source_hashes(),
        primary_outcome='mean personalised-head AP on the fixed common test set',
        privacy_unit='replacement of all local records/state of one enrolled client',
        observer='honest-but-curious server seeing every protected message; client raw states excluded',
        evaluation_scope='public common test; separately protected local heldout metrics',
        previous_benchmark_use=cfg.acknowledge_reused_benchmarks,
        independence_note='Previously studied datasets; a new split is not an untouched external cohort.',
        noninferiority_margin=cfg.noninferiority_margin,
        noninferiority_justification=cfg.noninferiority_justification)
    fingerprint=digest(body)
    path=out/'protocol_lock.json'
    if path.exists():
        existing=json.loads(path.read_text())
        if existing['fingerprint']!=fingerprint:
            raise RuntimeError('Locked source/configuration changed. Use a NEW output directory and disclose the new protocol.')
        return existing
    body.update(fingerprint=fingerprint,locked_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    save_json(path,body)
    snapshot=out/'executed_source'; snapshot.mkdir(exist_ok=True)
    for p in SOURCE_NAMES: shutil.copy2(BASE/p,snapshot/p)
    save_json(snapshot/'executed_config.json',asdict(cfg))
    packages={}
    for p in ['numpy','pandas','scipy','scikit-learn','matplotlib']:
        try: packages[p]=importlib.metadata.version(p)
        except importlib.metadata.PackageNotFoundError: packages[p]='missing'
    save_json(out/'environment.json',dict(python=sys.version,platform=platform.platform(),packages=packages))
    try:
        frozen=subprocess.run([sys.executable,'-m','pip','freeze'],capture_output=True,text=True,check=True)
        (out/'environment_freeze.txt').write_text(frozen.stdout)
    except (subprocess.CalledProcessError,FileNotFoundError): pass
    return body

def run_id(dataset,seed,alpha,eps,method):
    return f'{dataset}__seed{seed}__alpha{alpha:g}__eps{eps:g}__{method}'

def iter_runs(cfg):
    for dataset in cfg.datasets:
        for seed in cfg.seeds:
            for alpha in cfg.alphas:
                for eps in cfg.epsilon_targets:
                    for method in cfg.methods: yield dataset,seed,alpha,eps,method

def execute(cfg,out,cache,command):
    out=Path(out); protocol_lock(cfg,out); previous=None; prepared=None
    planned=list(iter_runs(cfg)); failures=[]
    for index,(dataset,seed,alpha,eps,method) in enumerate(planned,1):
        identity=run_id(dataset,seed,alpha,eps,method); folder=out/'runs'/identity
        marker=folder/('training_summary.json' if command=='train' else 'common_test_summary.json')
        if marker.exists():
            print(f'[{index}/{len(planned)}] cached {identity}',flush=True); continue
        if command=='evaluate' and not (folder/'training_summary.json').exists():
            failures.append(dict(run=identity,error='training incomplete')); continue
        key=(dataset,seed,alpha)
        if key!=previous:
            destination=out/'partitions'/f'{dataset}_{seed}_{alpha:g}'
            prepared=prepare(dataset,cfg,seed,alpha,cache,destination); previous=key
            provenance_file=destination/'input_provenance.json'
            new=dict(source_hash=prepared.audit['source']['csv_sha256'],partition_hash=prepared.partition_hash)
            if provenance_file.exists() and json.loads(provenance_file.read_text())!=new:
                raise RuntimeError('Dataset/partition changed after lock; refuse train/evaluate.')
            # Hashes identify exact public benchmark inputs. No sensitive-data deployment supported.
            save_json(provenance_file,new)
        print(f'[{index}/{len(planned)}] {command} {identity}',flush=True)
        if command=='train':
            train(prepared,cfg,method,seed,alpha,eps,folder)
        else: evaluate_common_test(prepared,cfg,folder)
    completed=sum((out/'runs'/run_id(*r)/('training_summary.json' if command=='train' else 'common_test_summary.json')).exists() for r in planned)
    save_json(out/(command+'_completion.json'),dict(expected=len(planned),completed=completed,missing=failures))
    if failures: raise RuntimeError(f'{len(failures)} runs lack training; see {command}_completion.json')
    print(f'{command}: {completed}/{len(planned)} complete',flush=True)

def package(out):
    out=Path(out).resolve()
    # The complete research bundle includes clearly marked public-benchmark diagnostics.
    zip_path=shutil.make_archive(str(out)+'_results','zip',root_dir=out.parent,base_dir=out.name)
    print(zip_path)
    return zip_path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['test','lock','train','evaluate','analyze','package'])
    parser.add_argument('--config',default=str(BASE/'configs/development.json'))
    parser.add_argument('--out',default=str(BASE/'results_development'))
    parser.add_argument('--cache',default=str(BASE/'data_cache'))
    args=parser.parse_args()
    if args.command=='test':
        result=subprocess.run([sys.executable,'-m','unittest','-v','test_correctness'],cwd=BASE)
        raise SystemExit(result.returncode)
    if args.command=='package': package(args.out); return
    cfg=load_config(args.config)
    if args.command=='lock':
        lock=protocol_lock(cfg,args.out); print('Locked:',lock['fingerprint'])
        print('Planned runs:',len(list(iter_runs(cfg))))
    elif args.command in ['train','evaluate']: execute(cfg,args.out,args.cache,args.command)
    else:
        protocol_lock(cfg,args.out); print(analyze(args.out,cfg))

if __name__=='__main__': main()

'''

MODULES['test_correctness.py'] = r'''"""Deterministic correctness tests, including mathematical and protocol invariants."""
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from core import (Config,metrics,PrivacyFilter,project_l2,MLP,focal_loss_gradient,
    DoubleDQN,make_context,keyed_rng,ACTIONS,method_spec)
from data import PublicPreprocessor,encode_target,prepare,EXCLUSIONS
from experiment import train,evaluate_common_test,allocations,action_costs
from analyze import paired_interval,holm

def small_config(**kw):
    opts=dict(profile='smoke',datasets=['synthetic'],methods=['dpcast'],seeds=[17],alphas=[.5],
        epsilon_targets=[8.],clients=4,rounds=8,local_epochs=1,batch_size=64,
        encoder_dims=[8,4],head_hidden=4,dropout=0.,max_rows=240,
        rl_batch=4,rl_warmup=4,rl_updates_per_round=2,benchmark_diagnostics=False,
        bootstrap_reps=100)
    opts.update(kw); return Config(**opts).validate()

class MetricsTests(unittest.TestCase):
    def test_constant_scores_equal_prevalence(self):
        y=np.array([0,1,0,0,1,0]); self.assertAlmostEqual(metrics(y,np.ones(6)*.3)['ap'],y.mean())

    def test_ties_permutation_invariance(self):
        y=np.array([0,1,0,1,0,1,1]); p=np.array([.2,.2,.8,.8,.8,.3,.3]); base=metrics(y,p)['ap']
        rng=keyed_rng(1)
        for _ in range(30):
            ix=rng.permutation(len(y)); self.assertAlmostEqual(metrics(y[ix],p[ix])['ap'],base)

    def test_undefined_and_empty(self):
        self.assertTrue(np.isnan(metrics([0,0],[.1,.2])['ap']))
        self.assertTrue(np.isnan(metrics([1,1],[.1,.2])['auroc']))
        self.assertEqual(metrics([],[])['undefined_reason'],'empty')

class PrivacyTests(unittest.TestCase):
    def test_gaussian_cost_and_fixed_bound(self):
        f=PrivacyFilter(3,8.,1e-5); c=f.capacity/10
        z=f.release(np.zeros(2),0,'test',c,0,2.,keyed_rng(1),reserve=f.capacity/2)
        self.assertEqual(z.shape,(2,)); self.assertAlmostEqual(f.events[-1]['noise_sd'],2/np.sqrt(2*c))
        self.assertAlmostEqual(f.certificate()['bound_at_fixed_order'],8.)

    def test_refusal_before_rng_or_ledger_change(self):
        class ForbiddenRNG:
            def normal(self,*args): raise AssertionError('Noise was drawn before the budget guard')
        f=PrivacyFilter(2,1.,1e-5)
        with self.assertRaises(RuntimeError): f.release(1.,0,'test',f.capacity*2,0,1.,ForbiddenRNG())
        self.assertEqual(len(f.events),0); self.assertEqual(f.spent.sum(),0)

    def test_reservation_and_exact_boundary(self):
        f=PrivacyFilter(2,4.,1e-5)
        self.assertTrue(f.feasible(0,.6*f.capacity,.4*f.capacity))
        self.assertFalse(f.feasible(0,.6*f.capacity,.401*f.capacity))
        f.charge(0,'a',.9*f.capacity,0,1.)
        f.charge(0,'final',.1*f.capacity,1,1.)
        self.assertFalse(f.feasible(0,.01*f.capacity))

    def test_replacement_sensitivities(self):
        rng=keyed_rng(99)
        for _ in range(30):
            a=project_l2(rng.normal(size=100),.05); b=project_l2(rng.normal(size=100),.05)
            self.assertLessEqual(np.linalg.norm(a-b),.1+1e-12)
        self.assertAlmostEqual(np.linalg.norm(np.ones(5)-np.zeros(5)),np.sqrt(5))

    def test_adaptive_budget_actions_and_reserve(self):
        f=PrivacyFilter(2,8.,1e-5); c=small_config(); pool=allocations(c,method_spec('dpcast'),f.capacity)
        spent=0.; n=10
        for remaining in reversed(range(1,n+1)):
            candidates=action_costs(pool['update'],spent,remaining)
            minimum_future=(remaining-1)*pool['update']/n*.5
            valid=candidates+spent+minimum_future<=pool['update']+1e-12
            self.assertTrue(valid.any()); cost=candidates[np.flatnonzero(valid)[-1]]; spent+=cost
        self.assertLessEqual(spent,pool['update']+1e-12)

class NeuralTests(unittest.TestCase):
    def test_focal_gradient_finite_difference(self):
        z=np.array([[-2.],[.4],[1.2]]); y=np.array([0,1,0]); _,grad=focal_loss_gradient(z,y)
        h=1e-5
        for i in range(3):
            a=z.copy();b=z.copy();a[i]+=h;b[i]-=h
            numerical=(focal_loss_gradient(a,y)[0]-focal_loss_gradient(b,y)[0])/(2*h)
            self.assertAlmostEqual(numerical,grad[i,0],places=7)

    def test_network_backprop_finite_difference(self):
        m=MLP([2,3,1],keyed_rng(9)); x=np.array([[.3,.8],[.7,-.2]]); y=np.array([0,1])
        z,cache=m.forward(x); _,grad=focal_loss_gradient(z,y); actual=m.backward(grad,cache)
        h=1e-5
        for p,g in zip(m.params,actual):
            for ix in np.ndindex(p.shape):
                old=p[ix];p[ix]=old+h;a=focal_loss_gradient(m.forward(x)[0],y)[0]
                p[ix]=old-h;b=focal_loss_gradient(m.forward(x)[0],y)[0];p[ix]=old
                self.assertAlmostEqual((a-b)/(2*h),g[ix],places=6)

    def test_focal_extreme_logits_finite(self):
        loss,g=focal_loss_gradient(np.array([[-1e4],[1e4]]),[1,0])
        self.assertTrue(np.isfinite(loss)); self.assertTrue(np.isfinite(g).all())

    def test_dqn_updates_and_masks(self):
        cfg=small_config(); q=DoubleDQN(cfg,2); s=np.ones(8)*.2; mask=np.zeros(15,bool); mask[4]=True
        self.assertEqual(q.greedy(s,mask),4)
        before=q.q.vector().copy()
        for _ in range(8): q.add(s,4,1.,s,False,mask)
        self.assertTrue(np.isfinite(q.learn())); self.assertGreater(np.linalg.norm(q.q.vector()-before),0)
        self.assertTrue(np.array_equal(q.frozen.vector(),before))

class DataTests(unittest.TestCase):
    def test_mapping_is_strict(self):
        self.assertTrue(np.array_equal(encode_target(pd.Series(['LGG','GBM']),'Glioma'),[0,1]))
        with self.assertRaises(ValueError): encode_target(pd.Series([1,2]),'Cervical')

    def test_reference_only_and_unknown_categories(self):
        a=pd.DataFrame({'n':[1.,2.,np.nan],'c':['A','B',None]})
        p=PublicPreprocessor().fit(a,['c']); before=json.dumps(p.specs)
        b=pd.DataFrame({'n':[1e20],'c':['PRIVATE_ONLY_CATEGORY']}); x=p.transform(b)
        self.assertEqual(json.dumps(p.specs),before); self.assertTrue(np.isfinite(x).all())
        self.assertEqual(x[0,-2],1.)

    def test_partition_disjoint_and_fixed_test(self):
        cfg=small_config()
        with tempfile.TemporaryDirectory() as d:
            a=prepare('synthetic',cfg,1,.1,d,Path(d)/'a')
            b=prepare('synthetic',cfg,2,.1,d,Path(d)/'b')
            self.assertTrue(np.array_equal(a.public_test,b.public_test))
            self.assertNotEqual(a.partition_hash,b.partition_hash)
            allidx=np.concatenate([a.public_val,a.public_test,*a.client_train,*a.client_test])
            self.assertEqual(len(np.unique(allidx)),len(a.y))
            self.assertFalse((Path(d)/'a/dataset_audit_BENCHMARK_ONLY.json').exists())

    def test_leakage_exclusions(self):
        self.assertIn('death',EXCLUSIONS['SUPPORT2']); self.assertIn('d.time',EXCLUSIONS['SUPPORT2'])
        self.assertIn('Case_ID',EXCLUSIONS['Glioma']); self.assertIn('Hinselmann',EXCLUSIONS['Cervical'])

class InferenceTests(unittest.TestCase):
    def test_holm_and_paired_interval(self):
        self.assertTrue(np.allclose(holm([.01,.04,.03]),[.03,.06,.06]))
        a=paired_interval([.01,.02,.03,.04,.05],keyed_rng(2),200)
        self.assertAlmostEqual(a['mean'],.03); self.assertGreater(a['ci_width'],0)
        self.assertEqual(a['n'],5)

class IntegrationTests(unittest.TestCase):
    def test_protected_transcript_replay_and_no_test_peeking(self):
        cfg=small_config()
        with tempfile.TemporaryDirectory() as d:
            p=prepare('synthetic',cfg,17,.5,d,Path(d)/'partition'); out=Path(d)/'run'
            s=train(p,cfg,'dpcast',17,.5,8.,out)
            self.assertGreater(s['controller_updates'],0)
            self.assertGreater(s['decisions_after_first_update'],0)
            self.assertFalse((out/'public_test_predictions.npz').exists())
            self.assertFalse((out/'BENCHMARK_ONLY_NOT_PRIVATE').exists())
            ledger=pd.read_csv(out/'ledger.csv')
            self.assertLessEqual(ledger.cumulative_charged_rho.max(),s['rho_capacity']+1e-12)
            self.assertEqual(int((ledger.mechanism=='local_evaluation').sum()),cfg.clients)
            action=pd.read_csv(out/'actions.csv'); replay=pd.read_csv(out/'replay_index.csv')
            for _,r in replay.iterrows():
                match=action[(action.client==r.client)&(action['round']==r.source_round)]
                self.assertEqual(int(match.iloc[0].executed_action),r.executed_action)
            e=evaluate_common_test(p,cfg,out)
            self.assertTrue(0<=e['mean_head_ap']<=1)

    def test_all_controls_and_empty_rounds(self):
        cfg=small_config(rounds=2,participation=.00001,benchmark_diagnostics=True,reproducible_noise=True)
        methods=['fixed','adaptive_clip','rule','random','frozen','dpcast','constant','noise_only',
                 'constant_realloc','noise_only_realloc','drop_0','drop_2_realloc','raw_context','nonprivate']
        with tempfile.TemporaryDirectory() as d:
            p=prepare('synthetic',cfg,17,.5,d,Path(d)/'partition')
            for method in methods:
                s=train(p,cfg,method,17,.5,8.,Path(d)/method)
                self.assertEqual(s['executed_releases'],0); self.assertEqual(s['empty_rounds'],2)

if __name__=='__main__': unittest.main(verbosity=2)

'''

# Materialise exact source. Existing files from another version are never overwritten.
for name, source in MODULES.items():
    destination = project/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and destination.read_text() != source:
        raise RuntimeError(f"Existing source differs: {destination}. Choose a new WORKDIR for this version.")
    destination.write_text(source)

# Use standard scientific Python packages already present in most Colab runtimes.
needed = [package for module, package in [("numpy","numpy>=1.24,<3"),
    ("pandas","pandas>=1.5,<4"), ("scipy","scipy>=1.10,<2"),
    ("sklearn","scikit-learn>=1.3,<2"), ("matplotlib","matplotlib>=3.6,<4")]
    if importlib.util.find_spec(module) is None]
if needed:
    subprocess.run([sys.executable,"-m","pip","install",*needed],check=True)

config = project/"configs"/(PROFILE+".json")
if not config.exists():
    raise ValueError("Unknown PROFILE. Choose one of: " + ", ".join(p.stem for p in (project/"configs").glob("*.json")))
results = workspace/("results_"+PROFILE)
def command(name):
    subprocess.run([sys.executable,str(project/"run.py"),name,
        "--config",str(config),"--out",str(results),"--cache",str(workspace/"data_cache")],check=True)
command("test")
command("lock")
command("train")
if RUN_FINAL_TEST:
    command("evaluate")
    command("analyze")
else:
    print("Training completed. The common test set was not evaluated. Review validation trajectories before final evaluation.")
command("package")
archive = Path(str(results)+"_results.zip")
print("Results:",results)
print("Download:",archive)
if DOWNLOAD_RESULTS and IN_COLAB:
    from google.colab import files
    files.download(str(archive))
