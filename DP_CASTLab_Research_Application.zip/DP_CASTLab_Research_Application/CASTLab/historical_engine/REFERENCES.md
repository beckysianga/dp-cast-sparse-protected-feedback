# Technical and data sources

These primary sources informed the implementation. They do not establish priority or novelty of this package's combined protocol. The two uploaded files are the task specifications; the corrected code deliberately changes mechanisms identified as invalid or incomplete in the supplied review.

1. Ilya Mironov. **Renyi Differential Privacy**. IEEE CSF, 2017. https://arxiv.org/abs/1702.07476
2. Mathias Lécuyer. **Practical Privacy Filters and Odometers with Renyi Differential Privacy and Applications to Differentially Private Deep Learning**. 2021. https://arxiv.org/abs/2103.01379
3. Galen Andrew, Om Thakkar, H. Brendan McMahan and Swaroop Ramaswamy. **Differentially Private Learning with Adaptive Clipping**. NeurIPS, 2021. https://arxiv.org/abs/1905.03871
4. Hado van Hasselt, Arthur Guez and David Silver. **Deep Reinforcement Learning with Double Q-learning**. AAAI, 2016. https://arxiv.org/abs/1509.06461
5. Tsung-Yi Lin, Priya Goyal, Ross Girshick, Kaiming He and Piotr Dollár. **Focal Loss for Dense Object Detection**. ICCV, 2017. https://arxiv.org/abs/1708.02002
6. scikit-learn. **average_precision_score API**. Non-interpolated AP and its distinction from trapezoidal PR-AUC. https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html
7. UCI Machine Learning Repository. **CDC Diabetes Health Indicators**, dataset 891. https://archive.ics.uci.edu/dataset/891/cdc+diabetes+health+indicators ; https://doi.org/10.24432/C53919
8. K. Fernandes, J. S. Cardoso and J. Fernandes. **Cervical Cancer Risk Factors**, dataset 383. UCI, 2017. https://archive.ics.uci.edu/dataset/383/cervical+cancer+risk+factors ; https://doi.org/10.24432/C5Z310
9. E. Tasci, K. Camphausen, A. Krauze and Y. Zhuge. **Glioma Grading Clinical and Mutation Features**, dataset 759. UCI, 2022. https://archive.ics.uci.edu/dataset/759/glioma-grading-clinical-and-mutation-features-dataset ; https://doi.org/10.24432/C5R62J
10. UCI Machine Learning Repository. **SUPPORT2**, dataset 880. https://archive.ics.uci.edu/dataset/880/support2
11. Frank Harrell's HBiostat repository. **SUPPORT dataset description**. Assessment timing, outcome variables and model/prognosis feature exclusions. https://hbiostat.org/data/repo/supportdesc

Respect the datasets' source-specific licences and acknowledgement requirements. The code downloads the official data at execution; the source ZIP does not redistribute the raw CSVs.

