"""DP-CAST research primitives. NumPy reference implementation, Python 3.10+.

The RDP filter certifies a PREDECLARED bound under the ideal Gaussian protocol.
The observed spend is a ledger, not an adaptively selected privacy odometer.
This single-process simulator is not a hospital deployment or secure aggregator.
"""
from __future__ import annotations
import copy
import hashlib
import json
import math
from collections import deque
from dataclasses import dataclass, asdict, field
from pathlib import Path
import numpy as np
from scipy.special import expit
from sklearn.metrics import average_precision_score, roc_auc_score

CONTEXT_NAMES = ['sensitivity_score', 'representation_change', 'uncertainty',
                 'imbalance', 'update_deviation']
METRIC_NAMES = ['ap', 'auroc', 'f1', 'recall', 'specificity', 'balanced_accuracy']
ACTION_FACTORS = np.array([.50, .75, 1., 1.50, 2.])
CLIP_FACTORS = np.array([.75, 1., 1.25])
ACTIONS = [(float(a), float(c)) for a in ACTION_FACTORS for c in CLIP_FACTORS]
DEFAULT_ACTION = ACTIONS.index((1., 1.))

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(obj):
    return hashlib.sha256(canonical(obj).encode()).hexdigest()

def keyed_rng(seed, *keys):
    key = hashlib.sha256(canonical([int(seed), *keys]).encode()).digest()
    return np.random.default_rng(int.from_bytes(key[:16], 'little'))

def jsonable(x):
    if isinstance(x, dict): return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [jsonable(v) for v in x]
    if isinstance(x, np.ndarray): return jsonable(x.tolist())
    if isinstance(x, np.generic): return jsonable(x.item())
    if isinstance(x, float) and not math.isfinite(x): return None
    return x

def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(jsonable(obj), indent=2, sort_keys=True))
    tmp.replace(path)

@dataclass
class Config:
    profile: str = 'development'
    datasets: list = field(default_factory=lambda: ['CDC_Diabetes', 'Cervical', 'Glioma', 'SUPPORT2'])
    methods: list = field(default_factory=lambda: ['nonprivate', 'fixed', 'adaptive_clip',
        'rule', 'random', 'frozen', 'dpcast'])
    seeds: list = field(default_factory=lambda: [42, 52, 62, 72, 82])
    alphas: list = field(default_factory=lambda: [.1, .5, 1.])
    epsilon_targets: list = field(default_factory=lambda: [4., 8., 16.])
    clients: int = 8
    participation: float = .75
    rounds: int = 100
    local_epochs: int = 2
    batch_size: int = 256
    local_lr: float = .001
    server_lr: float = 1.
    encoder_dims: list = field(default_factory=lambda: [128, 64, 32])
    head_hidden: int = 32
    dropout: float = .1
    focal_alpha: float = .75
    focal_gamma: float = 2.
    delta: float = 1e-5
    clip_init: float = .05
    clip_min: float = .005
    clip_max: float = .5
    clip_lr: float = .2
    clip_quantile: float = .8
    context_fraction: float = .15
    clip_fraction: float = .05
    evaluation_fraction: float = .10
    central_postprocess_sigma: float = 0.
    release_projection_radius: float = 1.
    rl_batch: int = 32
    rl_warmup: int = 32
    rl_updates_per_round: int = 4
    rl_lr: float = .001
    rl_gamma: float = .95
    rl_target_interval: int = 10
    rl_capacity: int = 10000
    exploration_start: float = 1.
    exploration_end: float = .05
    exploration_decay_fraction: float = .7
    reward_gain_weight: float = .6
    reward_privacy_weight: float = .1
    reward_change_weight: float = .1
    reward_recall_weight: float = .1
    reward_risk_weight: float = .1
    gain_scale: float = .1
    public_val_fraction: float = .1
    public_test_fraction: float = .1
    local_test_fraction: float = .2
    split_seed: int = 20261011
    max_rows: int | None = None
    max_public_eval_rows: int | None = None
    benchmark_diagnostics: bool = True
    reproducible_noise: bool = False
    acknowledge_reused_benchmarks: bool = True
    noninferiority_margin: float | None = None
    noninferiority_justification: str = ''
    bootstrap_reps: int = 10000

    def validate(self):
        assert self.clients > 1 and self.rounds > 0 and self.local_epochs > 0
        assert self.batch_size > 0 and self.rl_batch > 0 and self.rl_warmup >= self.rl_batch
        assert 0 < self.participation <= 1 and 0 < self.delta < 1
        assert 0 < self.clip_min <= self.clip_init <= self.clip_max
        assert 0 <= self.dropout < 1 and 0 < self.focal_alpha < 1
        assert 0 < self.public_val_fraction < 1 and 0 < self.public_test_fraction < 1
        assert self.public_val_fraction + self.public_test_fraction < 1
        assert 0 < self.local_test_fraction < 1
        assert self.evaluation_fraction > 0 and self.context_fraction > 0 and self.clip_fraction > 0
        assert self.evaluation_fraction + self.context_fraction + self.clip_fraction < 1
        assert all(a > 0 for a in self.alphas) and all(e > 0 for e in self.epsilon_targets)
        assert self.central_postprocess_sigma >= 0 and self.release_projection_radius > 0
        if self.noninferiority_margin is not None:
            assert 0 < self.noninferiority_margin < 1 and self.noninferiority_justification.strip()
        for method in self.methods: method_spec(method)
        if self.profile == 'publication':
            assert len(self.seeds) >= 5, 'At least five independent training/partition seeds.'
            assert self.max_rows is None, 'Publication profile must not silently truncate data.'
            assert not self.reproducible_noise, 'Published DP noise seeds invalidate a private release.'
        if self.reproducible_noise and not self.benchmark_diagnostics:
            raise ValueError('Deterministic public noise seeds are for public-benchmark diagnostics only.')
        return self

def method_spec(name):
    base = dict(private=True, adaptive=True, controller='trained', context='protected',
                drop=None, reallocate=False)
    if name == 'nonprivate': base.update(private=False, adaptive=False, controller='fixed', context='none')
    elif name == 'fixed': base.update(adaptive=False, controller='fixed', context='none')
    elif name == 'adaptive_clip': base.update(controller='fixed', context='none')
    elif name in ['rule', 'random', 'frozen']: base['controller'] = name
    elif name == 'dpcast': pass
    elif name == 'raw_context': base['context'] = 'raw'
    elif name in ['constant', 'noise_only', 'constant_realloc', 'noise_only_realloc']:
        base['context'] = name.split('_realloc')[0]; base['reallocate'] = name.endswith('_realloc')
    elif name.startswith('drop_'):
        pieces = name.split('_'); base['drop'] = int(pieces[1])
        if base['drop'] not in range(5): raise ValueError(name)
        base['reallocate'] = name.endswith('_realloc')
    else: raise ValueError(f'Unknown method: {name}')
    return base

def metrics(y, p):
    y = np.asarray(y, dtype=int); p = np.asarray(p, dtype=float)
    if len(y) != len(p) or not np.isfinite(p).all(): raise ValueError('Invalid predictions')
    if not np.isin(y, [0, 1]).all(): raise ValueError('Binary target required')
    n = len(y); pos = int(y.sum()); neg = n-pos
    pred = p >= .5
    tp = int(np.sum(pred & (y == 1))); fp = int(np.sum(pred & (y == 0)))
    fn = pos-tp; tn = neg-fp
    # AP has no positive-class retrieval interpretation if no positives exist.
    ap = float(average_precision_score(y, p)) if pos else np.nan
    auc = float(roc_auc_score(y, p)) if pos and neg else np.nan
    recall = tp/pos if pos else np.nan
    spec = tn/neg if neg else np.nan
    f1 = 2*tp/(2*tp+fp+fn) if (2*tp+fp+fn) else np.nan
    balanced = (recall+spec)/2 if pos and neg else np.nan
    reason = ('empty' if not n else 'no_positives' if not pos else 'no_negatives' if not neg else '')
    return dict(zip(METRIC_NAMES, [ap, auc, f1, recall, spec, balanced]),
                n=n, positives=pos, negatives=neg, undefined_reason=reason)

def average_metrics(rows):
    out = {}
    for k in METRIC_NAMES:
        a = np.array([r[k] for r in rows], dtype=float); a = a[np.isfinite(a)]
        out['mean_'+k] = float(a.mean()) if len(a) else np.nan
        out['valid_'+k] = int(len(a))
    a = np.array([r['ap'] for r in rows]); a = a[np.isfinite(a)]
    out['worst_head_ap'] = float(a.min()) if len(a) else np.nan
    out['head_ap_dispersion'] = float(a.std(ddof=0)) if len(a) else np.nan
    return out

class PrivacyFilter:
    """Fixed-order adaptive RDP filter (Lecuyer 2021, Theorem 1).

    Cost is rho=Delta^2/(2*s^2); RDP at the fixed order is alpha*rho.
    Alpha is selected from public epsilon/delta BEFORE any data interaction.
    Each enrolled client has its own replacement-adjacency ledger. No amplification.
    """
    def __init__(self, clients, epsilon, delta):
        self.epsilon = float(epsilon); self.delta = float(delta)
        orders = np.r_[np.arange(1.25, 10, .25), np.arange(10., 65.), [96., 128., 192., 256., 512.]]
        capacities = (epsilon - np.log(1/delta)/(orders-1))/orders
        idx = int(np.argmax(capacities)); self.order = float(orders[idx])
        self.capacity = float(capacities[idx])
        if self.capacity <= 0: raise ValueError('No positive RDP capacity')
        self.spent = np.zeros(clients, dtype=float); self.events = []

    def feasible(self, client, cost, reserve=0.):
        return (np.isfinite(cost) and cost >= 0 and np.isfinite(reserve) and reserve >= 0
                and self.spent[client] + cost + reserve <= self.capacity + 1e-12*self.capacity)

    def charge(self, client, mechanism, cost, round_id, sensitivity, reserve=0., actual_query=True):
        if not self.feasible(client, cost, reserve):
            raise RuntimeError(f'Privacy filter refused {mechanism} BEFORE release')
        if cost <= 0 or sensitivity <= 0: raise ValueError('Gaussian query requires positive cost and bound')
        self.spent[client] += cost
        self.events.append(dict(client=client, round=round_id, mechanism=mechanism,
            charged_rho=cost, ideal_gaussian_rho=cost if actual_query else 0.,
            rdp_at_fixed_order=self.order*cost, cumulative_charged_rho=self.spent[client],
            reserved_rho=reserve, sensitivity=sensitivity,
            noise_sd=sensitivity/math.sqrt(2*cost), alpha=self.order,
            epsilon_cap=self.epsilon, delta=self.delta))

    def release(self, value, client, mechanism, cost, round_id, sensitivity, rng, reserve=0., actual_query=True):
        # Charge/guard before drawing noise or exposing a value.
        self.charge(client, mechanism, cost, round_id, sensitivity, reserve, actual_query)
        return np.asarray(value, float) + rng.normal(0., sensitivity/math.sqrt(2*cost), np.shape(value))

    def certificate(self):
        return dict(epsilon_cap=self.epsilon, delta=self.delta, fixed_rdp_order=self.order,
                    rho_capacity=self.capacity, rho_spent_per_client=self.spent.tolist(),
                    bound_at_fixed_order=self.order*self.capacity+np.log(1/self.delta)/(self.order-1),
                    observed_spend_is_not_an_odometer=True, sampling_amplification=False)

def project_l2(v, radius):
    v = np.asarray(v, dtype=float)
    return v * min(1., radius/max(float(np.linalg.norm(v)), 1e-300))

def focal_loss_gradient(logit, y, alpha=.75, gamma=2.):
    y = np.asarray(y, float).reshape(-1, 1)
    z = np.asarray(logit, float).reshape(-1, 1)
    sign = 2*y-1
    pt = expit(sign*z)
    logpt = -np.logaddexp(0., -sign*z)
    weight = np.where(y == 1, alpha, 1-alpha)
    loss = -weight*(1-pt)**gamma*logpt
    # Exact stable derivative; no log(p) clipping mismatch with the loss.
    grad = weight*sign*(1-pt)**gamma*(gamma*pt*logpt-(1-pt))/max(len(y), 1)
    return float(loss.mean()), grad

class MLP:
    """Dense ReLU network with exact backpropagation and explicit Adam state."""
    def __init__(self, dims, rng, dropout=0., dropout_layers=()):
        self.dims = list(dims); self.dropout = dropout; self.dropout_layers = set(dropout_layers)
        self.params = []
        for i, (a,b) in enumerate(zip(dims[:-1], dims[1:])):
            scale = np.sqrt((2. if i < len(dims)-2 else 1.)/a)
            self.params += [rng.normal(0, scale, (a,b)), np.zeros(b)]
        self.m = [np.zeros_like(p) for p in self.params]
        self.v = [np.zeros_like(p) for p in self.params]; self.steps = 0

    def copy(self): return copy.deepcopy(self)

    def vector(self, start=0, stop=None):
        return np.concatenate([p.ravel() for p in self.params[start:stop]])

    def set_vector(self, vec, start=0, stop=None):
        chosen = self.params[start:stop]; offset = 0
        for p in chosen:
            p[:] = vec[offset:offset+p.size].reshape(p.shape); offset += p.size
        if offset != len(vec): raise ValueError('Parameter vector length mismatch')

    def forward(self, x, training=False, rng=None):
        a = np.asarray(x, float); cache = []; n_layers = len(self.params)//2
        for l in range(n_layers):
            w,b = self.params[2*l:2*l+2]; z = a@w+b; mask = None
            if l < n_layers-1:
                h = np.maximum(z, 0)
                if training and l in self.dropout_layers and self.dropout:
                    mask = (rng.random(h.shape) >= self.dropout)/(1-self.dropout); h *= mask
            else: h = z
            cache.append((a,z,mask)); a = h
        return a, cache

    def backward(self, grad, cache):
        grads = [None]*len(self.params)
        for l in reversed(range(len(cache))):
            a,z,mask = cache[l]
            if l < len(cache)-1:
                if mask is not None: grad = grad*mask
                grad = grad*(z>0)
            grads[2*l] = a.T@grad; grads[2*l+1] = grad.sum(axis=0)
            grad = grad@self.params[2*l].T
        return grads

    def adam(self, grads, lr, clip_norm=10.):
        norm = np.sqrt(sum(float(np.sum(g*g)) for g in grads))
        factor = min(1., clip_norm/max(norm, 1e-300)); self.steps += 1
        for j,g in enumerate(grads):
            g = g*factor; self.m[j] = .9*self.m[j]+.1*g; self.v[j] = .999*self.v[j]+.001*g*g
            self.params[j] -= lr*(self.m[j]/(1-.9**self.steps))/(np.sqrt(self.v[j]/(1-.999**self.steps))+1e-8)

    def fit_local(self, x, y, cfg, rng):
        if not len(y): return 0.
        loss_sum = 0.; batches = 0
        for _ in range(cfg.local_epochs):
            order = rng.permutation(len(y))
            for j in range(0, len(y), cfg.batch_size):
                ix = order[j:j+cfg.batch_size]
                z, cache = self.forward(x[ix], True, rng)
                loss, grad = focal_loss_gradient(z, y[ix], cfg.focal_alpha, cfg.focal_gamma)
                self.adam(self.backward(grad, cache), cfg.local_lr)
                loss_sum += loss; batches += 1
        return loss_sum/max(batches, 1)

    def predict(self, x, batch=4096):
        return np.concatenate([expit(self.forward(x[j:j+batch])[0][:,0])
            for j in range(0, len(x), batch)]) if len(x) else np.empty(0)

    def representation(self, x, encoder_layers=3):
        a = np.asarray(x, float)
        for l in range(encoder_layers): a = np.maximum(a@self.params[2*l]+self.params[2*l+1], 0.)
        return a

class DoubleDQN:
    def __init__(self, cfg, seed):
        self.cfg = cfg; self.q = MLP([8,64,32,len(ACTIONS)], keyed_rng(seed, 'q_init'))
        self.target = self.q.copy(); self.frozen = self.q.copy()
        self.memory = deque(maxlen=cfg.rl_capacity); self.updates = 0
        self.rng = keyed_rng(seed, 'q_replay')

    def greedy(self, state, mask, network=None):
        mask = np.asarray(mask, bool)
        if not mask.any(): return None
        scores = (network or self.q).forward(np.atleast_2d(state))[0][0]
        return int(np.argmax(np.where(mask, scores, -np.inf)))

    def add(self, state, executed_action, reward, next_state, done, next_mask, gap=1):
        assert 0 <= executed_action < len(ACTIONS)
        self.memory.append((np.asarray(state), int(executed_action), float(reward),
                            np.asarray(next_state), bool(done), np.asarray(next_mask, bool), int(gap)))

    def learn(self):
        if len(self.memory) < self.cfg.rl_warmup: return None
        ix = self.rng.choice(len(self.memory), self.cfg.rl_batch, replace=False)
        batch = [self.memory[int(i)] for i in ix]
        s = np.stack([b[0] for b in batch]); a = np.array([b[1] for b in batch])
        r = np.array([b[2] for b in batch]); ns = np.stack([b[3] for b in batch])
        done = np.array([b[4] for b in batch]); mask = np.stack([b[5] for b in batch])
        gap = np.array([b[6] for b in batch]); rows = np.arange(len(batch))
        online_next = self.q.forward(ns)[0]
        best = np.argmax(np.where(mask, online_next, -np.inf), axis=1)
        target_next = self.target.forward(ns)[0][rows, best]
        target = r + (~done & mask.any(axis=1))*(self.cfg.rl_gamma**gap)*target_next
        pred, cache = self.q.forward(s); err = pred[rows,a]-target
        loss = np.where(np.abs(err)<=1., .5*err**2, np.abs(err)-.5).mean()
        grad = np.zeros_like(pred); grad[rows,a] = np.clip(err,-1.,1.)/len(batch)
        self.q.adam(self.q.backward(grad,cache), self.cfg.rl_lr)
        self.updates += 1
        if self.updates % self.cfg.rl_target_interval == 0: self.target = self.q.copy()
        if not np.isfinite(loss): raise FloatingPointError('Non-finite Q loss')
        return float(loss)

def make_context(model, x, y, delta_encoder, clip_base, previous_mean, public_previous_update):
    if not len(y): return np.zeros(5), previous_mean
    rep = model.representation(x[:128], len(model.dims)-3)
    mean = rep.mean(axis=0); dispersion = np.linalg.norm(rep-mean, axis=1).mean()
    norm = float(np.linalg.norm(delta_encoder)); imbalance = abs(2*float(np.mean(y))-1)
    sensitivity_score = .4*min(1.,dispersion/2.)+.4*min(1.,norm/clip_base)+.2*imbalance
    change = 0. if previous_mean is None else min(1.,float(np.linalg.norm(mean-previous_mean)))
    p = np.clip(model.predict(x[:128]),1e-12,1-1e-12)
    uncertainty = float(np.mean(-(p*np.log(p)+(1-p)*np.log1p(-p))/np.log(2)))
    pn = float(np.linalg.norm(public_previous_update))
    directional = .5 if norm*pn == 0 else float(np.clip((1-np.dot(delta_encoder,public_previous_update)/(norm*pn))/2,0,1))
    # Public DP aggregate norm replaces the paper's raw cross-client median.
    deviation = .4*directional+.3*min(1.,abs(norm-pn)/.25)+.3*change
    return np.clip([sensitivity_score,change,uncertainty,imbalance,deviation],0.,1.), mean

