#!/usr/bin/env python3
"""Commands: test, lock, train, evaluate, analyze, package. See README.md."""
from __future__ import annotations
# Set before importing NumPy. This avoids CPU oversubscription in local/Colab runs.
import os
for _key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[_key]='1'
import sys
import argparse
import hashlib
import json
import platform
import shutil
import subprocess
import time
from pathlib import Path
from dataclasses import asdict
import importlib.metadata
from core import Config,canonical,digest,save_json
from data import prepare, SPECS
from experiment import train,evaluate_common_test
from analyze import analyze

BASE=Path(__file__).resolve().parent
SOURCE_NAMES=['core.py','data.py','experiment.py','analyze.py','run.py','test_correctness.py']

def load_config(path): return Config(**json.loads(Path(path).read_text())).validate()

def source_hashes():
    return {p:hashlib.sha256((BASE/p).read_bytes()).hexdigest() for p in SOURCE_NAMES}

def protocol_lock(cfg,out):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    body=dict(config=asdict(cfg),sources=source_hashes(),
        primary_outcome='mean personalised-head AP on the fixed common test set',
        privacy_unit='replacement of all local records/state of one enrolled client',
        observer='honest-but-curious server seeing every protected message; client raw states excluded',
        evaluation_scope='public common test; separately protected local heldout metrics',
        previous_benchmark_use=cfg.acknowledge_reused_benchmarks,
        independence_note='Previously studied datasets; a new split is not an untouched external cohort.',
        noninferiority_margin=cfg.noninferiority_margin,
        noninferiority_justification=cfg.noninferiority_justification)
    fingerprint=digest(body)
    path=out/'protocol_lock.json'
    if path.exists():
        existing=json.loads(path.read_text())
        if existing['fingerprint']!=fingerprint:
            raise RuntimeError('Locked source/configuration changed. Use a NEW output directory and disclose the new protocol.')
        return existing
    body.update(fingerprint=fingerprint,locked_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    save_json(path,body)
    snapshot=out/'executed_source'; snapshot.mkdir(exist_ok=True)
    for p in SOURCE_NAMES: shutil.copy2(BASE/p,snapshot/p)
    save_json(snapshot/'executed_config.json',asdict(cfg))
    packages={}
    for p in ['numpy','pandas','scipy','scikit-learn','matplotlib']:
        try: packages[p]=importlib.metadata.version(p)
        except importlib.metadata.PackageNotFoundError: packages[p]='missing'
    save_json(out/'environment.json',dict(python=sys.version,platform=platform.platform(),packages=packages))
    try:
        frozen=subprocess.run([sys.executable,'-m','pip','freeze'],capture_output=True,text=True,check=True)
        (out/'environment_freeze.txt').write_text(frozen.stdout)
    except (subprocess.CalledProcessError,FileNotFoundError): pass
    return body

def run_id(dataset,seed,alpha,eps,method):
    return f'{dataset}__seed{seed}__alpha{alpha:g}__eps{eps:g}__{method}'

def iter_runs(cfg):
    for dataset in cfg.datasets:
        for seed in cfg.seeds:
            for alpha in cfg.alphas:
                for eps in cfg.epsilon_targets:
                    for method in cfg.methods: yield dataset,seed,alpha,eps,method

def execute(cfg,out,cache,command):
    out=Path(out); protocol_lock(cfg,out); previous=None; prepared=None
    planned=list(iter_runs(cfg)); failures=[]
    for index,(dataset,seed,alpha,eps,method) in enumerate(planned,1):
        identity=run_id(dataset,seed,alpha,eps,method); folder=out/'runs'/identity
        marker=folder/('training_summary.json' if command=='train' else 'common_test_summary.json')
        if marker.exists():
            print(f'[{index}/{len(planned)}] cached {identity}',flush=True); continue
        if command=='evaluate' and not (folder/'training_summary.json').exists():
            failures.append(dict(run=identity,error='training incomplete')); continue
        key=(dataset,seed,alpha)
        if key!=previous:
            destination=out/'partitions'/f'{dataset}_{seed}_{alpha:g}'
            prepared=prepare(dataset,cfg,seed,alpha,cache,destination); previous=key
            provenance_file=destination/'input_provenance.json'
            new=dict(source_hash=prepared.audit['source']['csv_sha256'],partition_hash=prepared.partition_hash)
            if provenance_file.exists() and json.loads(provenance_file.read_text())!=new:
                raise RuntimeError('Dataset/partition changed after lock; refuse train/evaluate.')
            # Hashes identify exact public benchmark inputs. No sensitive-data deployment supported.
            save_json(provenance_file,new)
        print(f'[{index}/{len(planned)}] {command} {identity}',flush=True)
        if command=='train':
            train(prepared,cfg,method,seed,alpha,eps,folder)
        else: evaluate_common_test(prepared,cfg,folder)
    completed=sum((out/'runs'/run_id(*r)/('training_summary.json' if command=='train' else 'common_test_summary.json')).exists() for r in planned)
    save_json(out/(command+'_completion.json'),dict(expected=len(planned),completed=completed,missing=failures))
    if failures: raise RuntimeError(f'{len(failures)} runs lack training; see {command}_completion.json')
    print(f'{command}: {completed}/{len(planned)} complete',flush=True)

def package(out):
    out=Path(out).resolve()
    # The complete research bundle includes clearly marked public-benchmark diagnostics.
    zip_path=shutil.make_archive(str(out)+'_results','zip',root_dir=out.parent,base_dir=out.name)
    print(zip_path)
    return zip_path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['test','lock','train','evaluate','analyze','package'])
    parser.add_argument('--config',default=str(BASE/'configs/development.json'))
    parser.add_argument('--out',default=str(BASE/'results_development'))
    parser.add_argument('--cache',default=str(BASE/'data_cache'))
    args=parser.parse_args()
    if args.command=='test':
        result=subprocess.run([sys.executable,'-m','unittest','-v','test_correctness'],cwd=BASE)
        raise SystemExit(result.returncode)
    if args.command=='package': package(args.out); return
    cfg=load_config(args.config)
    if args.command=='lock':
        lock=protocol_lock(cfg,args.out); print('Locked:',lock['fingerprint'])
        print('Planned runs:',len(list(iter_runs(cfg))))
    elif args.command in ['train','evaluate']: execute(cfg,args.out,args.cache,args.command)
    else:
        protocol_lock(cfg,args.out); print(analyze(args.out,cfg))

if __name__=='__main__': main()

