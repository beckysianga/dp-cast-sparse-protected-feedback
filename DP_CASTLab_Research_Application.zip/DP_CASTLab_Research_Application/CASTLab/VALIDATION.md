# Validation — CASTLab

Validation completed on 14 October 2026, using Python 3.12 and the versions pinned in requirements.txt.

| Check | Observed result |
| --- | --- |
| All exposed research methods | 50 real synthetic training runs across two seeds passed |
| Functional API/worker/export checks | 22 checks passed |
| Mixed age/mutation input regression | Two additional actual training runs passed |
| Age and schema checks | 5 checks passed |
| Interface DOM execution | 11 checks passed with actual result fixtures |
| Saved prediction metrics | Recomputed and compared before completion |
| Original paper evidence audit | 462 consistency checks and 21 source hashes passed |
| JavaScript and Python syntax | Passed |
| Exported comparison figure | Visually inspected during verification |
| Browser screenshot/layout QA | Not available in this environment |
| Windows/macOS native launcher execution | Not executed; scripts supplied for those platforms |

The full-method test used a small network, four simulated clients, two seeds, a nondefault delta of 1e-4, and eight rounds on the 800-record synthetic dataset. This checks execution and parameter propagation. It is not an added scientific experiment for the paper.

The mixed-data regression tested age strings with day remainders and mutation labels after the source-schema adaptation. The UI test used linkedom as a DOM runtime; it did not launch a browser or take screenshots. Its fixtures came from actual completed backend runs.

Machine-readable reports and the current source checksums accompany this document. To verify the package locally, run tests/functional.py and tests/data_regression.py from an environment with requirements.txt installed.
