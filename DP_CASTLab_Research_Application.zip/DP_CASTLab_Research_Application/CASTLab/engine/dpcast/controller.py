"""Double DQN with masks and discounted rewards between successive client visits."""
from collections import deque
import numpy as np
from .common import rng
from .network import MLP

ACTIONS = [(f,c) for f in [.5,.75,1.,1.5,2.] for c in [.75,1.,1.25]]
DEFAULT_ACTION = ACTIONS.index((1.,1.))
STATE_DIM = 10


def network_state(net):
    return dict(params=net.params,m=net.m,v=net.v,steps=net.steps)


def restore_network(net, state):
    for name in ['params','m','v']: setattr(net,name,[np.asarray(a,float) for a in state[name]])
    net.steps = state['steps']


class Controller:
    def __init__(self, cfg, seed):
        self.cfg = cfg; self.q = MLP([STATE_DIM,64,32,len(ACTIONS)],rng(seed,'q_init'))
        self.target = self.q.copy(); self.frozen = self.q.copy()
        self.memory = deque(maxlen=cfg.rl_capacity); self.updates = 0; self.gen = rng(seed,'replay')

    def greedy(self, state, mask, frozen=False):
        mask = np.asarray(mask,bool)
        if not mask.any(): raise RuntimeError('No feasible controller action')
        scores = (self.frozen if frozen else self.q).forward(np.atleast_2d(state))[0][0]
        return int(np.argmax(np.where(mask,scores,-np.inf)))

    def add(self, state, action, discounted_return, next_state, done, mask, gap):
        if gap < 1 or not 0 <= action < len(ACTIONS): raise ValueError('Replay transition')
        self.memory.append([np.asarray(state),int(action),float(discounted_return),np.asarray(next_state),
                            bool(done),np.asarray(mask,bool),int(gap)])

    def learn(self):
        if len(self.memory) < self.cfg.rl_warmup: return None
        ix = self.gen.choice(len(self.memory),self.cfg.rl_batch,replace=False)
        b = [self.memory[int(i)] for i in ix]
        s = np.stack([v[0] for v in b]); a = np.array([v[1] for v in b]); r = np.array([v[2] for v in b])
        ns = np.stack([v[3] for v in b]); done = np.array([v[4] for v in b]); mask = np.stack([v[5] for v in b])
        gaps = np.array([v[6] for v in b]); rows = np.arange(len(b))
        best = np.argmax(np.where(mask,self.q.forward(ns)[0],-np.inf),axis=1)
        target = r + (~done & mask.any(axis=1))*(self.cfg.rl_gamma**gaps)*self.target.forward(ns)[0][rows,best]
        pred, cache = self.q.forward(s); error = pred[rows,a]-target
        loss = np.where(abs(error)<=1,.5*error**2,abs(error)-.5).mean()
        grad = np.zeros_like(pred); grad[rows,a] = np.clip(error,-1,1)/len(b)
        self.q.adam(self.q.backward(grad,cache),self.cfg.rl_lr); self.updates += 1
        if self.updates % self.cfg.rl_target_interval == 0: self.target = self.q.copy()
        if not np.isfinite(loss): raise FloatingPointError('Controller loss')
        return float(loss)

    def state(self):
        return dict(q=network_state(self.q),target=network_state(self.target),updates=self.updates,
                    memory=list(self.memory),rng=self.gen.bit_generator.state)

    def restore(self,s):
        restore_network(self.q,s['q']); restore_network(self.target,s['target']); self.updates=s['updates']
        self.memory.clear()
        for b in s['memory']: self.add(*b)
        self.gen.bit_generator.state=s['rng']
