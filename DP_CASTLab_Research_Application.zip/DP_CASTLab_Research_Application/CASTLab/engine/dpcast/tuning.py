"""Equal grid effort per method on selection data. Never opens final test arrays."""
from pathlib import Path
from itertools import product
import numpy as np
import pandas as pd
from .common import save_json, read_json, digest
from .config import Config


def tune(config_path,destination,cache,train_function,prepare_function):
    base=Config(**read_json(config_path)).validate()
    if base.purpose!='development': raise ValueError('Tuning requires a development configuration')
    if base.method_overrides: raise ValueError('Tune from a base configuration without existing overrides')
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    grid=[{'local_lr':lr,'clip_init':clip} for lr,clip in product([.0005,.001,.003],[.03,.1,.3])]
    save_json(destination/'tuning_plan.json',dict(base_config=base.to_dict(),grid=grid,
        selection_rule='highest mean selection AP across prespecified dataset/seed cells, separately per method',
        tie_rule='first grid row in deterministic order',final_test_used=False))
    rows=[]
    for index,params in enumerate(grid):
        cfg=Config(**{**base.to_dict(),**params,'study_name':base.study_name+f'_grid{index}'})
        cp=destination/f'config_{index}.json';save_json(cp,cfg.to_dict()); study=destination/f'grid_{index}'
        lock=prepare_function(cp,study,cache);train_function(study)
        for spec in lock['runs']:
            s=read_json(study/'runs'/spec['run_id']/'complete.json')
            rows.append(dict(grid_index=index,**params,method=spec['method'],dataset=spec['dataset'],seed=spec['seed'],
                             alpha=spec['alpha'],epsilon=spec['epsilon'],selection_ap=s['selection_ap']))
    frame=pd.DataFrame(rows); frame.to_csv(destination/'tuning_results.csv',index=False)
    chosen={}
    for name,g in frame.groupby('method'):
        means=g.groupby('grid_index').selection_ap.mean(); best=int(means.idxmax());chosen[name]=grid[best]
    save_json(destination/'selected_method_overrides.json',dict(overrides=chosen,base_config_hash=digest(base.to_dict()),
        all_candidates_trained=True,test_used=False,selection_rule='mean public selection AP; per-method equal grid',
        limitation='Selection estimates are optimistic after tuning; evaluate a locked future plan once.'))
    return {'grid_candidates':len(grid),'completed_runs':len(rows),'selected_overrides':chosen,'final_test_used':False}
