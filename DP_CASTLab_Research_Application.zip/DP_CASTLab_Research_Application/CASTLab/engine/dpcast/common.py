"""Deterministic public streams, atomic records, and source provenance."""
from pathlib import Path
import hashlib
import json
import math
import os
import platform
import importlib.metadata
import numpy as np


def clean(x):
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [clean(v) for v in x]
    if isinstance(x, np.ndarray): return clean(x.tolist())
    if isinstance(x, np.generic): return clean(x.item())
    if isinstance(x, float) and not math.isfinite(x): return None
    return x


def canonical(x):
    return json.dumps(clean(x), sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(x): return hashlib.sha256(canonical(x).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()


def rng(seed, *keys):
    h = hashlib.sha256(canonical([str(seed), *keys]).encode()).digest()
    return np.random.default_rng(int.from_bytes(h[:16], 'little'))


def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(clean(obj), f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    tmp.replace(path)


def read_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def source_manifest():
    root = Path(__file__).resolve().parents[1]
    paths = sorted((root/'dpcast').glob('*.py')) + [root/'run.py']
    return {str(p.relative_to(root)): file_hash(p) for p in paths}


def environment():
    return {'python': platform.python_version(), 'platform': platform.platform(),
            'packages': {n: importlib.metadata.version(n) for n in
                         ['numpy', 'pandas', 'scipy', 'scikit-learn', 'matplotlib', 'threadpoolctl']}}
