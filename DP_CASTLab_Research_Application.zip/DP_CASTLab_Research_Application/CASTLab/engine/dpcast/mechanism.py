"""Public synthetic mechanism experiment; does not stand in for model training."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .privacy import posterior_mean, boundary_probability, single_query_tv_bound
from .common import rng


def run(destination,draws=20000):
    out=Path(destination); out.mkdir(parents=True,exist_ok=True); rows=[]
    for dim in [1,2,5]:
        for rho in [.001,.005,.01,.05,.1,.5,1.]:
            for prior in ['uniform','boundary_beta','shifted_beta']:
                gen=rng(2026,'mechanism',dim,rho,prior)
                c=gen.uniform(0,1,(draws,dim)) if prior=='uniform' else gen.beta(.5,.5,(draws,dim)) if prior=='boundary_beta' else gen.beta(2,8,(draws,dim))
                sd=np.sqrt(dim/(2*rho));noisy=c+gen.normal(0,sd,c.shape);clip=np.clip(noisy,0,1);posterior=posterior_mean(noisy,sd)
                rows.append(dict(prior=prior,dimension=dim,rho=rho,noise_sd=sd,draws=draws,
                    boundary_observed=float(np.mean((noisy<=0)|(noisy>=1))),
                    boundary_expected=float(boundary_probability(c,sd).mean()),
                    clip_mse=float(np.mean((clip-c)**2)),posterior_mse=float(np.mean((posterior-c)**2)),
                    constant_mse=float(np.mean((.5-c)**2)),action_tv_upper_bound=single_query_tv_bound(rho)))
    df=pd.DataFrame(rows); df.to_csv(out/'mechanism_simulation.csv',index=False)
    fig,ax=plt.subplots(1,2,figsize=(9,3.7))
    for dim,g in df[df.prior=='uniform'].groupby('dimension'):
        ax[0].semilogx(g.rho,g.boundary_observed,'o-',label=f'd={dim}')
        ax[1].semilogx(g.rho,g.posterior_mse,'o-',label=f'Posterior d={dim}')
    ax[0].set(xlabel='Per-query Gaussian cost rho',ylabel='Boundary fraction')
    ax[1].axhline(1/12,color='black',linestyle='--',label='Constant .5 under Uniform prior')
    ax[1].set(xlabel='Per-query Gaussian cost rho',ylabel='Mean squared decoding error')
    for a in ax:a.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(out/'mechanism_simulation.pdf'); fig.savefig(out/'mechanism_simulation.png',dpi=170); plt.close(fig)
    return {'settings':len(rows),'draws_per_setting':draws,'scope':'Synthetic mechanism diagnostic with prior misspecification checks; no model utility evidence.'}
