"""Fixed-order adaptive filter for ideal Gaussian mechanisms, not a production DP library."""
import math
import numpy as np
from scipy.special import ndtr, erf, logsumexp


def project(v, radius):
    v = np.asarray(v, float)
    if radius <= 0 or not np.isfinite(v).all(): raise ValueError('Invalid projection')
    return v * min(1., radius/max(float(np.linalg.norm(v)), 1e-300))


class Filter:
    def __init__(self, clients, epsilon, delta):
        if epsilon <= 0 or not 0 < delta < 1: raise ValueError('Privacy target')
        self.epsilon, self.delta = float(epsilon), float(delta)
        orders = np.r_[np.arange(1.25, 10, .25), np.arange(10., 65.), [96.,128.,192.,256.,512.,1024.]]
        caps = (epsilon - np.log(1/delta)/(orders-1))/orders
        i = int(np.argmax(caps)); self.order = float(orders[i]); self.capacity = float(caps[i])
        if self.capacity <= 0: raise ValueError('No feasible fixed order')
        # Public numerical safety margin. It is not added to the theoretical cap.
        self.usable = self.capacity * (1 - 1e-10)
        self.spent = np.zeros(clients); self.events = []

    def feasible(self, i, cost, reserve=0.):
        return bool(np.isfinite(cost) and np.isfinite(reserve) and cost >= 0 and reserve >= 0
                    and self.spent[i] + cost + reserve <= self.capacity)

    def release(self, value, i, channel, cost, sensitivity, noise_rng, round_id, reserve=0., actual=True):
        value = np.asarray(value, float)
        if not np.isfinite(value).all() or cost <= 0 or sensitivity <= 0: raise ValueError('Invalid Gaussian query')
        if not self.feasible(i, cost, reserve): raise RuntimeError('Privacy filter refused BEFORE release')
        sd = sensitivity/math.sqrt(2*cost)
        self.spent[i] += cost
        self.events.append(dict(client=i, round=round_id, channel=channel, rho=cost,
                                actual_query_rho=cost if actual else 0., sensitivity=sensitivity,
                                noise_sd=sd, cumulative_rho=self.spent[i], reserve=reserve))
        return value + noise_rng.normal(0, sd, value.shape), sd

    def record(self, formal=True):
        return dict(epsilon_cap=self.epsilon, delta=self.delta, order=self.order,
                    rho_capacity=self.capacity, usable_capacity=self.usable,
                    rho_spent=self.spent, max_spent=float(self.spent.max()),
                    bound_conversion=self.order*self.capacity+np.log(1/self.delta)/(self.order-1),
                    formal_ideal_protocol_applies=bool(formal), actual_numeric_dp_certified=False,
                    adjacency='replace all private training and evaluation data of one fixed enrolled client',
                    sampling_amplification=False, realized_spend_is_not_an_odometer=True,
                    whole_artifact_private=False)


def posterior_mean(y, sigma):
    """E[c|y] under a public Uniform[0,1] prior, independent coordinates.

    Fixed 64-point Gauss-Legendre quadrature is stable at the large sigma values
    relevant here. This is a model-based decoder, not a recovery guarantee.
    """
    if sigma <= 0 or not np.isfinite(sigma): raise ValueError('Positive sigma required')
    y = np.asarray(y, float)
    nodes, weights = np.polynomial.legendre.leggauss(64)
    nodes = (nodes + 1)/2; weights = weights/2
    logw = -.5*((y[..., None]-nodes)/sigma)**2 + np.log(weights)
    weights = np.exp(logw-logsumexp(logw, axis=-1, keepdims=True))
    return (weights*nodes).sum(axis=-1)


def boundary_probability(raw, sigma):
    raw = np.asarray(raw, float)
    return ndtr(-raw/sigma) + ndtr((raw-1)/sigma)


def single_query_tv_bound(rho):
    """Uniform upper bound for any downstream action from ONE conditional query.

    Equal covariance Gaussian TV = 2 Phi(||mu1-mu0||/(2 sigma))-1.
    With sigma=Delta/sqrt(2 rho), the sensitivity bound gives erf(sqrt(rho)/2).
    This is not a bound on two entire adaptive training trajectories.
    """
    if rho < 0: raise ValueError('Negative cost')
    return float(erf(math.sqrt(rho)/2))
