"""Public warm start and fixed public subspace shared across private comparators."""
from types import SimpleNamespace
import numpy as np
from .network import MLP, focal_loss_gradient
from .common import rng


def make_model(input_dim,cfg,seed):
    return MLP([input_dim,*cfg.encoder_dims,cfg.head_hidden,1],rng(seed,'model_init'),
               dropout=cfg.dropout,dropout_layers=range(len(cfg.encoder_dims)))


def encoder_stop(cfg): return 2*len(cfg.encoder_dims)


def public_model(data,cfg,seed):
    model = make_model(data['x_fit'].shape[1],cfg,seed)
    public_cfg = SimpleNamespace(**cfg.to_dict()); public_cfg.local_epochs=cfg.pretrain_epochs
    model.fit_local(data['x_fit'],data['y_fit'],public_cfg,rng(seed,'public_fit'))
    return model


def public_basis(model,data,cfg,seed,dim,kind='public_gradient'):
    n = len(model.vector())
    if dim == 0 or dim >= n: return None
    gen = rng(seed,'public_basis',kind)
    if kind == 'random':
        q, _ = np.linalg.qr(gen.normal(size=(n,dim))); return q
    gradients=[]
    for _ in range(cfg.basis_gradient_batches):
        ix = gen.choice(len(data['y_fit']), min(cfg.basis_batch_size,len(data['y_fit'])), replace=False)
        z, cache = model.forward(data['x_fit'][ix])
        _, grad = focal_loss_gradient(z,data['y_fit'][ix],cfg.focal_alpha,cfg.focal_gamma)
        v = np.concatenate([a.ravel() for a in model.backward(grad,cache)])
        gradients.append(v/max(np.linalg.norm(v),1e-12))
    _, singular, vt = np.linalg.svd(np.stack(gradients),full_matrices=False)
    # Uncentered gradient span, fixed solely by public features, labels, and seed.
    rank = min(dim,len(vt)); cols = vt[:rank].T
    if rank < dim: cols = np.column_stack([cols,gen.normal(size=(n,dim-rank))])
    q, _ = np.linalg.qr(cols)
    if not np.allclose(q.T@q,np.eye(dim),atol=1e-8): raise RuntimeError('Basis orthogonality')
    return q[:,:dim]


def scores(model,encoder,heads,x,cfg):
    net = model.copy(); net.set_vector(encoder,0,encoder_stop(cfg))
    predictions=[]
    for head in heads:
        net.set_vector(head,encoder_stop(cfg)); predictions.append(net.predict(x))
    return np.stack(predictions)


def context(model,x,y,delta,clip,previous_rep,previous_update,cfg):
    if not len(y): return np.zeros(5), previous_rep
    rep=model.representation(x[:128],len(cfg.encoder_dims)); mean=rep.mean(axis=0)
    norm=float(np.linalg.norm(delta)); dispersion=float(np.linalg.norm(rep-mean,axis=1).mean())
    imbalance=abs(2*float(np.mean(y))-1)
    c1=.4*min(dispersion/2,1)+.4*min(norm/clip,1)+.2*imbalance
    change=0. if previous_rep is None else min(float(np.linalg.norm(mean-previous_rep)),1.)
    p=np.clip(model.predict(x[:128]),1e-12,1-1e-12)
    entropy=float(np.mean(-(p*np.log(p)+(1-p)*np.log1p(-p))/np.log(2)))
    oldnorm=float(np.linalg.norm(previous_update))
    angle=.5 if norm*oldnorm==0 else float(np.clip((1-np.dot(delta,previous_update)/(norm*oldnorm))/2,0,1))
    dev=.4*angle+.3*min(abs(norm-oldnorm)/.25,1)+.3*change
    return np.clip([c1,change,entropy,imbalance,dev],0,1),mean
