"""One explicit final-test opening after all planned models have been committed."""
from pathlib import Path
import numpy as np
import pandas as pd
from .common import read_json, save_json, file_hash, digest, source_manifest
from .config import Config
from .model import make_model, scores
from .metrics import metrics, aggregate


def check_lock(study):
    study=Path(study); lock=read_json(study/'protocol_lock.json')
    if lock['source']!=source_manifest(): raise RuntimeError('Executable source changed after protocol lock. Create a new study; do not overwrite the lock.')
    if digest(lock['config'])!=lock['config_hash']: raise RuntimeError('Configuration hash mismatch')
    for dataset,files in lock['data_files'].items():
        for name,sha in files.items():
            if file_hash(study/'data'/dataset/name)!=sha: raise RuntimeError('Locked data changed: '+dataset+'/'+name)
    return lock,Config(**lock['config']).validate()


def evaluate(study):
    study=Path(study); lock,cfg=check_lock(study)
    models={}; summaries={}
    for spec in lock['runs']:
        out=study/'runs'/spec['run_id']; summary_path=out/'complete.json'
        if not summary_path.exists(): raise RuntimeError('Final evaluation requires every planned run: missing '+spec['run_id'])
        s=read_json(summary_path)
        if s['config_hash']!=lock['config_hash'] or s['model_sha256']!=file_hash(out/'model.npz'): raise RuntimeError('Model commitment mismatch')
        models[spec['run_id']]=s['model_sha256']; summaries[spec['run_id']]=s
    commitment=digest({'config':lock['config_hash'],'models':models,'data':lock['data_files']})
    marker=study/'TEST_OPENED.json'
    if marker.exists():
        previous=read_json(marker)
        if previous['commitment']!=commitment: raise RuntimeError('Test already opened for different models. This study cannot be retuned.')
        if previous['status']=='complete': return read_json(study/'evaluation_summary.json')
        # Interrupted evaluation may resume only the identical committed models.
    save_json(marker,dict(commitment=commitment,status='in_progress',models=models,
                         warning='Test has now been opened. A new split does not erase prior benchmark exposure.'))
    all_rows=[]
    for dataset in cfg.datasets:
        with np.load(study/'data'/dataset/'sealed_test.npz',allow_pickle=False) as z:
            x,y,ids=z['x'],z['y'],z['ids']
        for spec in [s for s in lock['runs'] if s['dataset']==dataset]:
            out=study/'runs'/spec['run_id']; net=make_model(x.shape[1],cfg,spec['seed'])
            with np.load(out/'model.npz',allow_pickle=False) as z:
                p=scores(net,z['encoder'],z['heads'],x,cfg)
                last=scores(net,z['last_encoder'],z['last_heads'],x,cfg)
                thresholds=z['thresholds']; ensemble_threshold=float(z['ensemble_threshold'])
            rows=[dict(client=i,**metrics(y,v,thresholds[i])) for i,v in enumerate(p)]
            row=dict(**spec,**aggregate(rows),**{'last_'+k:v for k,v in aggregate([metrics(y,v) for v in last]).items()},
                     selected_round=summaries[spec['run_id']]['selected_round'],test_n=len(y),test_positives=int(y.sum()))
            ensemble=metrics(y,p.mean(axis=0),ensemble_threshold)
            row.update({'ensemble_'+k:v for k,v in ensemble.items() if k not in ['reason']})
            np.savez_compressed(out/'test_predictions.npz',y=y,p=p,last_p=last,ids=ids,thresholds=thresholds,
                                ensemble_threshold=ensemble_threshold)
            pd.DataFrame(rows).to_csv(out/'test_heads.csv',index=False)
            save_json(out/'test_metrics.json',row); all_rows.append(row)
    pd.DataFrame(all_rows).to_csv(study/'test_results.csv',index=False)
    summary=dict(completed_runs=len(all_rows),test_commitment=commitment,
                 primary_endpoint='AP averaged across protected head proxies at the selection-chosen checkpoint',
                 secondary_endpoint='last round mean proxy AP, mean proxy AUROC, calibration, threshold metrics, ensemble metrics',
                 thresholds='balanced accuracy on selection partition; deterministic tie rule',
                 independent_replicates='seeds; heads and rounds are not replicates',
                 data_history=cfg.data_history,purpose=cfg.purpose)
    save_json(study/'evaluation_summary.json',summary)
    save_json(marker,dict(commitment=commitment,status='complete',models=models))
    return summary


def audit_saved_predictions(study):
    checks=[]
    for path in sorted((Path(study)/'runs').glob('*/test_metrics.json')):
        saved=read_json(path)
        with np.load(path.parent/'test_predictions.npz',allow_pickle=False) as z:
            recomputed=aggregate([metrics(z['y'],p,float(t)) for p,t in zip(z['p'],z['thresholds'])])
        for k,v in recomputed.items():
            actual=saved[k]; ok=(actual is None and not np.isfinite(v)) or (actual is not None and np.isclose(actual,v,rtol=1e-10,atol=1e-12))
            checks.append(dict(run=path.parent.name,metric=k,passed=bool(ok)))
    if not checks: raise RuntimeError('No saved final predictions to audit')
    result=dict(checks=checks,all_passed=all(r['passed'] for r in checks),count=len(checks))
    save_json(Path(study)/'prediction_audit.json',result)
    if not result['all_passed']: raise RuntimeError('Saved metric audit failed')
    return result
