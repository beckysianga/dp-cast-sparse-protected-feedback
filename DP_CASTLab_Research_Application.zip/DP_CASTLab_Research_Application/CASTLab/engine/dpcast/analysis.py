"""Run-level statistics, figures, and evidence-limited manuscript text."""
from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .common import rng, read_json, save_json
from .config import Config


def paired_statistics(differences,reps=10000,seed=123):
    d=np.asarray(differences,float); d=d[np.isfinite(d)]; n=len(d)
    if not n: return dict(n=0,mean_difference=None,ci_low=None,ci_high=None,p_two_sided=None)
    out=dict(n=n,mean_difference=float(d.mean()),sd_difference=float(d.std(ddof=1)) if n>1 else None,
             ci_low=None,ci_high=None,p_two_sided=None)
    if n<5: return out
    gen=rng(seed,'paired_bootstrap',n)
    boot=np.mean(d[gen.integers(0,n,size=(reps,n))],axis=1)
    out['ci_low'],out['ci_high']=[float(v) for v in np.quantile(boot,[.025,.975])]
    # Conditional sign-exchangeability is an explicit assumption, not automatic randomization.
    if n<=16:
        signs=2*((np.arange(2**n)[:,None] >> np.arange(n)) & 1)-1
        out['p_two_sided']=float(np.mean(abs((signs*d).mean(axis=1))>=abs(d.mean())-1e-15))
    else:
        signs=gen.choice([-1,1],size=(reps,n)); stat=abs((signs*d).mean(axis=1))
        out['p_two_sided']=float((1+np.sum(stat>=abs(d.mean())-1e-15))/(reps+1))
    return out


def holm(pvalues):
    p=np.asarray(pvalues,float); order=np.argsort(p); adjusted=np.empty(len(p)); running=0.
    for rank,idx in enumerate(order):
        running=max(running,(len(p)-rank)*p[idx]); adjusted[idx]=min(1.,running)
    return adjusted


def latex_table(frame,path):
    """Standalone tabular fragment using only booktabs; no optional template engine."""
    def escape(text):
        special={'\\':r'\textbackslash{}','_':r'\_','&':r'\&','%':r'\%','#':r'\#','$':r'\$','{':r'\{','}':r'\}'}
        return ''.join(special.get(c,c) for c in str(text))
    def cell(value):
        if isinstance(value,(float,np.floating)):return '--' if not np.isfinite(value) else f'{value:.4f}'
        return escape(value)
    headers={'dataset':'Dataset','alpha':'Alpha','epsilon':'Epsilon','method':'Method','n_seeds':'Seeds',
             'ap_mean':'AP mean','ap_sd':'AP SD','auroc_mean':'AUROC','brier_mean':'Brier','selected_round_mean':'Round'}
    lines=[r'% Requires \usepackage{booktabs}. Split by dataset if the table is too wide.',
           r'\begin{tabular}{'+'l'*len(frame.columns)+'}',r'\toprule',
           ' & '.join(headers.get(c,escape(c)) for c in frame.columns)+r' \\',r'\midrule']
    lines += [' & '.join(cell(v) for v in row)+r' \\' for row in frame.itertuples(index=False,name=None)]
    lines += [r'\bottomrule',r'\end{tabular}']
    Path(path).write_text('\n'.join(lines)+'\n')


def analyze(study):
    study=Path(study); lock=read_json(study/'protocol_lock.json'); cfg=Config(**lock['config'])
    out=study/'analysis'; out.mkdir(exist_ok=True)
    summaries=[]; curves=[]; diagnostics=[]; accounts=[]
    for spec in lock['runs']:
        run=study/'runs'/spec['run_id']
        if not (run/'complete.json').exists(): continue
        summary=read_json(run/'complete.json'); summaries.append(summary)
        p=run/'rounds.csv'
        if p.exists() and p.stat().st_size>2:
            df=pd.read_csv(p)
            for k in ['dataset','seed','alpha','epsilon','method']: df[k]=spec[k]
            curves.append(df)
        ctx=read_json(run/'BENCHMARK_ONLY_NOT_PRIVATE/context_diagnostics.json')
        if ctx:
            action_path=run/'BENCHMARK_ONLY_NOT_PRIVATE/action_diagnostics.csv'
            action_diag=pd.read_csv(action_path) if action_path.exists() else pd.DataFrame()
            comparable=action_diag.dropna(subset=['raw_context_greedy_action']) if len(action_diag) else action_diag
            diagnostics.append(dict(**spec,queries=len(ctx),
                action_diagnostic_queries=len(comparable),
                raw_protected_action_change_fraction=float(np.mean(comparable.greedy_action!=comparable.raw_context_greedy_action)) if len(comparable) else None,
                mean_decoded_mae=float(np.mean([r['decoded_mae'] for r in ctx])),
                coordinate_clip_boundary_fraction=float(np.average([r['clip_boundary_fraction'] for r in ctx],weights=[len(r['coordinates']) for r in ctx])),
                expected_boundary=float(np.average([r['expected_boundary'] for r in ctx],weights=[len(r['coordinates']) for r in ctx])),
                mean_noise_sd=float(np.mean([r['noise_sd'] for r in ctx]))))
        accounting=read_json(run/'privacy_accounting.json')
        accounts.append(dict(**spec,max_rho=accounting['max_spent'],capacity=accounting['rho_capacity'],
                             within_cap=accounting['max_spent']<=accounting['rho_capacity']))
    pd.DataFrame([{k:v for k,v in s.items() if k!='method_spec'} for s in summaries]).to_csv(out/'completed_runs.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(out/'feedback_diagnostics.csv',index=False)
    pd.DataFrame(accounts).to_csv(out/'budget_checks.csv',index=False)
    if curves:
        cv=pd.concat(curves,ignore_index=True); cv.to_csv(out/'training_curves.csv',index=False)
        for dataset in cfg.datasets:
            fig,ax=plt.subplots(figsize=(7,4))
            # One explicit condition per figure, never average heterogeneous privacy budgets together.
            subset=cv[(cv.dataset==dataset)&(cv.alpha==cfg.alphas[0])&(cv.epsilon==cfg.epsilons[0])]
            for method_name,g in subset.groupby('method'):
                line=g.groupby('round').controller_ap.agg(['mean','std','count'])
                ax.plot(line.index,line['mean'],label=method_name)
            ax.set(xlabel='Communication round',ylabel='Controller-set mean proxy AP',
                   title=f'{dataset}: alpha={cfg.alphas[0]}, epsilon={cfg.epsilons[0]}')
            ax.legend(fontsize=7,ncol=2); fig.tight_layout()
            fig.savefig(out/f'{dataset}_development_curve.pdf'); fig.savefig(out/f'{dataset}_development_curve.png',dpi=170); plt.close(fig)
    readiness=dict(planned_runs=len(lock['runs']),completed_runs=len(summaries),all_runs_complete=len(summaries)==len(lock['runs']),
                   final_test_opened=(study/'TEST_OPENED.json').exists(),purpose=cfg.purpose,
                   at_least_five_seeds=len(cfg.seeds)>=5,uncapped_data=cfg.max_rows is None,
                   nonprivate_baseline='nonprivate' in cfg.methods,public_only_baseline='public_only' in cfg.methods,
                   external_validation=False,published_method_exact_replications=False,
                   all_recorded_budgets_within_cap=all(r['within_cap'] for r in accounts),
                   publication_ready_score=None)
    paired=[]; table=pd.DataFrame()
    if (study/'test_results.csv').exists():
        results=pd.read_csv(study/'test_results.csv')
        groups=['dataset','alpha','epsilon','method']
        table=results.groupby(groups,as_index=False).agg(n_seeds=('seed','nunique'),ap_mean=('mean_ap','mean'),ap_sd=('mean_ap','std'),
            auroc_mean=('mean_auroc','mean'),brier_mean=('mean_brier','mean'),selected_round_mean=('selected_round','mean'))
        table.to_csv(out/'results_summary.csv',index=False)
        latex_table(table,out/'results_table.tex')
        for (dataset,alpha,epsilon),g in results.groupby(['dataset','alpha','epsilon']):
            proposed=g[g.method=='proposed'].set_index('seed')
            for comparator in cfg.primary_comparators:
                other=g[g.method==comparator].set_index('seed')
                common=proposed.index.intersection(other.index)
                d=proposed.loc[common,'mean_ap'].to_numpy()-other.loc[common,'mean_ap'].to_numpy()
                paired.append(dict(dataset=dataset,alpha=alpha,epsilon=epsilon,comparator=comparator,
                                   **paired_statistics(d,cfg.bootstrap_reps)))
        eligible=[i for i,r in enumerate(paired) if r['p_two_sided'] is not None]
        if eligible:
            adjusted=holm([paired[i]['p_two_sided'] for i in eligible])
            for i,p in zip(eligible,adjusted): paired[i]['holm_p']=float(p)
        for r in paired:
            r['supported_direction']='not established'
            if r.get('holm_p',1)<.05 and r['ci_low'] is not None:
                if r['ci_low']>0: r['supported_direction']='higher AP conditional on this benchmark split'
                elif r['ci_high']<0: r['supported_direction']='lower AP conditional on this benchmark split'
        pd.DataFrame(paired).to_csv(out/'paired_comparisons.csv',index=False)
        for dataset in cfg.datasets:
            sub=table[(table.dataset==dataset)&(table.alpha==cfg.alphas[0])&(table.epsilon==cfg.epsilons[0])]
            if len(sub):
                fig,ax=plt.subplots(figsize=(7,4.5)); y=np.arange(len(sub))
                ax.errorbar(sub.ap_mean,y,xerr=sub.ap_sd.fillna(0),fmt='o',capsize=3)
                ax.set_yticks(y,sub.method); ax.set(xlabel='Mean test AP (bars: SD across seeds)',title=dataset)
                fig.tight_layout(); fig.savefig(out/f'{dataset}_test_AP.pdf'); fig.savefig(out/f'{dataset}_test_AP.png',dpi=170); plt.close(fig)
    save_json(out/'readiness_checks.json',readiness)
    lines=[f'DP CAST Next evidence report: {cfg.study_name}', '',
        f'Purpose: {cfg.purpose}. Completed {len(summaries)} of {len(lock["runs"])} planned runs.',
        'The package does not assign a publication score or certify a private deployment.',
        'The proposed contribution is a testable combination of public subspace updates, sparse feedback, and noise-aware decoding.',
        'Adaptive clipping and time scheduling are explicitly adapted baselines, not exact published replications.', '',
        'Data history: '+cfg.data_history,
        'Uncertainty describes training, partition, and noise variation conditional on fixed benchmark evaluation sets.',
        'Heads, records, and communication rounds are not independent training replicates.',
        'Bootstrap intervals are pointwise 95% intervals. Holm adjustment covers the reported primary comparison family.',
        'The sign-flip test assumes paired-difference sign exchangeability under the null. It is not a randomized clinical test.',
        'No equivalence, clinical effectiveness, or universal superiority follows from a nonsignificant comparison.', '']
    if not table.empty:
        for r in table.to_dict('records'):
            sd='unavailable' if pd.isna(r['ap_sd']) else f'{r["ap_sd"]:.6f}'
            lines.append(f'{r["dataset"]}, alpha={r["alpha"]:g}, epsilon={r["epsilon"]:g}: {r["method"]} had mean test AP {r["ap_mean"]:.6f}; SD {sd}; {r["n_seeds"]} seeds.')
        lines.append('')
        for r in paired:
            lines.append(f'{r["dataset"]}, alpha={r["alpha"]:g}, epsilon={r["epsilon"]:g}: proposed minus {r["comparator"]}, paired n={r["n"]}; difference={r["mean_difference"]}; conclusion: {r["supported_direction"]}.')
    else: lines.append('No final test results are available. No test performance claim is generated.')
    lines += ['', 'Remaining requirements include adequate convergence, sensitivity analyses, independently checked threat assumptions, exact published comparisons where compatible, and venue-specific review.']
    (out/'results_draft.txt').write_text('\n'.join(lines)+'\n')
    return readiness
