"""NumPy MLP primitives adapted from the user-supplied DP_CAST_Research_Code.
Exact focal derivative; explicit Adam state. These are established components.
"""
import copy
import numpy as np
from scipy.special import expit

def focal_loss_gradient(logit, y, alpha=.75, gamma=2.):
    y = np.asarray(y, float).reshape(-1, 1)
    z = np.asarray(logit, float).reshape(-1, 1)
    sign = 2*y-1
    pt = expit(sign*z)
    logpt = -np.logaddexp(0., -sign*z)
    weight = np.where(y == 1, alpha, 1-alpha)
    loss = -weight*(1-pt)**gamma*logpt
    # Exact stable derivative; no log(p) clipping mismatch with the loss.
    grad = weight*sign*(1-pt)**gamma*(gamma*pt*logpt-(1-pt))/max(len(y), 1)
    return float(loss.mean()), grad

class MLP:
    """Dense ReLU network with exact backpropagation and explicit Adam state."""
    def __init__(self, dims, rng, dropout=0., dropout_layers=()):
        self.dims = list(dims); self.dropout = dropout; self.dropout_layers = set(dropout_layers)
        self.params = []
        for i, (a,b) in enumerate(zip(dims[:-1], dims[1:])):
            scale = np.sqrt((2. if i < len(dims)-2 else 1.)/a)
            self.params += [rng.normal(0, scale, (a,b)), np.zeros(b)]
        self.m = [np.zeros_like(p) for p in self.params]
        self.v = [np.zeros_like(p) for p in self.params]; self.steps = 0

    def copy(self): return copy.deepcopy(self)

    def vector(self, start=0, stop=None):
        return np.concatenate([p.ravel() for p in self.params[start:stop]])

    def set_vector(self, vec, start=0, stop=None):
        chosen = self.params[start:stop]; offset = 0
        for p in chosen:
            p[:] = vec[offset:offset+p.size].reshape(p.shape); offset += p.size
        if offset != len(vec): raise ValueError('Parameter vector length mismatch')

    def forward(self, x, training=False, rng=None):
        a = np.asarray(x, float); cache = []; n_layers = len(self.params)//2
        for l in range(n_layers):
            w,b = self.params[2*l:2*l+2]; z = a@w+b; mask = None
            if l < n_layers-1:
                h = np.maximum(z, 0)
                if training and l in self.dropout_layers and self.dropout:
                    mask = (rng.random(h.shape) >= self.dropout)/(1-self.dropout); h *= mask
            else: h = z
            cache.append((a,z,mask)); a = h
        return a, cache

    def backward(self, grad, cache):
        grads = [None]*len(self.params)
        for l in reversed(range(len(cache))):
            a,z,mask = cache[l]
            if l < len(cache)-1:
                if mask is not None: grad = grad*mask
                grad = grad*(z>0)
            grads[2*l] = a.T@grad; grads[2*l+1] = grad.sum(axis=0)
            grad = grad@self.params[2*l].T
        return grads

    def adam(self, grads, lr, clip_norm=10.):
        norm = np.sqrt(sum(float(np.sum(g*g)) for g in grads))
        factor = min(1., clip_norm/max(norm, 1e-300)); self.steps += 1
        for j,g in enumerate(grads):
            g = g*factor; self.m[j] = .9*self.m[j]+.1*g; self.v[j] = .999*self.v[j]+.001*g*g
            self.params[j] -= lr*(self.m[j]/(1-.9**self.steps))/(np.sqrt(self.v[j]/(1-.999**self.steps))+1e-8)

    def fit_local(self, x, y, cfg, rng):
        if not len(y): return 0.
        loss_sum = 0.; batches = 0
        for _ in range(cfg.local_epochs):
            order = rng.permutation(len(y))
            for j in range(0, len(y), cfg.batch_size):
                ix = order[j:j+cfg.batch_size]
                z, cache = self.forward(x[ix], True, rng)
                loss, grad = focal_loss_gradient(z, y[ix], cfg.focal_alpha, cfg.focal_gamma)
                self.adam(self.backward(grad, cache), cfg.local_lr)
                loss_sum += loss; batches += 1
        return loss_sum/max(batches, 1)

    def predict(self, x, batch=4096):
        return np.concatenate([expit(self.forward(x[j:j+batch])[0][:,0])
            for j in range(0, len(x), batch)]) if len(x) else np.empty(0)

    def representation(self, x, encoder_layers=3):
        a = np.asarray(x, float)
        for l in range(encoder_layers): a = np.maximum(a@self.params[2*l]+self.params[2*l+1], 0.)
        return a

