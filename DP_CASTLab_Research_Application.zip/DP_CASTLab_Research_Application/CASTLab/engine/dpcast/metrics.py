"""Explicit endpoints, undefined counts, and selection-only thresholds."""
import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve

NAMES = ['ap','auroc','brier','log_loss','f1','recall','specificity','balanced_accuracy']


def metrics(y, p, threshold=.5):
    y = np.asarray(y, int); p = np.asarray(p, float)
    if len(y) != len(p) or not np.isin(y,[0,1]).all() or not np.isfinite(p).all() or ((p<0)|(p>1)).any():
        raise ValueError('Invalid binary predictions')
    n = len(y); positives = int(y.sum()); negatives = n-positives
    pred = p >= threshold; tp = int(np.sum(pred & (y==1))); fp = int(np.sum(pred & (y==0)))
    fn = positives-tp; tn = negatives-fp
    recall = tp/positives if positives else np.nan; specificity = tn/negatives if negatives else np.nan
    safe = np.clip(p,1e-12,1-1e-12)
    return dict(ap=float(average_precision_score(y,p)) if positives else np.nan,
                auroc=float(roc_auc_score(y,p)) if positives and negatives else np.nan,
                brier=float(np.mean((p-y)**2)) if n else np.nan,
                log_loss=float(-np.mean(y*np.log(safe)+(1-y)*np.log1p(-safe))) if n else np.nan,
                f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else np.nan,
                recall=recall, specificity=specificity,
                balanced_accuracy=(recall+specificity)/2 if positives and negatives else np.nan,
                n=n, positives=positives, negatives=negatives, tp=tp, fp=fp, tn=tn, fn=fn,
                threshold=float(threshold), reason='empty' if not n else 'no_positives' if not positives else 'no_negatives' if not negatives else '')


def aggregate(rows):
    out = {}
    for key in NAMES:
        vals = np.asarray([np.nan if r[key] is None else r[key] for r in rows], float)
        valid = vals[np.isfinite(vals)]
        out['mean_'+key] = float(valid.mean()) if len(valid) else np.nan
        out['valid_'+key] = len(valid)
    ap = [r['ap'] for r in rows if r['ap'] is not None and np.isfinite(r['ap'])]
    out['worst_head_ap'] = float(min(ap)) if ap else np.nan
    out['head_ap_sd'] = float(np.std(ap)) if ap else np.nan
    return out


def threshold_on_selection(y, p):
    if len(np.unique(y)) < 2: return .5
    fpr, tpr, thresholds = roc_curve(y,p,drop_intermediate=False)
    j = tpr-fpr
    candidates = np.flatnonzero(np.isclose(j, j.max(), rtol=0, atol=1e-12))
    # Stable tie rule; keep an all-negative threshold if it is optimal and closest.
    finite = np.where(np.isfinite(thresholds), thresholds, 1.+1e-12)
    index = candidates[np.argmin(np.abs(finite[candidates]-.5))]
    return float(finite[index])
