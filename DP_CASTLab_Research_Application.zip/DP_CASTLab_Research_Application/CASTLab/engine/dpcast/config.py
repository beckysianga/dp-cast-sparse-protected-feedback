"""Explicit methods and locked study configuration. No claimed results in presets."""
from dataclasses import dataclass, asdict, field
from itertools import product
import math
from .common import digest


@dataclass
class Method:
    name: str
    private: bool = True
    controller: str = 'trained'
    context: str = 'protected'
    coordinates: list = field(default_factory=lambda: [0, 2])
    feedback_interval: int = 5
    decoder: str = 'posterior'
    context_fraction: float = .15
    adaptive_clip: bool = True
    basis_dim: int = 16  # 0 means an identity map; no dense identity is allocated.
    basis_kind: str = 'public_gradient'
    reward: str = 'gain'
    reallocate: bool = False
    post_project: bool = True


def method(name):
    m = Method(name)
    if name == 'proposed': pass
    elif name == 'public_only': m.private = False; m.controller = 'public'; m.context = 'none'; m.adaptive_clip = False
    elif name == 'nonprivate': m.private = False; m.controller = 'fixed'; m.context = 'none'; m.adaptive_clip = False; m.basis_dim = 0
    elif name in ['fixed', 'adaptive_clip', 'time_schedule']:
        m.controller = 'time' if name == 'time_schedule' else 'fixed'; m.context = 'none'
        m.adaptive_clip = name != 'fixed'
    elif name in ['random', 'frozen']: m.controller = name
    elif name == 'legacy_feedback':
        m.coordinates = list(range(5)); m.feedback_interval = 1; m.decoder = 'clip'; m.reward = 'legacy'
    elif name in ['constant', 'noise_only', 'constant_realloc', 'noise_only_realloc']:
        m.context = 'constant' if name.startswith('constant') else 'noise_only'
        m.reallocate = name.endswith('_realloc')
    elif name == 'raw_context': m.context = 'raw'  # Always an unprotected benchmark diagnostic.
    elif name == 'clip_decoder': m.decoder = 'clip'
    elif name == 'legacy_reward': m.reward = 'legacy'
    elif name == 'full_updates': m.basis_dim = 0
    elif name == 'random_basis': m.basis_kind = 'random'
    elif name == 'no_post_projection': m.post_project = False
    elif name.startswith('freq_'): m.feedback_interval = int(name[5:])
    elif name.startswith('dim_'):
        d = int(name[4:]); order = [0, 2, 1, 3, 4]
        if not 1 <= d <= 5: raise ValueError('Context dimension must be 1..5')
        m.coordinates = order[:d]
    elif name.startswith('share_'): m.context_fraction = float(name[6:])
    elif name.startswith('basis_'): m.basis_dim = int(name[6:])
    else: raise ValueError('Unknown method: ' + name)
    if m.feedback_interval < 1 or m.basis_dim < 0 or not 0 < m.context_fraction < .7:
        raise ValueError('Invalid method parameters')
    return m


@dataclass
class Config:
    study_name: str = 'pilot'
    purpose: str = 'development'
    datasets: list = field(default_factory=lambda: ['Cervical'])
    methods: list = field(default_factory=lambda: ['public_only', 'nonprivate', 'fixed', 'adaptive_clip', 'time_schedule', 'random', 'frozen', 'legacy_feedback', 'proposed'])
    seeds: list = field(default_factory=lambda: [42, 52, 62])
    alphas: list = field(default_factory=lambda: [.5])
    epsilons: list = field(default_factory=lambda: [8.])
    split_seed: int = 20261117
    clients: int = 8
    participation: float = .75
    rounds: int = 100
    local_epochs: int = 2
    batch_size: int = 256
    local_lr: float = .001
    encoder_dims: list = field(default_factory=lambda: [32, 16])
    head_hidden: int = 8
    dropout: float = .1
    focal_alpha: float = .5
    focal_gamma: float = 0.  # BCE default; focal is an explicit tunable choice.
    pretrain_epochs: int = 40
    basis_gradient_batches: int = 64
    basis_batch_size: int = 32
    delta: float = 1e-5
    clip_init: float = .1
    clip_min: float = .005
    clip_max: float = 2.
    clip_lr: float = .2
    clip_quantile: float = .5
    clip_fraction: float = .05
    evaluation_fraction: float = .05
    min_update_factor: float = .25
    rl_batch: int = 32
    rl_warmup: int = 32
    rl_updates_per_round: int = 4
    rl_lr: float = .001
    rl_gamma: float = .95
    rl_target_interval: int = 20
    rl_capacity: int = 20000
    exploration_start: float = 1.
    exploration_end: float = .05
    exploration_decay_fraction: float = .7
    reward_scale: float = .02
    time_saving_fraction: float = .5
    time_saving_weight: float = .5
    time_spending_weight: float = 1.5
    public_fit_fraction: float = .1
    controller_fraction: float = .1
    selection_fraction: float = .1
    test_fraction: float = .2
    local_test_fraction: float = .2
    max_rows: int | None = None
    drop_exact_duplicates: bool = True
    max_control_rows: int = 3000
    max_selection_rows: int = 3000
    selection_interval: int = 5
    noise_mode: str = 'public_benchmark'
    bootstrap_reps: int = 10000
    primary_comparators: list = field(default_factory=lambda: ['fixed', 'adaptive_clip', 'time_schedule'])
    method_overrides: dict = field(default_factory=dict)
    data_history: str = 'Previously explored public benchmarks; fresh split is not external validation.'

    def validate(self):
        if any(isinstance(v,float) and not math.isfinite(v) for v in self.__dict__.values()):raise ValueError('Nonfinite configuration value')
        if self.purpose not in ['software_check', 'development', 'confirmatory_plan', 'mechanism_study']: raise ValueError('Unknown purpose')
        if not self.datasets or any(n not in ['synthetic', 'Uploaded', 'Cervical', 'CDC_Diabetes', 'Glioma', 'SUPPORT2'] for n in self.datasets): raise ValueError('Dataset')
        if not self.methods or len(set(self.methods)) != len(self.methods): raise ValueError('Duplicate/empty methods')
        if len(set(self.seeds)) != len(self.seeds) or not self.seeds: raise ValueError('Unique seeds required')
        if any(a <= 0 for a in self.alphas) or any(e <= 0 for e in self.epsilons): raise ValueError('Positive alpha and epsilon required')
        if self.clients < 2 or self.rounds < 1 or self.local_epochs < 1 or self.batch_size < 1: raise ValueError('Training counts')
        if not 0 < self.participation <= 1 or not 0 < self.delta < 1: raise ValueError('Probability')
        fs = [self.public_fit_fraction, self.controller_fraction, self.selection_fraction, self.test_fraction]
        if any(f <= 0 for f in fs) or sum(fs) >= 1: raise ValueError('Disjoint public split fractions')
        if not 0 <= self.local_test_fraction < 1: raise ValueError('Local holdout fraction')
        if not 0 < self.clip_min <= self.clip_init <= self.clip_max: raise ValueError('Clipping bounds')
        if not 0 < self.clip_fraction < 1 or not 0 < self.evaluation_fraction < 1: raise ValueError('Release shares')
        if not 0 < self.min_update_factor <= .5: raise ValueError('Minimum reserve factor')
        if self.noise_mode not in ['public_benchmark', 'secret']: raise ValueError('Noise mode')
        if self.rl_warmup < self.rl_batch or self.rl_batch < 1: raise ValueError('Replay warmup/batch')
        if self.pretrain_epochs < 1 or self.selection_interval < 1: raise ValueError('Training schedule')
        if not 0<=self.dropout<1 or not 0<self.focal_alpha<1 or self.focal_gamma<0:raise ValueError('Loss or dropout')
        if self.local_lr<=0 or self.rl_lr<=0 or self.reward_scale<=0 or not 0<self.rl_gamma<=1:raise ValueError('Learning parameters')
        if self.bootstrap_reps<100 or self.basis_batch_size<1 or self.max_rows is not None and self.max_rows<40:raise ValueError('Sample counts')
        if not 0<self.time_saving_fraction<1 or not 0<self.time_saving_weight<=self.time_spending_weight:raise ValueError('Time schedule')
        if not self.encoder_dims or any(x < 1 for x in self.encoder_dims): raise ValueError('Encoder widths')
        if self.basis_gradient_batches < max(method(n).basis_dim for n in self.methods): raise ValueError('Not enough public gradient batches for requested basis')
        for n in self.methods:
            m = method(n)
            if m.context_fraction + self.clip_fraction + self.evaluation_fraction >= 1: raise ValueError('Budget fractions sum to >=1')
        allowed={'local_lr','clip_init','focal_alpha','focal_gamma','reward_scale'}
        for name,values in self.method_overrides.items():
            if name not in self.methods or not set(values)<=allowed: raise ValueError('Invalid method tuning override')
            if values.get('local_lr',self.local_lr)<=0 or values.get('reward_scale',self.reward_scale)<=0: raise ValueError('Nonpositive scale')
            if not self.clip_min<=values.get('clip_init',self.clip_init)<=self.clip_max: raise ValueError('Tuned clip outside bounds')
            if not 0<values.get('focal_alpha',self.focal_alpha)<1 or values.get('focal_gamma',self.focal_gamma)<0: raise ValueError('Focal parameters')
        if self.purpose == 'confirmatory_plan':
            if len(self.seeds) < 5 or self.max_rows is not None or self.rounds < 100:
                raise ValueError('Confirmatory plan needs >=5 seeds, uncapped data, >=100 rounds')
        return self

    def to_dict(self): return asdict(self)


def run_plan(cfg):
    rows = []
    for dataset, seed, alpha, eps, name in product(cfg.datasets, cfg.seeds, cfg.alphas, cfg.epsilons, cfg.methods):
        # Nonprivate/public-only results do not depend on epsilon. Avoid duplicate training.
        if name in ['public_only', 'nonprivate'] and eps != cfg.epsilons[0]: continue
        spec = dict(dataset=dataset, seed=int(seed), alpha=float(alpha), epsilon=float(eps), method=name)
        spec['run_id'] = f'{dataset}_{name}_s{seed}_a{alpha:g}_e{eps:g}_{digest(spec)[:8]}'
        rows.append(spec)
    return rows
