"""Single-process public-benchmark simulator with resumable round checkpoints.

No trainer function opens the sealed final test file. Public gradient projection,
decoding, and validation operations are post-processing or public-data operations.
Raw diagnostics and private restart state are explicitly outside the DP transcript.
"""
from pathlib import Path
import math
import os
import secrets
import time
import numpy as np
import pandas as pd
from .common import rng, digest, save_json, read_json, file_hash
from .config import method, Config
from .data import load_training, partition_clients
from .privacy import Filter, project, posterior_mean, boundary_probability, single_query_tv_bound
from .controller import Controller, ACTIONS, DEFAULT_ACTION, STATE_DIM
from .model import public_model, public_basis, encoder_stop, scores, context, make_model
from .metrics import metrics, aggregate, threshold_on_selection


def public_initialization(study,data,cfg,spec,m):
    folder=Path(study)/'public_initialization'; folder.mkdir(exist_ok=True)
    public_settings={k:getattr(cfg,k) for k in ['local_lr','focal_alpha','focal_gamma','pretrain_epochs','encoder_dims','head_hidden','dropout','batch_size']}
    stem=f'{spec["dataset"]}_{spec["seed"]}_{digest(public_settings)[:10]}'
    model_path=folder/(stem+'.npz')
    net=make_model(data['x_fit'].shape[1],cfg,spec['seed'])
    if model_path.exists():
        with np.load(model_path,allow_pickle=False) as z: net.set_vector(z['weights'])
    else:
        net=public_model(data,cfg,spec['seed']); np.savez_compressed(model_path,weights=net.vector())
    basis=None
    if m.basis_dim:
        path=folder/f'{stem}_{m.basis_kind}_{m.basis_dim}.npz'
        if path.exists():
            with np.load(path,allow_pickle=False) as z: basis=z['basis']
        else:
            basis=public_basis(net,data,cfg,spec['seed'],m.basis_dim,m.basis_kind)
            if basis is not None: np.savez_compressed(path,basis=basis)
    return net,basis


def budget_plan(cfg,m,filter_,schedule):
    visits=schedule.sum(axis=0).astype(int)
    feedback=np.zeros_like(schedule,bool)
    ctx_live=m.context not in ['none'] and not m.reallocate and m.private
    for i in range(cfg.clients):
        rounds=np.flatnonzero(schedule[:,i])
        if ctx_live: feedback[rounds[::m.feedback_interval],i]=True
    ctx_share=m.context_fraction if ctx_live else 0.
    clip_share=cfg.clip_fraction if m.adaptive_clip and m.private else 0.
    eval_share=cfg.evaluation_fraction if m.private else 0.
    total=filter_.usable
    return dict(visits=visits,feedback=feedback,
                context=np.full(cfg.clients,ctx_share*total),
                clipping=np.full(cfg.clients,clip_share*total),
                evaluation=np.full(cfg.clients,eval_share*total),
                update=np.full(cfg.clients,(1-ctx_share-clip_share-eval_share)*total))


def feasible_costs(filter_,client,remaining_update,remaining_visits,min_future,reserve):
    average=remaining_update/remaining_visits
    costs=np.array([f*average for f,_ in ACTIONS])
    mask=np.array([c <= remaining_update-min_future+1e-14 and
                   filter_.feasible(client,c,reserve+min_future) for c in costs])
    return costs,mask


def train_run(study,cfg,spec,stop_after=None):
    """stop_after supports interruption tests; CLI normally completes all rounds."""
    base_config_hash=digest(cfg.to_dict())
    overrides=cfg.method_overrides.get(spec['method'],{})
    cfg=Config(**{**cfg.to_dict(),**overrides}).validate()
    study=Path(study); out=study/'runs'/spec['run_id']; out.mkdir(parents=True,exist_ok=True)
    complete=out/'complete.json'
    if complete.exists(): return read_json(complete)
    m=method(spec['method']); data=load_training(study/'data'/spec['dataset'])
    train,held=partition_clients(data['y_pool'],cfg.clients,spec['alpha'],spec['seed'],cfg.local_test_fraction)
    partition={'train':[v.tolist() for v in train],'held':[v.tolist() for v in held]}
    partition_hash=digest(partition)
    net,basis=public_initialization(study,data,cfg,spec,m); stop=encoder_stop(cfg)
    initial_encoder=net.vector(0,stop); initial_head=net.vector(stop)
    encoder=initial_encoder.copy(); heads=np.tile(initial_head,(cfg.clients,1)); raw_heads=heads.copy()
    schedule=rng(spec['seed'],'participation',spec['dataset']).random((cfg.rounds,cfg.clients))<cfg.participation
    if m.controller=='public': schedule[:]=False
    filter_=Filter(cfg.clients,spec['epsilon'],cfg.delta); budget=budget_plan(cfg,m,filter_,schedule)
    private=out/'LOCAL_RESTART_STATE_NOT_A_RELEASE'; private.mkdir(exist_ok=True)
    seed_path=private/'noise_seed.txt'
    if not seed_path.exists():
        seed_path.write_text(digest([cfg.study_name,spec,'noise']) if cfg.noise_mode=='public_benchmark' else secrets.token_hex(32))
        os.chmod(seed_path,0o600)
    noise_root=seed_path.read_text().strip()
    def nr(t,i,channel): return rng(noise_root,t,i,channel)
    ctrl=Controller(cfg,spec['seed'])
    cache=np.full((cfg.clients,5),.5); last_query=np.full(cfg.clients,-1,int); reliability=np.zeros(cfg.clients)
    previous_rep=[None]*cfg.clients; previous_update=np.zeros_like(encoder); update_spent=np.zeros(cfg.clients)
    base_clip=cfg.clip_init; pending={}; rounds_log=[]; actions_log=[]; context_log=[]; replay_log=[]
    initial_p=scores(net,encoder,heads,data['x_controller'],cfg)
    previous_ap=aggregate([metrics(data['y_controller'],p) for p in initial_p])['mean_ap']
    previous_recall=aggregate([metrics(data['y_controller'],p) for p in initial_p])['mean_recall']
    initial_selection=scores(net,encoder,heads,data['x_selection'],cfg)
    best_score=aggregate([metrics(data['y_selection'],p) for p in initial_selection])['mean_ap']
    best={'encoder':encoder.copy(),'heads':heads.copy(),'raw_heads':raw_heads.copy(),'round':0,'score':best_score}
    start=0; elapsed_before=0.
    checkpoint=private/'checkpoint.json'
    if checkpoint.exists():
        s=read_json(checkpoint)
        if s['spec_hash']!=digest(spec) or s['config_hash']!=digest(cfg.to_dict()): raise RuntimeError('Checkpoint mismatch')
        start=s['next_round']; encoder=np.array(s['encoder']); heads=np.array(s['heads']); raw_heads=np.array(s['raw_heads'])
        cache=np.array(s['cache']); last_query=np.array(s['last_query']); reliability=np.array(s['reliability'])
        previous_rep=[None if a is None else np.array(a) for a in s['previous_rep']]
        previous_update=np.array(s['previous_update']); update_spent=np.array(s['update_spent'])
        base_clip=s['base_clip']; previous_ap=s['previous_ap']; previous_recall=s['previous_recall']
        pending={int(k):v for k,v in s['pending'].items()}; ctrl.restore(s['controller'])
        rounds_log=s['rounds']; actions_log=s['actions']; context_log=s['contexts']; replay_log=s['replay']
        filter_.spent=np.array(s['spent']); filter_.events=s['events']; best=s['best']; elapsed_before=s['elapsed']
    started=time.perf_counter()
    for t in range(start,cfg.rounds):
        if m.controller=='public':
            # A public-only comparator has no private accesses, accounting, or fictitious rounds.
            break
        selected=np.flatnonzero(schedule[t]); encoder_parts=[]; noisy_bits=[]; round_cost=0.; coordinate_changes=[]; deviations=[]
        for i in selected:
            i=int(i); local=make_model(data['x_pool'].shape[1],cfg,spec['seed'])
            local.set_vector(encoder,0,stop); local.set_vector(raw_heads[i],stop)
            ix=train[i]
            local.fit_local(data['x_pool'][ix],data['y_pool'][ix],cfg,rng(spec['seed'],'local',spec['dataset'],t,i))
            local_encoder=local.vector(0,stop); raw_heads[i]=local.vector(stop)
            full_update=np.r_[local_encoder-encoder,raw_heads[i]-heads[i]]
            compressed=full_update if basis is None else basis.T@full_update
            raw,previous_rep[i]=context(local,data['x_pool'][ix],data['y_pool'][ix],local_encoder-encoder,
                                        base_clip,previous_rep[i],previous_update,cfg)
            remaining_visits=int(schedule[t:,i].sum()); future=remaining_visits-1
            total_visits=max(int(budget['visits'][i]),1)
            ctx_queries=max(int(budget['feedback'][:,i].sum()),1)
            c_cost=budget['context'][i]/ctx_queries
            b_cost=budget['clipping'][i]/total_visits
            e_cost=budget['evaluation'][i]
            minimum=cfg.min_update_factor*budget['update'][i]/total_visits
            future_ctx=int(budget['feedback'][t+1:,i].sum())*c_cost
            before=cache[i].copy(); did_query=bool(budget['feedback'][t,i])
            public_refresh=(m.reallocate and m.context=='noise_only' and int(schedule[:t,i].sum())%m.feedback_interval==0)
            noisy_context=None; sigma=None
            if public_refresh:
                # A server-generated placebo costs no privacy. Its scale matches the
                # counterfactual charged noise-only query, while its reliability is zero.
                coords=m.coordinates; dims=len(coords)
                hypothetical_queries=max(1,math.ceil(total_visits/m.feedback_interval))
                hypothetical_rho=m.context_fraction*filter_.usable/hypothetical_queries
                sigma=math.sqrt(dims/(2*hypothetical_rho))
                noisy_context=.5+rng(spec['seed'],'public_placebo',spec['dataset'],t,i).normal(0,sigma,dims)
                decoded=posterior_mean(noisy_context,sigma) if m.decoder=='posterior' else np.clip(noisy_context,0,1)
                cache[i]=.5;cache[i,coords]=decoded;last_query[i]=t;reliability[i]=0.
                context_log.append(dict(round=t+1,client=i,coordinates=coords,raw=raw[coords],noisy=noisy_context,
                    decoded=decoded,noise_sd=sigma,rho=0.,actual_private_query=False,public_placebo=True,
                    clip_boundary_fraction=float(np.mean((noisy_context<=0)|(noisy_context>=1))),
                    expected_boundary=float(boundary_probability(.5,sigma)),decoded_mae=float(np.mean(abs(decoded-raw[coords]))),
                    conditional_single_query_action_tv_bound=0.))
            if did_query:
                coords=m.coordinates; dims=len(coords)
                actual=m.context=='protected'
                query=raw[coords] if actual else np.full(dims,.5)
                if m.context=='raw':
                    # Dummy debit preserves allocation. Raw access removes the formal transcript claim.
                    noisy_context,sigma=filter_.release(np.full(dims,.5),i,'context_dummy_raw',c_cost,math.sqrt(dims),nr(t,i,'context'),t,
                        future_ctx+(future+1)*b_cost+e_cost+(future+1)*minimum,actual=False)
                    decoded=raw[coords]
                else:
                    noisy_context,sigma=filter_.release(query,i,'context' if actual else 'context_dummy',c_cost,math.sqrt(dims),nr(t,i,'context'),t,
                        future_ctx+(future+1)*b_cost+e_cost+(future+1)*minimum,actual=actual)
                    if m.context=='constant': decoded=np.full(dims,.5)
                    else: decoded=posterior_mean(noisy_context,sigma) if m.decoder=='posterior' else np.clip(noisy_context,0,1)
                cache[i]=.5; cache[i,coords]=decoded; last_query[i]=t; reliability[i]=single_query_tv_bound(c_cost)
                round_cost+=c_cost
                context_log.append(dict(round=t+1,client=i,coordinates=coords,raw=raw[coords],noisy=noisy_context,
                    decoded=decoded,noise_sd=sigma,rho=c_cost,actual_private_query=actual,
                    clip_boundary_fraction=float(np.mean((noisy_context<=0)|(noisy_context>=1))),
                    expected_boundary=float(np.mean(boundary_probability(query,sigma))),
                    decoded_mae=float(np.mean(abs(decoded-raw[coords]))),
                    conditional_single_query_action_tv_bound=reliability[i]))
            coordinate_changes.append(abs(float(cache[i,0]-before[0]))); deviations.append(float(cache[i,4]))
            if m.private and m.adaptive_clip:
                bit=float(np.linalg.norm(compressed)<=base_clip)
                protected_bit,_=filter_.release(bit,i,'clipping',b_cost,1.,nr(t,i,'clipping'),t,
                    future_ctx+future*b_cost+e_cost+(future+1)*minimum)
                noisy_bits.append(float(protected_bit)); round_cost+=b_cost
            reserve=future_ctx+future*b_cost+e_cost
            remaining_update=budget['update'][i]-update_spent[i]
            if m.private:
                costs,mask=feasible_costs(filter_,i,remaining_update,remaining_visits,future*minimum,reserve)
                if not mask.any(): raise RuntimeError('No feasible update; plan or accounting error')
            else: costs=np.zeros(len(ACTIONS)); mask=np.ones(len(ACTIONS),bool)
            age=0. if last_query[i]<0 else (t-last_query[i])/max(cfg.rounds-1,1)
            state=np.r_[cache[i],t/max(cfg.rounds-1,1),filter_.spent[i]/filter_.capacity,previous_ap,age,reliability[i]]
            if i in pending:
                prev=pending.pop(i); gap=t-prev['round']
                ctrl.add(prev['state'],prev['action'],prev['return'],state,False,mask,gap)
                replay_log.append(dict(client=i,start_round=prev['round']+1,end_round=t+1,gap=gap,
                                       discounted_return=prev['return'],done=False,action=prev['action']))
            explore=cfg.exploration_start+(cfg.exploration_end-cfg.exploration_start)*min(1.,t/max(1,cfg.rounds*cfg.exploration_decay_fraction))
            action_rng=rng(spec['seed'],'action',spec['dataset'],spec['method'],t,i)
            if m.controller in ['fixed','time']: action=DEFAULT_ACTION
            elif m.controller=='random': action=int(action_rng.choice(np.flatnonzero(mask)))
            elif action_rng.random()<explore: action=int(action_rng.choice(np.flatnonzero(mask)))
            else: action=ctrl.greedy(state,mask,frozen=m.controller=='frozen')
            cost=float(costs[action])
            if m.controller=='time' and m.private:
                # Explicit two-stage rho schedule adapted from the save-then-spend principle.
                visit_index=int(schedule[:t,i].sum())
                weights=np.where(np.arange(total_visits)<int(np.ceil(total_visits*cfg.time_saving_fraction)),
                                 cfg.time_saving_weight,cfg.time_spending_weight)
                cost=float(budget['update'][i]*weights[visit_index]/weights.sum())
                # Remaining scheduled mass replaces the generic minimum reserve.
                future_min=float(budget['update'][i]*weights[visit_index+1:].sum()/weights.sum())
            else: future_min=future*minimum
            C=base_clip*ACTIONS[action][1] if m.private else base_clip
            raw_action=None
            if did_query and m.controller in ['trained','frozen']:
                raw_state=state.copy(); raw_state[m.coordinates]=raw[m.coordinates]
                raw_action=ctrl.greedy(raw_state,mask,frozen=m.controller=='frozen')
            if m.private:
                released,update_sd=filter_.release(project(compressed,C),i,'model',cost,2*C,nr(t,i,'model'),t,
                                                   reserve+future_min)
                update_spent[i]+=cost; round_cost+=cost
                if m.post_project: released=project(released,C)
                message=released if basis is None else basis@released
            else: message=full_update; update_sd=0.
            encoder_parts.append(message[:len(encoder)]); heads[i]+=message[len(encoder):]
            pending[i]=dict(state=state,action=action,return_=0.,round=t)
            pending[i]['return']=pending[i].pop('return_')
            actions_log.append(dict(round=t+1,client=i,action=action,cost_factor=ACTIONS[action][0],
                executed_cost_factor=cost/(remaining_update/remaining_visits) if m.private else 0.,
                cost_source='public_two_stage_schedule' if m.controller=='time' else 'selected_action',
                clip_factor=ACTIONS[action][1],rho=cost,clip=C,update_noise_sd=update_sd,
                release_dimension=len(compressed),noise_rms_to_clip=update_sd*math.sqrt(len(compressed))/C,
                observed_query=did_query,public_placebo=public_refresh,context_age=age,exploration=explore,
                greedy_action=ctrl.greedy(state,mask,frozen=m.controller=='frozen'),
                raw_context_greedy_action=raw_action,
                projected_signal_fraction=float(np.linalg.norm(compressed)/max(np.linalg.norm(full_update),1e-30))))
        if encoder_parts:
            previous_update=np.mean(encoder_parts,axis=0); encoder+=previous_update
        if noisy_bits:
            quantile=float(np.clip(np.mean(noisy_bits),0,1))
            base_clip=float(np.clip(base_clip*np.exp(cfg.clip_lr*(cfg.clip_quantile-quantile)),cfg.clip_min,cfg.clip_max))
        cp=scores(net,encoder,heads,data['x_controller'],cfg)
        cr=aggregate([metrics(data['y_controller'],p) for p in cp]); ap=cr['mean_ap']; recall=cr['mean_recall']
        gain=float(np.clip((ap-previous_ap)/cfg.reward_scale,-1,1))
        privacy_penalty=round_cost/(cfg.clients*filter_.capacity)
        change_penalty=float(np.mean(coordinate_changes)) if coordinate_changes else 0.
        deviation_penalty=float(np.mean(deviations)) if deviations else 0.
        recall_penalty=max(0.,previous_recall-recall)
        reward=gain if m.reward=='gain' else float(np.clip(.6*gain-.1*(privacy_penalty+change_penalty+deviation_penalty+recall_penalty),-1,1))
        # Accumulate ALL intervening round rewards, not just the first reward in a visit gap.
        for prev in pending.values(): prev['return']+=cfg.rl_gamma**(t-prev['round'])*reward
        losses=[]
        if m.controller=='trained':
            for _ in range(cfg.rl_updates_per_round):
                loss=ctrl.learn()
                if loss is not None: losses.append(loss)
        selection_ap=None
        if (t+1)%cfg.selection_interval==0 or t+1==cfg.rounds:
            sp=scores(net,encoder,heads,data['x_selection'],cfg)
            selection_ap=aggregate([metrics(data['y_selection'],p) for p in sp])['mean_ap']
            if selection_ap>best['score']+1e-12:
                best={'encoder':encoder.copy(),'heads':heads.copy(),'raw_heads':raw_heads.copy(),'round':t+1,'score':selection_ap}
        rounds_log.append(dict(round=t+1,selected=len(selected),controller_ap=ap,selection_ap=selection_ap,
            reward=reward,scaled_ap_gain=gain,privacy_penalty=privacy_penalty,change_penalty=change_penalty,
            deviation_penalty=deviation_penalty,recall_penalty=recall_penalty,
            q_loss=float(np.mean(losses)) if losses else None,controller_updates=ctrl.updates,
            replay_size=len(ctrl.memory),max_rho=float(filter_.spent.max()),base_clip=base_clip))
        previous_ap=ap; previous_recall=recall
        save_json(checkpoint,dict(spec_hash=digest(spec),config_hash=digest(cfg.to_dict()),next_round=t+1,
            encoder=encoder,heads=heads,raw_heads=raw_heads,cache=cache,last_query=last_query,reliability=reliability,
            previous_rep=previous_rep,previous_update=previous_update,update_spent=update_spent,base_clip=base_clip,
            previous_ap=previous_ap,previous_recall=previous_recall,pending=pending,controller=ctrl.state(),
            spent=filter_.spent,events=filter_.events,best=best,rounds=rounds_log,actions=actions_log,
            contexts=context_log,replay=replay_log,elapsed=elapsed_before+time.perf_counter()-started))
        if stop_after is not None and t+1>=stop_after: return {'interrupted_after_round':t+1}
    for i,prev in pending.items():
        gap=cfg.rounds-prev['round']
        ctrl.add(prev['state'],prev['action'],prev['return'],np.zeros(STATE_DIM),True,np.zeros(len(ACTIONS),bool),gap)
        replay_log.append(dict(client=i,start_round=prev['round']+1,end_round=cfg.rounds+1,gap=gap,
                               discounted_return=prev['return'],done=True,action=prev['action']))
    # Final private evaluation occurs once, after the transcript-based model selection.
    best_encoder=np.asarray(best['encoder']); best_heads=np.asarray(best['heads']); best_raw=np.asarray(best['raw_heads'])
    local_rows=[]; protected_rows=[]
    for i,ix in enumerate(held):
        local=net.copy(); local.set_vector(best_encoder,0,stop); local.set_vector(best_raw[i],stop)
        p=local.predict(data['x_pool'][ix]); row=metrics(data['y_pool'][ix],p); row['client']=i; local_rows.append(row)
        if m.private:
            fields=['ap','auroc','f1','recall','specificity','balanced_accuracy']
            valid=np.array([np.isfinite(row[k]) for k in fields]); values=np.array([row[k] if v else 0. for k,v in zip(fields,valid)])
            released,_=filter_.release(np.r_[values,valid.astype(float)],i,'evaluation',budget['evaluation'][i],math.sqrt(12),
                                       nr(cfg.rounds,i,'evaluation'),cfg.rounds)
            protected_rows.append(dict(client=i,noisy_scores=released[:6],noisy_validity=released[6:]))
    selection=scores(net,best_encoder,best_heads,data['x_selection'],cfg)
    thresholds=np.array([threshold_on_selection(data['y_selection'],p) for p in selection])
    ensemble_threshold=threshold_on_selection(data['y_selection'],selection.mean(axis=0))
    np.savez_compressed(out/'model.npz',encoder=best_encoder,heads=best_heads,
                        last_encoder=encoder,last_heads=heads,thresholds=thresholds,ensemble_threshold=ensemble_threshold)
    np.savez_compressed(out/'selection_predictions.npz',y=data['y_selection'],p=selection)
    pd.DataFrame(rounds_log).to_csv(out/'rounds.csv',index=False)
    action_frame=pd.DataFrame(actions_log)
    raw_action_columns=['raw_context_greedy_action','projected_signal_fraction']
    action_frame.drop(columns=raw_action_columns,errors='ignore').to_csv(out/'actions.csv',index=False)
    pd.DataFrame(filter_.events).to_csv(out/'privacy_ledger.csv',index=False)
    pd.DataFrame(replay_log).to_csv(out/'replay_index.csv',index=False)
    save_json(out/'protected_local_evaluation.json',protected_rows)
    diagnostics=out/'BENCHMARK_ONLY_NOT_PRIVATE'; diagnostics.mkdir(exist_ok=True)
    if len(action_frame):
        action_frame[['round','client','greedy_action',*raw_action_columns]].to_csv(diagnostics/'action_diagnostics.csv',index=False)
    save_json(diagnostics/'context_diagnostics.json',context_log)
    save_json(diagnostics/'local_metrics.json',local_rows)
    save_json(diagnostics/'partition.json',partition)
    save_json(diagnostics/'client_counts.json',[dict(client=i,train_n=len(train[i]),train_positive=int(data['y_pool'][train[i]].sum()),
        eval_n=len(held[i]),eval_positive=int(data['y_pool'][held[i]].sum())) for i in range(cfg.clients)])
    formal=m.private and m.context!='raw'
    certificate=filter_.record(formal=formal); certificate['noise_mode']=cfg.noise_mode
    certificate['public_noise_seed_invalidates_actual_private_release']=cfg.noise_mode=='public_benchmark'
    save_json(out/'privacy_accounting.json',certificate)
    summary=dict(**spec,method_spec=m.__dict__,config_hash=base_config_hash,effective_config_hash=digest(cfg.to_dict()),
        hyperparameter_overrides=overrides,partition_hash=partition_hash,
        completed_rounds=cfg.rounds if m.controller!='public' else 0,selected_round=best['round'],
        selection_ap=best['score'],controller_updates=ctrl.updates,replay_transitions=len(replay_log),
        executed_updates=len(actions_log),context_queries=sum(r['rho']>0 for r in context_log),feedback_events=len(context_log),
        release_dimension=len(net.vector()) if basis is None else basis.shape[1],full_dimension=len(net.vector()),
        model_sha256=file_hash(out/'model.npz'),schedule_hash=digest(schedule),
        runtime_seconds=elapsed_before+time.perf_counter()-started,formal_protocol=formal,
        claim_scope='Public benchmark simulation; no accuracy or publication claim inferred from execution.')
    save_json(complete,summary)
    return summary
