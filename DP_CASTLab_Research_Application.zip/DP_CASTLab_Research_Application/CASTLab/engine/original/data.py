"""Audited UCI loading and benchmark-only partition construction.

Public reference/test membership and client membership are fixed conditioning
information for the protocol. Label-based partition construction is NOT itself DP.
No trained preprocessing statistic is fitted on pooled private training records.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError
import json
import hashlib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification
from .common import rng as keyed_rng, save_json, digest, file_hash, read_json

SPECS = {
 'CDC_Diabetes': dict(id=891, target='Diabetes_binary', positive='prediabetes or diabetes'),
 'Cervical': dict(id=383, target='Biopsy', positive='positive cervical biopsy'),
 'Glioma': dict(id=759, target='Grade', positive='GBM glioblastoma'),
 'SUPPORT2': dict(id=880, target='hospdead', positive='in-hospital death'),
}
EXCLUSIONS = {
 'CDC_Diabetes': ['ID', 'Diabetes_012'],
 'Cervical': ['ID','Hinselmann','Schiller','Citology','Cytology','Dx:Cancer','Dx:CIN','Dx:HPV','Dx'],
 'Glioma': ['ID','Project','Case_ID','Primary_Diagnosis'],
 # Conservative static clinical benchmark. Do NOT claim an hour-24 landmark.
 'SUPPORT2': ['id','ID','death','d.time','slos','charges','totcst','totmcst','sfdm2',
              'avtisst','aps','sps','surv2m','surv6m','prg2m','prg6m','dnr','dnrday'],
}
MISSING = ['?','--','not reported','unknown','NA','N/A','']

def fetch_bytes(url):
    error = None
    for attempt in range(3):
        try:
            with urlopen(Request(url, headers={'User-Agent':'DP-CAST-Next/2.0'}), timeout=45) as response:
                return response.read()
        except (URLError, TimeoutError, OSError) as exc: error = exc
    raise RuntimeError(f'Download failed: {url}. Supply the matching CSV in data_cache; no synthetic fallback. {error}')

def fetch_dataset(name, cache):
    cache = Path(cache); cache.mkdir(parents=True, exist_ok=True)
    spec = SPECS[name]; csv = cache/f'{name}.csv'; meta = cache/f'{name}_metadata.json'
    if not csv.exists():
        m = json.loads(fetch_bytes(f'https://archive.ics.uci.edu/api/dataset?id={spec["id"]}'))
        if m.get('status') != 200 or not m.get('data',{}).get('data_url'):
            raise RuntimeError(f'UCI dataset {spec["id"]} is unavailable; provide an official CSV.')
        metadata = m['data']; save_json(meta,metadata)
        csv.write_bytes(fetch_bytes(metadata['data_url']))
    metadata = json.loads(meta.read_text()) if meta.exists() else {'source':'user-provided CSV'}
    frame = pd.read_csv(csv, na_values=MISSING, low_memory=False)
    return frame, dict(metadata=metadata, csv_sha256=hashlib.sha256(csv.read_bytes()).hexdigest())

def encode_target(series, name):
    s = series.astype(str).str.strip().str.lower()
    maps = {'0':0,'0.0':0,'1':1,'1.0':1}
    if name == 'Glioma': maps.update(lgg=0, gbm=1)
    unknown = sorted(set(s.dropna())-set(maps))
    if unknown: raise ValueError(f'{name}: ambiguous target labels {unknown}; do not infer a positive class.')
    y = s.map(maps).to_numpy(dtype=np.int64)
    if len(np.unique(y)) != 2: raise ValueError(f'{name}: both target classes are required for the benchmark split.')
    return y

class PublicPreprocessor:
    """Fit on public reference features only; fixed schema, missing indicators.

    Numeric features use reference medians/means/SDs. All-missing columns use 0/1.
    Categories outside the reference vocabulary map to a fixed unknown bucket.
    Schema is public metadata; no feature selection based on private columns.
    """
    def __init__(self): self.specs=[]; self.feature_names=[]

    def fit(self, reference, categorical=()):
        cats = set(categorical)
        for col in reference.columns:
            s = reference[col]
            numeric = pd.to_numeric(s, errors='coerce')
            is_numeric = col not in cats and (pd.api.types.is_numeric_dtype(s) or numeric.notna().sum()==s.notna().sum())
            if is_numeric:
                a = numeric.to_numpy(float); missing = ~np.isfinite(a)
                med = float(np.median(a[~missing])) if (~missing).any() else 0.
                a[missing] = med; mean=float(a.mean()); scale=max(float(a.std()),1e-8)
                self.specs.append(dict(col=col, kind='numeric',median=med,mean=mean,scale=scale))
                self.feature_names += [col, col+'__missing']
            else:
                vals = sorted(set(s.dropna().astype(str)))
                self.specs.append(dict(col=col,kind='category',values=vals))
                self.feature_names += [col+'='+v for v in vals]+[col+'=__UNKNOWN__',col+'=__MISSING__']
        return self

    def transform(self, frame):
        parts=[]
        for spec in self.specs:
            s=frame[spec['col']]
            if spec['kind']=='numeric':
                a=pd.to_numeric(s,errors='coerce').to_numpy(float); missing=~np.isfinite(a)
                a[missing]=spec['median']
                parts += [np.clip((a-spec['mean'])/spec['scale'],-10,10)[:,None],missing.astype(float)[:,None]]
            else:
                vals=spec['values']; a=np.zeros((len(s),len(vals)+2)); mapping={v:i for i,v in enumerate(vals)}
                idx=[len(vals)+1 if pd.isna(v) else mapping.get(str(v),len(vals)) for v in s]
                a[np.arange(len(s)),idx]=1.; parts.append(a)
        out=np.concatenate(parts,axis=1)
        if not np.isfinite(out).all(): raise ValueError('Non-finite preprocessing output')
        return out


def build_public_split(name, cfg, cache, destination):
    """Benchmark custodian only. Trainer loads training.npz, never sealed_test.npz.

    Labels are used to construct stratified benchmark splits. Split construction
    is not private. A fresh split of previously studied benchmarks is not an
    independent external cohort. The seal is a workflow guard, not encryption.
    """
    destination = Path(destination); destination.mkdir(parents=True, exist_ok=True)
    if name == 'synthetic':
        xx, yy = make_classification(n_samples=cfg.max_rows or 1000, n_features=10,
                                     n_informative=7, weights=[.75,.25], random_state=812)
        frame = pd.DataFrame(xx, columns=[f'x{j}' for j in range(xx.shape[1])]); frame['outcome'] = yy
        source = {'csv_sha256': digest({'synthetic':812, 'rows':len(yy)})}; target = 'outcome'
    else:
        frame, source = fetch_dataset(name, cache); target = SPECS[name]['target']
    frame.columns = [c.strip() for c in frame.columns]
    if target not in frame: raise ValueError(f'{target} missing in {name}')
    original_n = len(frame); missing_target = int(frame[target].isna().sum())
    frame = frame.loc[frame[target].notna()].reset_index(drop=True)
    y = encode_target(frame[target], name)
    excluded = [c for c in EXCLUSIONS.get(name, []) if c in frame]
    features = frame.drop(columns=[target]+excluded)
    for v in source.get('metadata', {}).get('variables', []):
        if v.get('role','').lower() in ['id','target'] and v.get('name') in features:
            features = features.drop(columns=v['name']); excluded.append(v['name'])
    # Avoid placing exact feature+label duplicates on both sides of a split.
    duplicate_mask = features.assign(__target__=y).duplicated()
    duplicates = int(duplicate_mask.sum())
    row_ids = np.arange(len(y))
    if cfg.drop_exact_duplicates:
        keep = ~duplicate_mask.to_numpy(); features = features.loc[keep].reset_index(drop=True)
        y = y[keep]; row_ids = row_ids[keep]
    if cfg.max_rows is not None and len(y) > cfg.max_rows:
        ix, _ = train_test_split(np.arange(len(y)), train_size=cfg.max_rows, stratify=y,
                                 random_state=cfg.split_seed)
        ix = np.sort(ix); features = features.iloc[ix].reset_index(drop=True); y = y[ix]; row_ids = row_ids[ix]
    remaining = np.arange(len(y)); splits = {}; remaining_fraction = 1.
    for j, (key, fraction) in enumerate([('test',cfg.test_fraction),('selection',cfg.selection_fraction),
                                        ('controller',cfg.controller_fraction),('fit',cfg.public_fit_fraction)]):
        remaining, ix = train_test_split(remaining, test_size=fraction/remaining_fraction,
                                         stratify=y[remaining], random_state=cfg.split_seed+j)
        splits[key] = np.sort(ix); remaining_fraction -= fraction
    splits['pool'] = np.sort(remaining)
    cats = [v['name'] for v in source.get('metadata',{}).get('variables',[])
            if str(v.get('type','')).lower() in ['categorical','binary']]
    if name == 'Glioma': cats += [c for c in features if c != 'Age_at_diagnosis']
    prep = PublicPreprocessor().fit(features.iloc[splits['fit']], cats)
    arrays = {}
    for key, ix in splits.items():
        if key == 'test': continue
        arrays['x_'+key] = prep.transform(features.iloc[ix]); arrays['y_'+key] = y[ix]
        arrays['ids_'+key] = row_ids[ix]
    # Public subsampling controls compute only. It never touches the final test set.
    for key, cap in [('controller',cfg.max_control_rows),('selection',cfg.max_selection_rows)]:
        if cap and len(arrays['y_'+key]) > cap:
            ix, _ = train_test_split(np.arange(len(arrays['y_'+key])), train_size=cap,
                                     stratify=arrays['y_'+key], random_state=cfg.split_seed+101)
            for prefix in ['x_','y_','ids_']: arrays[prefix+key] = arrays[prefix+key][ix]
    np.savez_compressed(destination/'training.npz', **arrays)
    # Only evaluate.py opens this file. No public test labels are in the training bundle.
    np.savez_compressed(destination/'sealed_test.npz', x=prep.transform(features.iloc[splits['test']]),
                        y=y[splits['test']], ids=row_ids[splits['test']])
    partition = {k: row_ids[ix].tolist() for k,ix in splits.items()}
    save_json(destination/'custodian_splits.json', partition)
    save_json(destination/'preprocessing.json', {'specs':prep.specs,'feature_names':prep.feature_names})
    audit = dict(dataset=name, initial_n=original_n, missing_targets_removed=missing_target,
                 exact_duplicates=duplicates, duplicates_removed=cfg.drop_exact_duplicates,
                 retained_n=len(y), capped=cfg.max_rows is not None and len(frame)>cfg.max_rows,
                 encoded_features=len(prep.feature_names), excluded=excluded, source=source,
                 splits={k:{'n':len(ix),'positives':int(y[ix].sum())} for k,ix in splits.items()},
                 split_hash=digest(partition), data_history=cfg.data_history,
                 task='static retrospective tabular binary classification',
                 preprocessing_fit='public fit partition only',
                 training_file_sha256=file_hash(destination/'training.npz'),
                 test_file_sha256=file_hash(destination/'sealed_test.npz'))
    save_json(destination/'data_audit.json', audit)
    return audit


def load_training(destination):
    with np.load(Path(destination)/'training.npz', allow_pickle=False) as z:
        return {k:z[k] for k in z.files}


def partition_clients(labels, clients, alpha, seed, local_fraction):
    """One draw, no retries to manufacture positive-class coverage."""
    gen = keyed_rng(seed, 'partition', alpha); records = [[] for _ in range(clients)]
    for label in [0,1]:
        ix = gen.permutation(np.flatnonzero(labels == label))
        sizes = gen.multinomial(len(ix), gen.dirichlet(np.full(clients, alpha)))
        cursor = 0
        for i,size in enumerate(sizes): records[i] += ix[cursor:cursor+size].tolist(); cursor += size
    tr, ev = [], []
    for rec in records:
        ix = gen.permutation(rec).astype(int)
        n = min(int(round(len(ix)*local_fraction)), max(len(ix)-1,0))
        ev.append(ix[:n]); tr.append(ix[n:])
    joined = np.concatenate(tr+ev)
    if len(joined) != len(labels) or len(np.unique(joined)) != len(labels): raise RuntimeError('Partition overlap/loss')
    return tr, ev

