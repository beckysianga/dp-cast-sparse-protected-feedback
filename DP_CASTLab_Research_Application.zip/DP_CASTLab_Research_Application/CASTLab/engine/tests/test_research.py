"""Run: python -m unittest discover -s tests -v. No external downloads required."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from scipy.integrate import quad
from scipy.stats import norm
from threadpoolctl import threadpool_limits
from dpcast.common import rng, read_json, save_json, digest
from dpcast.config import Config, method, run_plan
from dpcast.privacy import Filter, project, posterior_mean, single_query_tv_bound
from dpcast.network import MLP, focal_loss_gradient
from dpcast.data import build_public_split, load_training, partition_clients, encode_target, PublicPreprocessor
from dpcast.model import public_model, public_basis, context
from dpcast.controller import Controller, STATE_DIM, ACTIONS
from dpcast.experiment import train_run
from dpcast.metrics import metrics, threshold_on_selection
from dpcast.analysis import paired_statistics, holm, analyze
from dpcast.evaluate import evaluate, audit_saved_predictions, check_lock
from run import prepare, export


def tiny(**changes):
    d=Config(study_name='test',purpose='software_check',datasets=['synthetic'],methods=['proposed'],
        seeds=[42],rounds=6,max_rows=240,pretrain_epochs=1,encoder_dims=[8,4],head_hidden=3,
        rl_batch=2,rl_warmup=2,batch_size=32,selection_interval=2,bootstrap_reps=200).__dict__
    d.update(changes); return Config(**d).validate()


class PrimitiveTests(unittest.TestCase):
    def test_focal_derivative(self):
        z=np.array([-.8,.2,1.7]); y=np.array([0,1,1]); h=1e-5
        for gamma in [0.,2.]:
            loss,grad=focal_loss_gradient(z,y,.75,gamma)
            for i in range(len(z)):
                plus=z.copy(); minus=z.copy(); plus[i]+=h; minus[i]-=h
                numeric=(focal_loss_gradient(plus,y,.75,gamma)[0]-focal_loss_gradient(minus,y,.75,gamma)[0])/(2*h)
                self.assertAlmostEqual(numeric,float(grad[i,0]),places=7)

    def test_network_gradient(self):
        net=MLP([3,4,1],rng(1)); x=rng(2).normal(size=(5,3)); y=np.array([0,1,0,1,1])
        z,cache=net.forward(x); _,g=focal_loss_gradient(z,y); grads=net.backward(g,cache)
        h=1e-5
        for j in range(len(net.params)):
            old=net.params[j].flat[0]; net.params[j].flat[0]=old+h
            plus=focal_loss_gradient(net.forward(x)[0],y)[0]; net.params[j].flat[0]=old-h
            minus=focal_loss_gradient(net.forward(x)[0],y)[0]; net.params[j].flat[0]=old
            self.assertAlmostEqual((plus-minus)/(2*h),grads[j].flat[0],places=6)

    def test_projection_and_replacement_bound(self):
        for _ in range(50):
            a=project(rng(_,1).normal(size=25),.2); b=project(rng(_,2).normal(size=25),.2)
            self.assertLessEqual(np.linalg.norm(a),.2+1e-14); self.assertLessEqual(np.linalg.norm(a-b),.4+1e-14)

    def test_filter_conversion(self):
        f=Filter(8,8.,1e-5)
        self.assertAlmostEqual(f.record()['bound_conversion'],8,places=12)
        self.assertEqual(f.order,4.25); self.assertLess(f.usable,f.capacity)

    def test_filter_refuses_before_noise(self):
        class Never:
            def normal(self,*args): raise AssertionError('Noise called before refusal')
        f=Filter(2,8,1e-5)
        with self.assertRaises(RuntimeError): f.release([0],0,'bad',f.capacity+1,1,Never(),0)
        self.assertEqual(len(f.events),0); self.assertEqual(f.spent[0],0)

    def test_filter_reserves(self):
        f=Filter(2,8,1e-5)
        with self.assertRaises(RuntimeError):f.release([0],0,'bad',.7*f.capacity,1,rng(1),0,.4*f.capacity)
        f.release([0],0,'good',.4*f.capacity,1,rng(1),0,.5*f.capacity)
        self.assertLessEqual(f.spent.max(),f.capacity)

    def test_noise_variance(self):
        f=Filter(2,8,1e-5); value=np.zeros(100000)
        sample,sd=f.release(value,0,'variance',.1,2,rng(12),0)
        self.assertLess(abs(np.var(sample)/sd**2-1),.02)

    def test_posterior_symmetry_bounds(self):
        for sd in [.1,1,20]:
            y=np.array([-30.,-.3,.5,1.3,31.]); a=posterior_mean(y,sd)
            self.assertTrue(((a>=0)&(a<=1)).all()); self.assertTrue((np.diff(a)>=0).all())
            np.testing.assert_allclose(a,1-posterior_mean(1-y,sd),atol=1e-11)
        self.assertLess(abs(posterior_mean(np.array([.8]),100)[0]-.5),1e-4)

    def test_posterior_quadrature_against_integral(self):
        for y,sd in [(.2,.1),(2.,1.),(-10.,12.)]:
            numerator=quad(lambda c:c*np.exp(-.5*((y-c)/sd)**2),0,1)[0]
            denominator=quad(lambda c:np.exp(-.5*((y-c)/sd)**2),0,1)[0]
            self.assertAlmostEqual(float(posterior_mean(np.array([y]),sd)[0]),numerator/denominator,places=8)

    def test_tv_formula(self):
        for rho in [.01,.2,1.]:
            sd=1/np.sqrt(2*rho)
            integral=quad(lambda x:abs(norm.pdf(x,0,sd)-norm.pdf(x,1,sd)),-np.inf,np.inf,epsabs=1e-9)[0]/2
            self.assertAlmostEqual(integral,single_query_tv_bound(rho),places=7)

    def test_metrics_edges(self):
        self.assertTrue(np.isnan(metrics([],[])['ap']))
        self.assertTrue(np.isnan(metrics([0,0],[.1,.2])['ap']))
        self.assertEqual(metrics([1,1],[.1,.2])['ap'],1)
        self.assertTrue(np.isnan(metrics([1,1],[.1,.2])['auroc']))
        self.assertEqual(metrics([0,1],[.1,.9])['ap'],1)

    def test_selection_threshold(self):
        y=np.array([0,0,1,1]); p=np.array([.6,.7,.8,.9]); threshold=threshold_on_selection(y,p)
        self.assertEqual(metrics(y,p,threshold)['balanced_accuracy'],1.)

    def test_targets_fail_closed(self):
        import pandas as pd
        np.testing.assert_equal(encode_target(pd.Series(['LGG','GBM']),'Glioma'),[0,1])
        with self.assertRaises(ValueError):encode_target(pd.Series(['alive','dead']),'SUPPORT2')

    def test_preprocess_unknown_and_missing(self):
        import pandas as pd
        pp=PublicPreprocessor().fit(pd.DataFrame({'n':[None,None],'c':['a','b']}),['c'])
        x=pp.transform(pd.DataFrame({'n':[2,None],'c':['unknown_value',None]}))
        self.assertTrue(np.isfinite(x).all()); self.assertEqual(x[0,-2],1); self.assertEqual(x[1,-1],1)

    def test_partition_completeness(self):
        y=np.array([0]*90+[1]*10)
        tr,ev=partition_clients(y,8,.1,42,.2); ids=np.concatenate(tr+ev)
        self.assertEqual(len(ids),len(y));self.assertEqual(len(np.unique(ids)),len(y))

    def test_holm_known(self):
        np.testing.assert_allclose(holm([.01,.04,.03]),[.03,.06,.06])

    def test_statistics_no_pseudoreplicates(self):
        s=paired_statistics([.1,.1,.1],100); self.assertIsNone(s['ci_low'])
        self.assertEqual(s['n'],3); self.assertIsNone(s['p_two_sided'])
        self.assertEqual(paired_statistics([0]*6,100)['p_two_sided'],1.)

    def test_config_rejects_fake_confirmation(self):
        with self.assertRaises(ValueError):tiny(purpose='confirmatory_plan')

    def test_run_plan_no_duplicate_nonprivate_eps(self):
        cfg=tiny(methods=['nonprivate','fixed'],epsilons=[4,8,16]); self.assertEqual(len(run_plan(cfg)),4)

    def test_method_identity(self):
        self.assertFalse(method('constant').reallocate);self.assertTrue(method('constant_realloc').reallocate)
        self.assertEqual(method('dim_1').coordinates,[0]); self.assertEqual(method('freq_10').feedback_interval,10)

    def test_controller_masks(self):
        c=Controller(tiny(),42); mask=np.zeros(len(ACTIONS),bool); mask[7]=True
        self.assertEqual(c.greedy(np.zeros(STATE_DIM),mask),7)
        with self.assertRaises(RuntimeError):c.greedy(np.zeros(STATE_DIM),np.zeros(len(ACTIONS),bool))

    def test_controller_updates_and_restore(self):
        cfg=tiny(); c=Controller(cfg,42); mask=np.ones(len(ACTIONS),bool)
        for i in range(5):c.add(np.full(STATE_DIM,.1*i),1,float(i)/10,np.ones(STATE_DIM),False,mask,i+1)
        self.assertIsNotNone(c.learn()); snapshot=c.state(); fresh=Controller(cfg,42)
        fresh.restore(json.loads(json.dumps(snapshot,default=lambda x:x.tolist())))
        self.assertAlmostEqual(c.learn(),fresh.learn(),places=12)


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name); self.cfg=tiny()
        self.limit=threadpool_limits(limits=1)
        build_public_split('synthetic',self.cfg,self.root/'cache',self.root/'data'/'synthetic')
        self.spec=run_plan(self.cfg)[0]

    def tearDown(self):self.limit.restore_original_limits();self.temp.cleanup()

    def test_data_split_disjoint(self):
        groups=read_json(self.root/'data/synthetic/custodian_splits.json'); ids=sum(groups.values(),[])
        self.assertEqual(len(ids),len(set(ids)))
        data=load_training(self.root/'data/synthetic');self.assertNotIn('y_test',data)

    def test_public_basis_ignores_private_records(self):
        a=load_training(self.root/'data/synthetic'); b=copy.deepcopy(a); b['x_pool'][:]=100; b['y_pool'][:]=1
        na=public_model(a,self.cfg,42);nb=public_model(b,self.cfg,42)
        np.testing.assert_equal(na.vector(),nb.vector())
        p=public_basis(na,a,self.cfg,42,16); q=public_basis(nb,b,self.cfg,42,16)
        np.testing.assert_allclose(p.T@p,np.eye(16),atol=1e-9);np.testing.assert_equal(p,q)

    def test_training_never_loads_test_arrays(self):
        original=np.load
        def guarded(file,*args,**kwargs):
            if 'sealed_test' in str(file):raise AssertionError('Trainer opened test arrays')
            return original(file,*args,**kwargs)
        with patch('numpy.load',side_effect=guarded):train_run(self.root,self.cfg,self.spec)
        certificate=read_json(self.root/'runs'/self.spec['run_id']/'privacy_accounting.json')
        self.assertLessEqual(certificate['max_spent'],certificate['rho_capacity'])

    def test_round_resume_matches_uninterrupted(self):
        train_run(self.root,self.cfg,self.spec,stop_after=3)
        result=train_run(self.root,self.cfg,self.spec)
        other=self.root/'second';build_public_split('synthetic',self.cfg,self.root/'cache',other/'data/synthetic')
        result2=train_run(other,self.cfg,self.spec)
        with np.load(self.root/'runs'/self.spec['run_id']/'model.npz') as a,np.load(other/'runs'/self.spec['run_id']/'model.npz') as b:
            for k in a.files:np.testing.assert_equal(a[k],b[k])
        self.assertEqual(result['controller_updates'],result2['controller_updates'])

    def test_gap_returns_include_all_rounds(self):
        cfg=tiny(participation=.4,rounds=10);spec=run_plan(cfg)[0];train_run(self.root,cfg,spec)
        import pandas as pd
        folder=self.root/'runs'/spec['run_id']; rewards=pd.read_csv(folder/'rounds.csv').reward.to_numpy()
        replay=pd.read_csv(folder/'replay_index.csv')
        for row in replay.itertuples():
            begin=row.start_round-1;end=row.end_round-1
            expected=sum(cfg.rl_gamma**j*rewards[t] for j,t in enumerate(range(begin,end)))
            self.assertAlmostEqual(expected,row.discounted_return,places=10)
        self.assertTrue((replay.gap>1).any())

    def test_all_ablation_channels(self):
        names=['fixed','adaptive_clip','time_schedule','random','frozen','legacy_feedback','constant','noise_only',
               'constant_realloc','noise_only_realloc','raw_context','clip_decoder','legacy_reward','full_updates',
               'random_basis','no_post_projection','freq_1','dim_1','dim_5','share_0.05','basis_8']
        for name in names:
            cfg=tiny(methods=[name],rounds=3);spec=run_plan(cfg)[0]
            result=train_run(self.root,cfg,spec)
            cert=read_json(self.root/'runs'/spec['run_id']/'privacy_accounting.json')
            self.assertLessEqual(cert['max_spent'],cert['rho_capacity'],name)
            self.assertEqual(cert['formal_ideal_protocol_applies'],name!='raw_context')
            if name.endswith('_realloc'):self.assertEqual(result['context_queries'],0)

    def test_final_test_gate_and_idempotence(self):
        cfg_path=self.root/'cfg.json';save_json(cfg_path,self.cfg.to_dict()); study=self.root/'locked'
        prepare(cfg_path,study,self.root/'cache')
        with self.assertRaises(RuntimeError):evaluate(study)
        self.assertFalse((study/'TEST_OPENED.json').exists())
        train_run(study,self.cfg,self.spec);first=evaluate(study);second=evaluate(study)
        self.assertEqual(first,second);self.assertTrue(audit_saved_predictions(study)['all_passed'])
        report=analyze(study);self.assertTrue(report['all_runs_complete'])
        self.assertTrue((study/'analysis/results_table.tex').exists())

    def test_source_mutation_blocks_test(self):
        cfg_path=self.root/'cfg.json';save_json(cfg_path,self.cfg.to_dict()); study=self.root/'locked'
        prepare(cfg_path,study,self.root/'cache')
        with patch('dpcast.evaluate.source_manifest',return_value={'changed':'yes'}):
            with self.assertRaises(RuntimeError):check_lock(study)

    def test_method_tuning_preserves_protocol_commitment(self):
        cfg=tiny(method_overrides={'proposed':{'local_lr':.003,'clip_init':.3}})
        cp=self.root/'tuned.json';save_json(cp,cfg.to_dict());study=self.root/'tuned'
        prepare(cp,study,self.root/'cache');result=train_run(study,cfg,run_plan(cfg)[0])
        self.assertEqual(result['config_hash'],digest(cfg.to_dict()))
        self.assertEqual(result['hyperparameter_overrides']['local_lr'],.003)
        self.assertEqual(evaluate(study)['completed_runs'],1)

    def test_export_omits_restart_secrets_and_inputs(self):
        train_run(self.root,self.cfg,self.spec)
        nested=self.root/'grid_0/data/synthetic';nested.mkdir(parents=True)
        np.savez(nested/'sealed_test.npz',y=[0,1])
        path=self.root/'bundle.zip';export(self.root,path)
        import zipfile
        with zipfile.ZipFile(path) as z:
            self.assertFalse(any('noise_seed.txt' in n or 'checkpoint.json' in n or 'sealed_test.npz' in n for n in z.namelist()))


if __name__=='__main__':unittest.main()
