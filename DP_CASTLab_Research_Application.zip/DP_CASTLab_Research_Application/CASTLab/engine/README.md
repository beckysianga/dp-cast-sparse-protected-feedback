# DP CAST Next research package

This package implements a new, testable version of DP CAST. It addresses the
weak feedback, large model noise, limited comparisons, and weak experimental
design identified in the supplied paper. It is a complete NumPy reference
implementation for public benchmarks. It does not promise better results,
research priority, a publication score, or acceptance.

Start with `DP_CAST_Next_Colab.ipynb`, or paste the complete contents of
`DP_CAST_Next_Single_Cell.py` into one Google Colab cell. Both contain the source
package. No GitHub repository or manual source-file upload is required.

## What changes

The proposed method builds an update subspace from a separate public fit set.
It perturbs a joint encoder and head correction in that smaller space. It queries
two bounded context coordinates every fifth client visit. It decodes each noisy
context with a public uniform-prior posterior mean. The controller uses context
age and a public bound on single-query distinguishability. Its default reward
depends only on improvement on the public controller set. It no longer assigns
large penalties to nearly random protected context differences.

These are hypotheses to test. Public gradient subspaces, Bayesian decoding,
adaptive clipping, and Double DQN are established ideas. The prospective
contribution is their explicit integration and a controlled study of the tradeoff
between feedback quality, feedback age, projection bias, and update noise.

The release protocol still protects replacement of one enrolled client's whole
private training and evaluation dataset against an observer of individual client
messages. It does not silently switch to patient privacy or secure aggregation.
See `docs/PRIVACY_AND_METHOD.md` for equations, assumptions, and derivations.

## Installation

Use Python 3.10 or later. The reference implementation runs on a CPU; selecting
a Colab GPU does not accelerate NumPy automatically.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

`requirements-tested.txt` records the exact library versions used for delivery
validation on Python 3.12.14. `requirements.txt` permits compatible versions. Every study also
records the environment actually used. Bitwise agreement across BLAS versions
or operating systems is not guaranteed.

## Run the small software check

```bash
python run.py plan --config configs/smoke.json
python run.py prepare --config configs/smoke.json --out studies/smoke
python run.py train --out studies/smoke
python run.py evaluate --out studies/smoke
python run.py audit --out studies/smoke
python run.py analyze --out studies/smoke
python run.py export --out studies/smoke --zip DP_CAST_smoke_results.zip
```

The smoke profile uses synthetic data. It is never substituted for a failed
clinical-data download. Its results are software checks, not research findings.

## Study profiles

| Profile | Planned scope | Purpose |
|---|---|---|
| `smoke.json` | 9 runs; synthetic; 1 seed; 8 rounds | Quick software check |
| `verification.json` | 36 runs; 4 datasets; 1 seed; 8 rounds; at most 2,000 rows | Dataset and integration checks |
| `pilot.json` | 108 runs; 4 datasets; 3 seeds; 50 rounds; at most 5,000 rows | Development and runtime estimates |
| `tuning.json` | 36 runs per candidate; 9 candidates; 324 runs total | Equal grid search effort per method |
| `confirmatory.json` | 360 runs; 4 datasets; 10 new seeds; 150 rounds; uncapped data | Main locked comparison plan |
| `robustness.json` | 720 runs; 4 datasets; 5 seeds; 3 privacy caps; 3 heterogeneity levels; 150 rounds | Privacy and heterogeneity study |
| `mechanisms.json` | 210 runs; Cervical and Glioma; 5 seeds; 21 methods; 150 rounds | Controlled mechanism ablations |

These are planned counts. A configuration is not an executed experiment.
The public-only comparator does not run private communication rounds. The full
profiles can take a long time on CPU, especially on CDC Diabetes. Use Drive or
another persistent disk for results and checkpoints. A single Colab session may
not complete them. Reissue the same `train` command to continue.

The main confirmatory seed set differs from the development seeds. All profiles
use the same prespecified benchmark split seed unless you change it before
preparation. The four benchmarks have already been explored. A fresh split and
new training seeds do not create an external validation cohort.

## Recommended research workflow

1. Run the tests and smoke profile.
2. Run the pilot without opening its test set. Inspect training and selection
   trajectories, runtime, class counts, and nonprivate learning.
3. Tune each method with the same grid effort, using only public selection data.
4. Choose the final design. Apply the selected settings to a new confirmatory
   configuration. Register the design externally if preregistration is required.
5. Prepare and train the complete final plan. Open the final test set once.
6. Audit saved predictions, generate reports, and export results.
7. Complete the robustness and mechanism plans that support the intended claims.

```bash
python run.py prepare --config configs/pilot.json --out studies/pilot
python run.py train --out studies/pilot
python run.py analyze --out studies/pilot

python run.py tune --config configs/tuning.json --out studies/tuning
python run.py apply-tuning --config configs/confirmatory.json --selection studies/tuning/selected_method_overrides.json --save-config configs/confirmatory_tuned.json

python run.py prepare --config configs/confirmatory_tuned.json --out studies/main
python run.py train --out studies/main
python run.py evaluate --out studies/main
python run.py audit --out studies/main
python run.py analyze --out studies/main
python run.py export --out studies/main --zip DP_CAST_main_results.zip
```

The tuning grid contains learning rates 0.0005, 0.001, and 0.003 and initial
clipping bounds 0.03, 0.1, and 0.3. It selects the highest mean selection AP
across the prespecified dataset and seed cells for each method. It never evaluates
the final test arrays. The search is a useful starting design, not a guarantee
that every baseline has converged. Expand the grid or horizon during development
if the curves justify it. Do not change these choices after final testing.

`prepare` records executable source hashes, configuration, dataset hashes, and
the complete run plan. A source or data change blocks training and testing in
that study. Use a new study directory after an intentional change. Do not remove
or edit `protocol_lock.json` to bypass this guard.

`evaluate` requires all planned models to be complete. It records model hashes
before loading test arrays. It refuses a different model after testing begins.
An interrupted evaluation can resume only the identical committed model set.
This is an operational guard, not a tamper-proof vault or external registration.

## Data and learning

The package downloads official UCI CSVs with a local cache. Supported datasets
are Cervical, CDC_Diabetes, Glioma, and SUPPORT2. Files supplied manually must use
the same target schema. Target validation fails on ambiguous labels. Downloads
fail clearly; there is no automatic synthetic fallback.

The split assigns 10% to public fitting, 10% to controller feedback, 10% to model
selection, and 20% to final testing. It assigns the remaining 50% to simulated
clients. Local client evaluation then reserves 20% of each client's pool where
possible. Exact feature-and-label duplicates are removed before splitting by
default. This changes the benchmark population and is recorded in each audit.
Identical clinical profiles do not necessarily identify the same patient.

The preprocessor uses only the public fit partition. The public fit labels also
train the warm-start MLP and determine the gradient subspace. All private main
comparators use the same public initialization unless the equal-effort tuning
procedure selects different learning rates. The public-only comparator measures
what the public information achieves without private client training.

The MLP uses encoder widths 32 and 16, a local head width of 8, and one sigmoid
output. The default focal parameters reduce to equally weighted binary cross
entropy. Focal loss remains configurable. No configuration should be called
adequately trained merely because it completed 150 rounds.

The primary endpoint is mean AP across protected head proxies on the common test
set at the checkpoint selected on the selection partition. The package also saves
last-round AP, AUROC, Brier score, log loss, threshold metrics, and ensemble
metrics. Thresholds maximize balanced accuracy on the selection partition only.
The server proxies are not the clients' raw personal heads. Local raw metrics are
separate benchmark diagnostics, with undefined metrics retained as missing.

## Methods and controlled comparisons

See `docs/EXPERIMENTS_AND_CLAIMS.md` for the full comparison matrix. Main methods
are public-only, nonprivate, fixed privacy, adapted private quantile clipping,
an adapted two-stage time schedule, random control, frozen control, legacy
feedback, and the proposed method. The package labels adaptations accurately.
It does not claim to reproduce every detail of the cited published algorithms.

The ablations vary query frequency, coordinate count, context share, release
dimension, decoder, reward, basis source, and post-noise projection. Constant
and noise-only controls distinguish information from allocation. Their
reallocation counterparts give unused context allowance to model updates.
The raw-context control has no formal complete-transcript privacy claim.

Run the separate Gaussian diagnostic with:

```bash
python run.py mechanism --out studies/mechanism_math
```

It checks saturation and decoding under three public synthetic context priors.
It does not measure downstream predictive benefit.

## Outputs

- `protocol_lock.json`: exact intended study and executable source hashes.
- `data/*/data_audit.json`: exclusions, counts, duplicates, sources, and split hashes.
- `runs/*/complete.json`: completed-run manifest and model hash.
- `runs/*/rounds.csv`: controller/selection curves and reward components.
- `runs/*/actions.csv`: executed actions, noise scales, and query diagnostics.
- `runs/*/BENCHMARK_ONLY_NOT_PRIVATE/action_diagnostics.csv`: raw-context policy probes and retained update energy; outside the protected transcript.
- `runs/*/privacy_ledger.csv`: charges and sensitivities for each release.
- `runs/*/privacy_accounting.json`: conditional ideal-protocol scope and limits.
- `runs/*/model.npz`: selected and final protected models.
- `runs/*/test_predictions.npz`: scores that permit independent metric audits.
- `analysis/results_summary.csv` and `results_table.tex`: scientific tables.
- `analysis/paired_comparisons.csv`: paired seed differences and uncertainty.
- `analysis/*pdf` and `*png`: curves and scientific figures.
- `analysis/results_draft.txt`: factual prose based on completed results only.
- `analysis/readiness_checks.json`: evidence gaps; no invented publication score.

## Reproducibility and privacy scope

`public_benchmark` noise is the default. It makes the public experiments repeatable,
but the released seed cannot protect confidential data. `secret` mode retains a
local unpublished noise seed for restart. NumPy sampling still does not certify
finite-precision differential privacy. Neither mode turns this simulator into a
secure distributed deployment.

Each round checkpoint includes raw client state. It is stored under
`LOCAL_RESTART_STATE_NOT_A_RELEASE`. Standard exports omit these checkpoints,
noise seeds, and raw input arrays. Exports still contain raw public-benchmark
diagnostics. They are not private release artifacts. Do not upload confidential
patient data into this benchmark workflow.

A per-run privacy cap does not cover an entire hyperparameter search or repeated
experiments on the same confidential population. Partition construction and
public-data selection also sit outside the stated conditional protocol bound.

The software tests verify gradients, accounting guards, split separation,
replay returns, resumption, evaluation locking, and saved metrics. They do not
replace mathematical review, a security audit, or the full experimental study.

## Attribution and remaining work

The numerical network and UCI loading utilities adapt the user's supplied
`DP_CAST_Research_Code` archive. The protocol runner, subspace release, sparse
feedback, tuning, test guard, analysis, documentation, and validation workflow
are new in this package. `docs/LITERATURE_AND_POSITIONING.md` separates existing
ideas from proposed contributions. `docs/REFERENCES.csv` contains source links.

No new license is imposed on the user-provided work. Review third-party data
licenses and choose a code license before publishing a repository.

Before submission, complete the necessary experiments, inspect every diagnostic,
compare compatible published methods in more depth, obtain an external cohort
where possible, and apply the target venue's current instructions. Report every
planned primary comparison, including negative results.
