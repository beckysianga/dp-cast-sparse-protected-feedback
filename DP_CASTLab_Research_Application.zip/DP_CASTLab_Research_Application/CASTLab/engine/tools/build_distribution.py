"""Rebuild embedded single-cell and notebook launchers from the current package."""
from pathlib import Path
import argparse
import base64
import hashlib
import io
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]

LAUNCHER='''# DP CAST Next complete single-cell launcher
# Paste this whole file into ONE Google Colab cell. The source archive is embedded below.
# Default: a small synthetic software check. Full research profiles require sustained CPU time.
STAGE = "smoke"  # smoke, verification, pilot, tuning, confirmatory, robustness, mechanisms
ACTION = "run"   # run, evaluate, analyze; use STAGE="tuning" with ACTION="run" for the grid
OPEN_FINAL_TEST = False  # Smoke evaluates automatically. Other studies require this explicit choice.
USE_GOOGLE_DRIVE = False # Set True for long studies and recovery after a Colab disconnect.
STUDY_TAG = ""          # Set a NEW tag when changing a locked configuration.
CUSTOM_CONFIG = ""      # Optional absolute path to a prepared/tuned JSON configuration.
MAX_NEW_RUNS = None      # Optional per-session limit; repeat the same cell to continue.
RUN_TESTS = True
INSTALL_DEPENDENCIES = True
USE_TESTED_VERSIONS = True
DOWNLOAD_RESULTS = True

import base64, hashlib, io, json, os, pathlib, subprocess, sys, zipfile
if sys.version_info < (3,10):
    raise RuntimeError("Use Python 3.10 or later.")
_PAYLOAD_SHA256 = "__SHA__"
_PAYLOAD = "__PAYLOAD__"
archive = base64.b64decode(_PAYLOAD)
if hashlib.sha256(archive).hexdigest() != _PAYLOAD_SHA256:
    raise RuntimeError("Embedded source archive is incomplete or corrupted.")

if USE_GOOGLE_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    base = pathlib.Path("/content/drive/MyDrive/DP_CAST_Next")
else:
    base = pathlib.Path.cwd() / "dpcast_work"
base.mkdir(parents=True, exist_ok=True)
code = base / "code_v2"
code.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(archive)) as package:
    for item in package.infolist():
        relative = pathlib.PurePosixPath(item.filename)
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError("Invalid embedded source path")
        target = code.joinpath(*relative.parts)
        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        content = package.read(item)
        if target.exists() and target.read_bytes() != content:
            raise RuntimeError("Existing code differs from this distribution. Preserve it and choose a new code folder before continuing: " + str(target))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)

def execute(*arguments):
    print("Running:", " ".join(str(a) for a in arguments), flush=True)
    subprocess.run([sys.executable, *map(str, arguments)], cwd=code, check=True)

if INSTALL_DEPENDENCIES:
    requirement = "requirements-tested.txt" if USE_TESTED_VERSIONS and sys.version_info >= (3,12) else "requirements.txt"
    execute("-m", "pip", "install", "-q", "-r", requirement)
if RUN_TESTS:
    execute("-m", "unittest", "discover", "-s", "tests", "-v")

if STAGE not in ["smoke","verification","pilot","tuning","confirmatory","robustness","mechanisms"]:
    raise ValueError("Unknown STAGE")
if ACTION not in ["run","evaluate","analyze"]:
    raise ValueError("Unknown ACTION")
config = pathlib.Path(CUSTOM_CONFIG) if CUSTOM_CONFIG else code / "configs" / (STAGE + ".json")
if not config.is_file():
    raise FileNotFoundError(config)
study = base / "studies" / (STUDY_TAG or STAGE)
cache = base / "data_cache"
execute("run.py", "plan", "--config", config)

if STAGE == "tuning":
    if ACTION != "run":
        raise ValueError("The tuning grid supports ACTION=run; its test sets remain unopened.")
    execute("run.py", "tune", "--config", config, "--out", study, "--cache", cache)
    print("Tuning finished. Apply selected_method_overrides.json to a new confirmatory configuration; see README.md.")
else:
    if ACTION == "run":
        execute("run.py", "prepare", "--config", config, "--out", study, "--cache", cache)
        options = [] if MAX_NEW_RUNS is None else ["--max-runs", str(MAX_NEW_RUNS)]
        if (study / "TEST_OPENED.json").exists():
            print("This study has already opened its final test. Reusing its committed results; training stays locked.")
        else:
            execute("run.py", "train", "--out", study, *options)
    if ACTION == "evaluate" and not OPEN_FINAL_TEST:
        raise RuntimeError("Set OPEN_FINAL_TEST=True to authorize the final test opening.")
    lock = json.loads((study / "protocol_lock.json").read_text())
    all_complete = all((study / "runs" / r["run_id"] / "complete.json").exists() for r in lock["runs"])
    if (OPEN_FINAL_TEST or STAGE == "smoke") and ACTION != "analyze":
        if all_complete:
            execute("run.py", "evaluate", "--out", study)
            execute("run.py", "audit", "--out", study)
        else:
            print("The final test remains unopened because some planned runs are incomplete. Repeat this cell to resume.")
    execute("run.py", "analyze", "--out", study)

# Include the exact source without exposing local restart seeds in a standard results export.
(study / "source_snapshot.zip").write_bytes(archive)
result_zip = base / ((STUDY_TAG or STAGE) + "_results.zip")
execute("run.py", "export", "--out", study, "--zip", result_zip)
print("Finished. Results:", result_zip)
print("Short verification runs do not establish predictive superiority or publication readiness.")
if DOWNLOAD_RESULTS:
    try:
        from google.colab import files
        files.download(str(result_zip))
    except ImportError:
        print("Outside Colab: copy the results ZIP from the printed path.")
'''


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',default=str(ROOT.parent));args=parser.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    include=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if any(v in rel.parts for v in ['validation','__pycache__','studies','data_cache']):continue
        if p.name.startswith('DP_CAST_Next_') or p.name=='DISTRIBUTION_MANIFEST.json' or p.suffix in ['.zip','.pyc']:continue
        include.append(p)
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in include}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as z:
        for p in include:
            item=zipfile.ZipInfo(str(p.relative_to(ROOT)),date_time=(2026,10,11,0,0,0))
            item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,p.read_bytes())
        z.writestr('DISTRIBUTION_MANIFEST.json',json.dumps(hashes,indent=2)+'\n')
    payload=buffer.getvalue();sha=hashlib.sha256(payload).hexdigest()
    script=LAUNCHER.replace('__SHA__',sha).replace('__PAYLOAD__',base64.b64encode(payload).decode())
    (out/'DP_CAST_Next_Single_Cell.py').write_text(script)
    intro='''# DP CAST Next complete research code

Run the cell below for a small synthetic software check. The source is embedded.
Change `STAGE` to choose a larger study. Use Google Drive for long runs.
Set `OPEN_FINAL_TEST=True` only when the complete experiment plan is fixed.
The software does not promise improved accuracy, novelty, or acceptance.
The ZIP package includes the methods, privacy derivation, literature, and study protocol.
'''
    notebook={'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.12'}},
        'cells':[{'cell_type':'markdown','id':'overview','metadata':{},'source':intro.splitlines(True)},
                 {'cell_type':'code','id':'complete-code','metadata':{},'execution_count':None,'outputs':[],'source':script.splitlines(True)}]}
    (out/'DP_CAST_Next_Colab.ipynb').write_text(json.dumps(notebook,indent=1)+'\n')
    (out/'DP_CAST_Next_Source_Only.zip').write_bytes(payload)
    print(json.dumps({'embedded_files':len(include),'source_sha256':sha,'source_bytes':len(payload),'output':str(out)},indent=2))


if __name__=='__main__':main()
