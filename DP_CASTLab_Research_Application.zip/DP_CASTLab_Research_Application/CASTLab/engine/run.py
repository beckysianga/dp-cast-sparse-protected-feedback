#!/usr/bin/env python3
"""DP CAST Next command line. Run python run.py --help."""
import os
for _name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ.setdefault(_name,'1')
from pathlib import Path
import argparse
import json
import zipfile
import sys
from threadpoolctl import threadpool_limits
from dpcast.common import read_json, save_json, source_manifest, digest, file_hash, environment
from dpcast.config import Config, run_plan
from dpcast.data import build_public_split


def prepare(config_path,study,cache):
    cfg=Config(**read_json(config_path)).validate(); study=Path(study)
    lock_path=study/'protocol_lock.json'
    if lock_path.exists():
        from dpcast.evaluate import check_lock
        lock,_=check_lock(study)
        if lock['config_hash']!=digest(cfg.to_dict()): raise RuntimeError('Existing study has a different protocol')
        return lock
    if (study/'runs').exists(): raise RuntimeError('Uncommitted runs exist. Use a new study directory.')
    study.mkdir(parents=True,exist_ok=True); files={}
    for name in cfg.datasets:
        print('Preparing',name,flush=True); dest=study/'data'/name
        build_public_split(name,cfg,cache,dest)
        files[name]={p.name:file_hash(p) for p in dest.iterdir() if p.is_file()}
    lock=dict(config=cfg.to_dict(),config_hash=digest(cfg.to_dict()),source=source_manifest(),
              data_files=files,runs=run_plan(cfg),environment=environment(),
              registered_externally=False,lock_kind='local workflow commitment, not external preregistration')
    save_json(lock_path,lock)
    print(f'Locked {len(lock["runs"])} runs. Test data remain unopened by training.',flush=True)
    return lock


def train(study,max_runs=None):
    from dpcast.evaluate import check_lock
    from dpcast.experiment import train_run
    study=Path(study); lock,cfg=check_lock(study)
    if (study/'TEST_OPENED.json').exists(): raise RuntimeError('Test has been opened. Training changes are blocked for this study.')
    path=study/'TRAINING_LOCK.json'
    if path.exists():
        pid=read_json(path)['pid']
        if os.name!='posix':
            raise RuntimeError('A training lock exists. Verify that no trainer is active before removing TRAINING_LOCK.json; automatic PID probing is supported only on POSIX.')
        try: os.kill(pid,0)
        except ProcessLookupError: path.unlink()
        else: raise RuntimeError(f'Training lock belongs to process {pid}. Do not run concurrent trainers in one study.')
    # Exclusive creation protects the shared public initialization cache.
    with path.open('x') as f: json.dump({'pid':os.getpid()},f)
    finished=0
    try:
        with threadpool_limits(limits=1):
            for index,spec in enumerate(lock['runs']):
                complete=study/'runs'/spec['run_id']/'complete.json'
                if complete.exists():
                    s=read_json(complete)
                    if s['config_hash']!=lock['config_hash'] or s['model_sha256']!=file_hash(complete.parent/'model.npz'):
                        raise RuntimeError('Completed run was modified')
                    continue
                if max_runs is not None and finished>=max_runs: break
                print(f'[{index+1}/{len(lock["runs"])}] {spec["run_id"]}',flush=True)
                result=train_run(study,cfg,spec); finished+=1
                print(f'  selection AP={result["selection_ap"]:.5f}, Q updates={result["controller_updates"]}, time={result["runtime_seconds"]:.1f}s',flush=True)
    finally: path.unlink(missing_ok=True)
    return {'newly_completed_runs':finished,'planned_runs':len(lock['runs'])}


def export(study,destination,include_checkpoints=False):
    study=Path(study); destination=Path(destination).resolve(); count=0
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(study.rglob('*')):
            if not p.is_file() or p.resolve()==destination: continue
            rel=p.relative_to(study)
            if 'LOCAL_RESTART_STATE_NOT_A_RELEASE' in rel.parts and not include_checkpoints: continue
            # Raw input data and unopened test labels are not part of a standard results export.
            if 'data' in rel.parts and p.suffix=='.npz': continue
            if p.name=='TRAINING_LOCK.json' or p.suffix=='.tmp': continue
            z.write(p,arcname=str(Path(study.name)/rel)); count+=1
    return dict(archive=str(destination),files=count,private_release=False,
                note='Includes public-benchmark diagnostics. Restart checkpoints excluded unless explicitly requested.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('plan'); p.add_argument('--config',required=True)
    p=sub.add_parser('prepare'); p.add_argument('--config',required=True); p.add_argument('--out',required=True); p.add_argument('--cache',default='data_cache')
    p=sub.add_parser('train'); p.add_argument('--out',required=True); p.add_argument('--max-runs',type=int)
    p=sub.add_parser('tune'); p.add_argument('--config',required=True); p.add_argument('--out',required=True); p.add_argument('--cache',default='data_cache')
    p=sub.add_parser('apply-tuning');p.add_argument('--config',required=True);p.add_argument('--selection',required=True);p.add_argument('--save-config',required=True)
    for name in ['evaluate','analyze','audit']:
        p=sub.add_parser(name); p.add_argument('--out',required=True)
    p=sub.add_parser('mechanism'); p.add_argument('--out',required=True); p.add_argument('--draws',type=int,default=20000)
    p=sub.add_parser('export'); p.add_argument('--out',required=True); p.add_argument('--zip',required=True); p.add_argument('--include-local-checkpoints',action='store_true')
    args=parser.parse_args()
    if args.command=='plan':
        cfg=Config(**read_json(args.config)).validate(); runs=run_plan(cfg)
        result={'study':cfg.study_name,'purpose':cfg.purpose,'planned_runs':len(runs),'rounds_per_private_run':cfg.rounds,'datasets':cfg.datasets,'seeds':cfg.seeds,'methods':cfg.methods,'executed':False}
    elif args.command=='prepare':
        lock=prepare(args.config,args.out,args.cache); result={'planned_runs':len(lock['runs']),'protocol_hash':lock['config_hash']}
    elif args.command=='train': result=train(args.out,args.max_runs)
    elif args.command=='tune':
        from dpcast.tuning import tune
        result=tune(args.config,args.out,args.cache,train,prepare)
    elif args.command=='apply-tuning':
        cfg=Config(**read_json(args.config));selection=read_json(args.selection)
        if selection.get('test_used') is not False or not selection.get('all_candidates_trained'):raise RuntimeError('Invalid tuning record')
        cfg.method_overrides={k:v for k,v in selection['overrides'].items() if k in cfg.methods};cfg.validate()
        destination=Path(args.save_config)
        if destination.exists():raise RuntimeError('Refusing to overwrite an existing configuration')
        save_json(destination,cfg.to_dict());result={'configuration':str(destination),'methods_tuned':list(cfg.method_overrides)}
    elif args.command=='evaluate':
        from dpcast.evaluate import evaluate
        with threadpool_limits(limits=1): result=evaluate(args.out)
    elif args.command=='analyze':
        from dpcast.analysis import analyze
        result=analyze(args.out)
    elif args.command=='audit':
        from dpcast.evaluate import audit_saved_predictions
        result=audit_saved_predictions(args.out); result={k:v for k,v in result.items() if k!='checks'}
    elif args.command=='mechanism':
        from dpcast.mechanism import run
        result=run(args.out,args.draws)
    elif args.command=='export': result=export(args.out,args.zip,args.include_local_checkpoints)
    print(json.dumps(result,indent=2,default=str))


if __name__=='__main__': main()
