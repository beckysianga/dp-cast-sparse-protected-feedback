# Experimental design and claim boundaries

## Questions fixed before the final comparison

1. Does the proposed controller improve common-test AP over fixed privacy,
   adapted quantile clipping, and the prescheduled time comparator at the same
   total per-client privacy cap?
2. Do sparse queries and fewer coordinates improve feedback quality enough to
   offset stale or missing information?
3. Does the public gradient subspace improve the noise-versus-bias tradeoff?
4. Does the posterior decoder help on actual context distributions, beyond its
   known advantage under its working uniform prior?
5. Does a simpler public reward improve the learning signal?

The answer to every question may be no. The study must retain those outcomes.
No source file contains fabricated performance results or a target score.

## Main comparison

All methods use the same public partitions, client partition, and participation
schedule for a dataset/seed/alpha cell. The model initialization and local batch
streams match unless a documented per-method tuning override changes learning
settings. Privacy-noise streams differ by method and run. Paired seeds reduce
some experimental variation; they do not make the outcomes noise-identical.

| Method | Feedback and action rule | Update space | Purpose |
|---|---|---|---|
| public_only | No private access | Publicly trained full model | Is private training adding value? |
| nonprivate | Ordinary local training and aggregation | Full parameter space | Utility and convergence reference |
| fixed | Fixed clipping and uniform cost | Public gradient subspace | Simple private baseline |
| adaptive_clip | Private norm-quantile indicator; uniform cost | Same subspace | Adapted published clipping component |
| time_schedule | Private clipping; public save-then-spend cost schedule | Same subspace | Adapted time-allocation principle |
| random | Samples feasible actions | Same subspace | Controls for the action space and feedback cost |
| frozen | Untrained Q-network with the same exploration schedule | Same subspace | Controls for controller learning |
| legacy_feedback | Five coordinates at every visit; direct clipping; legacy reward | Same subspace | Multi-component reference resembling the previous design |
| proposed | Two coordinates every fifth visit; posterior decoding; AP-gain reward | Same subspace | New combination under test |

The legacy reference is not an exact rerun of the earlier paper. It uses the
new public warm start, subspace, splits, and corrected replay returns. Do not
compare its values directly with earlier paper values as a controlled change.

The nonprivate method is an attainable comparison, not a guaranteed upper bound.
The fixed and adaptive clipping baselines have more update capacity because
they do not purchase context. This practical comparison shares the total cap.
Random/frozen/constant/noise-only controls better isolate the information and
learning effects within the proposed allocation.

## Mechanism ablations

Each variant changes the stated feature from the proposed method. Except for
explicit reallocation variants, the nominal total cap and component shares stay
the same. Context share variants necessarily change the available update share.
They answer an allocation question rather than a pure information question.

| Method | Change | Interpretation |
|---|---|---|
| constant | Replace selected feedback with 0.5; retain dummy charge | Remove context information without increasing update allowance |
| noise_only | Decode a noisy constant with the same variance and charge | Measure effects of stochastic state without private context information |
| constant_realloc | Constant state; no context query; reallocate allowance | Information removal plus larger update allowance |
| noise_only_realloc | Server-generated noisy constant; no private query; reallocate allowance | Placebo state variation with larger update allowance |
| raw_context | Read raw selected coordinates; retain dummy charge | Unprotected upper-information diagnostic; no complete DP claim |
| clip_decoder | Use coordinate clipping instead of posterior decoding | Decoder effect |
| legacy_reward | Use original-style context and privacy penalties | Reward effect at the proposed two-coordinate representation |
| full_updates | Release the full parameter vector | Noise dimension and projection-bias tradeoff |
| random_basis | Use an independent public orthonormal random basis | Value of the public gradient span |
| no_post_projection | Remove the projection after adding model noise | Effect of the second projection |
| freq_1, freq_2, freq_10 | Query every 1, 2, or 10 client visits | Feedback accuracy versus age |
| dim_1, dim_5 | Release one or five coordinates | Feedback detail versus noise |
| share_0.05, share_0.3 | Allocate 5% or 30% of the total cap to context | Context-versus-model allocation |
| basis_8, basis_32 | Change the public release dimension | Projection bias versus Gaussian noise dimension |

The noise-only reallocation control uses a public server random stream. Its
scale matches the hypothetical charged query, but its reliability feature is
zero. It performs no client context release. It differs from constant
reallocation through placebo state variation. Its public feedback events and
its zero charged context-query count are recorded separately.

## Tests that separate causes

Compare proposed against constant and noise_only at equal component charges
before attributing an improvement to private context information. Compare those
controls against their reallocation versions to estimate the cost of purchasing
feedback. Compare proposed against full_updates and random_basis before
attributing an improvement to the public gradient span. Compare proposed against
clip_decoder and legacy_reward to isolate decoder and reward changes.

An action disagreement calculation uses the same learned network and feasible
mask. It is not the counterfactual trajectory of an independently trained raw
controller. The raw_context method provides a separate training diagnostic, but
its results cannot support a complete-transcript DP claim.

The primary mechanism contrasts are declared in the configuration. Other
frequency, share, dimension, and rank sweeps are sensitivity analyses. Report
all conditions, and label post hoc selections as exploratory.

## Evaluation and uncertainty

The four public partitions have different roles. Only public fit features train
the preprocessor. Public fit labels train the warm start and gradient subspace.
Controller labels produce rewards. Selection labels select checkpoints and
thresholds. Test labels are loaded only after all committed runs finish.
The script's local lock does not erase prior researcher knowledge of these
public benchmarks. External validation is still absent.

For each head, calculate non-interpolated positive-class AP. Average those APs
to obtain one primary score per run. The shared encoder, heads, and test records
are correlated. Therefore, neither heads nor rounds nor test records count as
independent algorithm repetitions. The alternative ensemble AP is explicitly the
AP of the mean predicted probability, not the mean of head AP values.

The analysis pairs methods by dataset, alpha, epsilon, and training/partition
seed. It reports mean paired differences and percentile bootstrap intervals
across seed pairs. At least five pairs are required for intervals and tests.
Five is a minimal reporting gate, not a statistical power guarantee. The main
plan uses ten seeds. Seeds describe algorithmic variation conditional on the
fixed evaluation sets; this does not quantify between-hospital uncertainty.

The two-sided sign-flip calculation is exact for up to 16 pairs and Monte Carlo
otherwise. Its exchangeability assumption must be considered when interpreting
it. Holm correction covers the reported primary comparison family across
datasets, privacy caps, heterogeneity levels, and prespecified comparators.
Bootstrap intervals remain pointwise. They are not simultaneous confidence
intervals. The report states this distinction explicitly.

No equivalence or noninferiority margin is invented. A nonsignificant difference
supports neither equivalence nor superiority. Tiny statistically detectable
differences may still have no practical value. A positive adjusted test and a
positive interval support only the stated conditional benchmark comparison.

## Validity checks before claiming effectiveness

- Inspect the nonprivate baseline and public-only baseline. Verify useful learning.
- Inspect the whole trajectory and the selection-chosen round. A checkpoint at
  round zero may mean that private training added no detectable value.
- Check the fraction of constant predictions, Brier scores, and AUROC. An AP
  number alone does not establish clinical usefulness.
- Inspect class counts and undefined metrics. Do not rank a two-record,
  all-positive client's AP of 1 as evidence of successful discrimination.
- Report training duration, private accesses, release dimensions, and public-data
  requirements alongside utility and privacy caps.
- Inspect feedback distortion, query ages, policy disagreements, reward scales,
  and retained update energy before offering a causal explanation.
- State whether the full grid was completed. Do not count configuration files,
  failed jobs, synthetic runs, or partial runs as completed clinical experiments.

## Writing and figures

`analyze` writes a factual results draft, CSV and LaTeX tables, and vector figures.
It creates test claims only from saved completed test results. It does not invent
a conclusion from a planned experiment. Figure error bars show standard deviation
across seeds and are labeled as such. They are not confidence intervals.

Build the paper around a clear question and answer it with the relevant ablation.
Use active verbs and short sentences. Cite the source of each established
component. Keep the threat model and scope in the methods section. State the
main empirical limitation once in the abstract and explain it in the discussion.
Avoid repeated declarations that the work is novel or publication-ready.

For submission, include the actual executed configuration, data exclusions,
all primary comparisons, source commit or archive hash, reproducible commands,
and the supplementary evidence. No manuscript should describe the short bundled
verification runs as the completed confirmatory study.
