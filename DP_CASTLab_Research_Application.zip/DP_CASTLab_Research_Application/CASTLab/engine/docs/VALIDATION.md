# Delivery validation

These checks establish that the delivered research workflow runs and that its
reported metrics agree with its saved predictions. They do not establish that
the proposed method outperforms its comparators.

## Checks completed

| Check | Executed scope | Result |
|---|---|---|
| Correctness suite | 32 tests | All passed |
| Real-data integration | 36 runs; Cervical, CDC Diabetes, Glioma, and SUPPORT2; one seed; eight rounds; at most 2,000 rows | Completed; all 648 saved-prediction metric checks passed |
| Longer training workflow | Fixed and proposed methods; Cervical; one seed; 150 rounds; no row cap | Completed; all 36 metric checks passed |
| Repeated-seed statistics | Fixed and proposed methods; synthetic data; five seeds; ten rounds | Completed; all 180 metric checks passed |
| Tuning workflow | Nine grid candidates; two methods; one synthetic seed; three rounds | All 18 runs completed; final test stayed unopened; applying selected settings succeeded |
| Gaussian mechanism diagnostic | 63 settings; 5,000 draws each; three context priors | Completed; formula and decoding diagnostics saved |
| Embedded single-cell launcher | Nine synthetic runs; default smoke profile | Completed locally; all 162 metric checks passed |

The tests cover analytical and numerical gradients, release variance,
replacement sensitivity, the privacy filter and reservations, decoder
quadrature, the Gaussian total-variation expression, split separation, target
validation, feasible action masks, controller restoration, replay returns,
round-level resumption, method ablations, tuning commitments, test-opening
guards, saved metric audits, report generation, and export exclusions.

The repeated-seed check exercises paired comparisons and uncertainty reporting.
It is a synthetic software check. It provides no clinical evidence. The longer
training check exercises the full round count. One seed does not establish
superiority, convergence, or robustness.

## Execution environment and evidence

Validation used Python 3.12.14 on Linux. Exact numerical library versions appear
in `requirements-tested.txt` and `validation/environment.json`. The delivery ZIP
includes the test log, final run logs, public benchmark result archives, tuning
outputs, mechanism plots, and `validation/DELIVERY_VALIDATION.json`.

The result archives contain protocol locks, model commitments, privacy ledgers,
saved predictions, metric audits, tables, and figures. The executable source
hashes match the delivered code. Standard exports omit raw input arrays and
local restart state. Their benchmark diagnostics still sit outside the protected
transcript, so these archives are not confidential-data release artifacts.

The embedded launcher ran in the local Python environment with dependency
installation, Drive mounting, browser download, and the redundant test rerun
disabled. The complete test suite ran separately. The notebook and single-cell
script contain the same executable cell. Payload and file hashes were checked.
Live Google Colab authentication and its browser interface were not tested here.

## Experiments that remain

The complete pilot, equal-effort tuning plan, 360-run confirmatory comparison,
720-run robustness study, and 210-run mechanism study have not been executed.
Their configuration files specify future work. Do not cite their planned run
counts as completed evidence.

The package does not supply an independent clinical cohort, exact replications
of every cited method, a deployment security audit, or a certified
finite-precision Gaussian sampler. Its proposed combination still needs the
full experiments and an expert novelty assessment. Strong code supports that
work; it cannot guarantee publication or a numerical review score.
