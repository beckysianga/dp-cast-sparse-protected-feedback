# Literature and positioning

The package offers a research hypothesis. It does not establish priority for its
combination. The following primary sources identify ideas that must be credited.
The accompanying reference table retains the verified sources from the paper
audit and adds work on public gradient subspaces.

| Prior work | Established idea | Relation to this package |
|---|---|---|
| McMahan et al., AISTATS 2017 | Federated averaging | Equal averaging of client encoder increments; local heads differ from basic FedAvg |
| Mironov, IEEE CSF 2017 | Renyi differential privacy | Gaussian RDP cost and conversion |
| Andrew et al., NeurIPS 2021 | Private norm-quantile clipping | Adapted per-client noisy indicators under an individual-message observer |
| Lecuyer, 2021 | Fixed-order adaptive filters | Composition foundation; not a new theorem here |
| Collins et al., ICML 2021 | Shared representation and personal heads | Related architecture; this code does not reproduce FedRep's alternating training algorithm |
| Zhou, Wu, and Banerjee, ICLR 2021 | Public gradient subspace identification | Public subspaces are established; this code uses a fixed warm-start joint-update basis |
| Yu et al., ICLR 2021 | Gradient embedding perturbation | Related dimension reduction; this code does not release a separately protected residual as GEP does |
| Chen et al., IEEE ICC 2024 | RL privacy allocation | RL allocation is established; exact multi-agent replication is not included |
| Lu et al., IEEE TIFS 2025 | RL for personalized private FL | Related privacy-control work; assumptions and perturbation policies differ |
| Kiani et al., ICLR 2025 | Time-adaptive privacy spending | The time comparator adapts save-then-spend to a fixed-order rho schedule |
| Khavkin et al., arXiv 2026 | Explanation-guided noise adaptation | Recent related adaptive-signal work; explicitly a preprint |

The implemented `adaptive_clip` baseline ports the quantile adaptation component.
The original Andrew protocol can aggregate clipping feedback and uses a different
privacy setting. This code protects each client indicator because the observer
sees each individual message. It does not claim to reproduce their published
benchmark numbers.

The implemented `time_schedule` baseline uses cost weights 0.5 in the first half
of a client's visits and 1.5 in the remaining visits. It normalizes the weights
to the available update allowance. Kiani et al. use a broader framework with
sampling and heterogeneous privacy settings. This implementation tests the
data-independent scheduling principle under the present threat model; it is not
their full algorithm. Do not label its results as their reported method results.

The subspace work is essential to the novelty discussion. The code uses the
gradient span of a separate public fit set and perturbs a compressed, bounded
client update. Public-subspace private learning already exists. A claim that
subspace compression itself is new would be inaccurate.

The strongest prospective contribution is a controlled analysis of how a
fixed client privacy allowance should be divided between useful feedback and
model updates when individual messages are visible. The package tests sparse
context, limited dimension, a noise-aware decoder, and a fixed public update
subspace together. It also tests their separate effects. The one-query Gaussian
distinguishability calculation can connect budget choices to measurable action
sensitivity. Whether this adds sufficient scientific value depends on results,
comparison quality, and a broader literature review.

## Primary source links

- Adaptive clipping: https://proceedings.neurips.cc/paper/2021/hash/91cff01af640a24e7f9f7a5ab407889f-Abstract.html
- Adaptive RDP filter, Theorem 1: https://arxiv.org/abs/2103.01379
- Public gradient subspaces: https://arxiv.org/abs/2007.03813
- Gradient embedding perturbation: https://openreview.net/forum?id=7aogOj_VYO0
- Author GEP implementation: https://github.com/dayu11/Gradient-Embedding-Perturbation
- Time-adaptive spending: https://proceedings.iclr.cc/paper_files/paper/2025/hash/d45bb0586164aa7c2289b9e1abee4405-Abstract-Conference.html
- RL privacy allocation: https://doi.org/10.1109/ICC51166.2024.10622685
- Personalized RL privacy: https://doi.org/10.1109/TIFS.2024.3515814
- Recent explanation-guided preprint: https://arxiv.org/abs/2609.03851

Consult the exact source version and target publication's reference style before
submission. More citations alone do not resolve an experimental gap. Exact
published-method replications and external validation remain marked incomplete
in the machine-readable readiness report.
