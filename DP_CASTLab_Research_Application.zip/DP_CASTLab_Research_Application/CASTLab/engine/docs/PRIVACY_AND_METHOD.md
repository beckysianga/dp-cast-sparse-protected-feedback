# Protocol and technical formulation

## Protected unit and observer

Fix client enrollment, membership, a public participation schedule, four public
data partitions, architecture, subspace, and configuration. Neighbors replace
the entire private training and local evaluation data of one enrolled client.
Other clients' data remain unchanged. The coordinator sees every permitted
client message. We assume trusted client computation. We do not assume secure
aggregation or hidden client participation. No sampling amplification is used.

Private raw heads and raw feature statistics stay at the simulated client.
They are present in local restart files because this is a one-process simulator.
Reading that memory or those files falls outside the observer model. Raw
diagnostic exports also fall outside the protected transcript. The implementation
is intended for already public benchmark data.

The bound excludes private-data-dependent failures, timing channels, malicious
clients, inference-time raw personal-head releases, and any confidential fitting
of preprocessing or the public subspace. A real deployment must address these
issues separately.

## Public update subspace

Train an MLP on the public fit partition. Use 64 public minibatches to form
normalized gradient rows at the public warm start. An uncentered SVD gives a
basis. QR normalization yields a fixed matrix B with B^T B = I_r. The default
rank is r=16. Rank-zero configuration means the identity release space.
Rank-deficient data may yield uninformative singular directions. The empirical
comparison with a public random basis tests whether gradient alignment helps.

For client i at round t, form the joint vector

    u = [theta_local - theta_server ; phi_raw_local - phi_proxy_server].

Compute v = B^T u, clip v to the L2 ball of radius C, and release

    z = clip_C(v) + N(0, sigma_u^2 I_r),
    sigma_u = 2 C / sqrt(2 rho_u).

The server receives B clip_C(z) by default. Disabling the second projection
releases Bz instead. Either reconstruction is post-processing. Two clipped
inputs differ by at most 2C, so replacement sensitivity is 2C. The bound does
not depend on the model's ambient parameter count.

Before the second projection, the root mean square noise norm is sigma_u sqrt(r).
An orthonormal B preserves this norm on reconstruction. This replaces the dense
message's sqrt(d) factor with sqrt(r). It also discards update directions outside
the subspace. Smaller noise dimension does not guarantee higher predictive utility.
The benchmark logs the retained update-norm fraction to diagnose this tradeoff.

The server averages encoder increments with equal client weights. It applies
each head increment only to that client's proxy. No sample counts enter the
aggregation weights. Clients retain their raw heads between visits.

## Context releases and decoding

The five original bounded heuristic coordinates are sensitivity score,
representation change, predictive entropy, class imbalance, and update deviation.
The sensitivity score is not the formal sensitivity of a Gaussian mechanism.
Update deviation is not an attack or clinical risk estimator.

The proposed method selects coordinates 0 and 2. It queries them on client visits
1, 6, 11, and so on. The visit schedule is public before private interaction.
Unqueried coordinates remain at 0.5. The server caches the last decoded query.
For d selected coordinates, the query lies in [0,1]^d and has L2 replacement
sensitivity sqrt(d). Each query with Gaussian cost rho_c uses

    sigma_c = sqrt(d / (2 rho_c)).

Let R be the usable client capacity, eta_c the context share, and q_i the planned
number of queries for client i. Each query costs eta_c R/q_i. Reducing query
frequency increases per-query accuracy but makes cached information older.
Removing coordinates reduces dimension at fixed total context allocation.
It also removes potentially useful information. Both effects require evaluation.

The default decoder uses a public working prior c_j ~ Uniform[0,1]:

    c_hat(y) = integral_0^1 c exp(-(y-c)^2/(2 sigma^2)) dc
               / integral_0^1 exp(-(y-c)^2/(2 sigma^2)) dc.

The code evaluates this ratio with fixed 64-point Gauss-Legendre quadrature.
It is deterministic post-processing. It does not estimate a private prior.
Its mean-square optimality only holds under the working prior and observation
model, up to numerical approximation. The actual context prior can differ.
The mechanism diagnostic tests uniform, Beta(0.5,0.5), and Beta(2,8) contexts.
The training ablation compares this decoder with direct coordinate clipping.

## A conditional distinguishability calculation

For two means separated by Euclidean distance h and a common isotropic Gaussian
standard deviation sigma, the exact total variation distance is

    TV = 2 Phi(h/(2 sigma)) - 1.

To derive it, rotate the coordinate system along the mean difference. The
likelihood-ratio decision boundary is the perpendicular midpoint hyperplane.
Integrating the densities on the two sides reduces the problem to one normal
coordinate. The tail difference gives the expression above.

With h <= Delta and sigma=Delta/sqrt(2 rho),

    TV <= 2 Phi(sqrt(rho/2)) - 1 = erf(sqrt(rho)/2).

Fix the preceding transcript and any downstream randomized action rule. The
data-processing inequality for total variation preserves this upper bound for
that action. The code logs the bound as a public reliability descriptor. It is
an upper bound on distinguishability, not a measured information score or a
lower bound on utility. It applies to one conditional query. It must not be
interpreted as the distance between complete adaptive training trajectories or
between raw-context and protected-context controllers.

For direct clipping, a raw scalar c in [0,1] has boundary probability

    Phi(-c/sigma) + 1 - Phi((1-c)/sigma).

The package compares this expected probability with observed clipping saturation.
The calculation and decoder use standard probability results. No new general
privacy theorem is claimed.

## Controller and reward

The state has ten coordinates: five decoded values, normalized time, spent
capacity fraction, preceding controller-set AP, normalized context age, and the
single-query bound above. The Q-network has widths 10, 64, 32, and 15.
The fifteen actions combine cost factors {0.5,0.75,1,1.5,2} with clipping
multipliers {0.75,1,1.25}. Public masks exclude actions that violate reservations.

The proposed round reward is clip((AP_t-AP_(t-1))/0.02,-1,1). Only controller-set
labels and protected proxies enter it. The legacy reward ablation adds the prior
privacy, context-change, recall-drop, and deviation penalties. The controller
receives a shared cooperative reward; this does not prove optimal individual
credit assignment or a stationary Markov model.

Replay links successive visits of each client. If visits are g rounds apart,
the stored return includes sum_{k=0}^{g-1} gamma^k r_(t+k). The Double DQN target
adds gamma^g times the target-network value of the feasible action selected by
the online network. Terminal transitions have no bootstrap. This corrects
omission of intervening rewards. The learning rate is 0.001, gamma is 0.95, the
batch and warm-up are 32, and the target copy interval is 20 updates. The default
schedule uses up to four updates per round. Exploration decreases from 1 to 0.05
over the first 70% of rounds. The loop adds final terminal transitions but does
not train on them after the last action; their presence is an audit record.

## Remaining releases

A client releases a noisy indicator of whether its compressed update norm is
at most the current public base clipping threshold. The sensitivity is 1.
The server averages these indicators and updates its threshold toward a target
quantile of 0.5. This adapts the mechanism of Andrew and colleagues to an observer
who sees each noisy indicator. It is not their original aggregate protocol.

Final local evaluation uses six bounded metrics and six validity bits. Undefined
metrics become zero before release. The joint vector is in [0,1]^12, so its
replacement sensitivity is at most sqrt(12). Brier and log loss are reported on
public test data; they are not additional private evaluation coordinates.
The private evaluation concerns the selected raw local head with the selected
protected encoder. Noisy validity bits are not exact valid-client counts.

## Fixed-order adaptive privacy filter

For sensitivity Delta and noise sigma, write rho=Delta^2/(2 sigma^2). The Gaussian
mechanism has lambda-rho RDP cost at any fixed order lambda>1. Before interaction,
choose a public order from a finite grid to maximize positive

    R_lambda = [epsilon - log(1/delta)/(lambda-1)] / lambda.

Each enrolled client has a separate ledger. The implementation allocates only
(1-10^-10) R_lambda to avoid boundary rounding. It refuses a proposed message
before drawing noise if the charge plus spent cost and future reservations
would exceed R_lambda. No tolerance expands the theoretical cap.

At the default epsilon=8 and delta=10^-5, the selected order is 4.25 and the
capacity is approximately 1.048838. The proposed shares are 15% context, 5%
clipping, 5% final evaluation, and 75% model updates. Fixed privacy uses 95%
updates and 5% evaluation. Adaptive clipping and time scheduling use 90% updates,
5% clipping, and 5% evaluation. Random and frozen controllers match the proposed
shares, query schedule, decoder, and subspace. Constant/noise-only controls keep
a conservative dummy context charge. Reallocation controls move that share to
updates and make no context query.

An update action proposes f times remaining update allocation divided by
remaining visits. Reservations cover all later scheduled context and clipping
queries, final evaluation, and a minimum update cost for each future visit.
The minimum equals 0.25 times the original average update allocation. The
two-stage time comparator reserves its exact remaining prescheduled update mass.

### Conditional protocol proposition

Assume ideal independent Gaussian draws and exact arithmetic. Under the stated
fixed public inputs and trusted-client model, the permitted transcript is
(epsilon,delta)-DP for replacement of any one enrolled client's private data,
provided every message passes its fixed-order filter.

Proof sketch with the composition step made explicit:

1. Condition on an arbitrary preceding permitted transcript. Actions, masks,
   clipping bounds, context schedule, subspace, and current proxies are now
   determined by public information and preceding protected messages.
2. For the replaced client, every conditional query has the stated sensitivity:
   sqrt(d), 1, 2C, or sqrt(12). Its ideal Gaussian release is
   (lambda,lambda*rho)-RDP. Arbitrary retained local state is allowed because
   the bounds hold for all possible bounded query outputs.
3. The fixed-order adaptive filter theorem of Lecuyer bounds the complete
   interaction by (lambda,lambda*R_lambda)-RDP. Merely reporting the realized
   path sum would not justify an adaptive odometer claim.
4. Other clients use unchanged private data. Given the transcript, their
   responses constitute the same conditional kernels in both neighboring worlds.
   Server aggregation, controller training, model selection, and public
   evaluation are post-processing. They require no additional charge.
5. RDP conversion gives lambda*R_lambda+log(1/delta)/(lambda-1)=epsilon.
   Since the replaced client can be any enrolled client, the stated bound
   holds for that adjacency relation.

This applies existing adaptive composition. It is not a new composition theorem.
The numerical tests do not prove finite-precision DP. A secret PRNG seed alone
does not certify the Gaussian sampler or the surrounding implementation.

Repeated runs on the same confidential population need a composition analysis.
Changing label-based client partitions also changes the conditional setup.
The package does not represent the complete experiment archive as epsilon=8 DP.
The raw-context and nonprivate controls deliberately lack this protocol claim.

## Algorithm

1. Partition the public benchmark. Lock configuration, source, splits, and run plan.
2. Fit preprocessing, warm start, and subspace using the public fit partition.
3. Draw the public participation schedule. Reserve all release costs per client.
4. At each visit, train locally from the shared encoder and retained raw head.
5. When scheduled, perturb selected bounded context coordinates. Decode and cache.
6. Release the private clipping indicator. Construct the protected controller state.
7. Close the previous client replay transition. Select a feasible executed action.
8. Clip and perturb the projected joint update. Reconstruct and aggregate.
9. Compute the controller-set reward. Accumulate it for all pending transitions.
10. Train Double DQN. Select checkpoints only on the separate selection partition.
11. Save the full local restart state after each round. Resume only the locked code.
12. Release protected local evaluation. Commit every final selected model.
13. Open the test arrays once for the committed study. Audit and report all results.
