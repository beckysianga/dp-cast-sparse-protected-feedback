#!/usr/bin/env python3
"""Loopback-only research desktop application. Start: python run.py"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ.setdefault(k,'1')
import sys,threading,subprocess,webbrowser,argparse,secrets,mimetypes,uuid,shutil,io
from urllib.parse import urlparse,unquote
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from common import *

TOKEN=secrets.token_urlsafe(32)
RUN_LOCK=threading.Lock();PROCESSES={}
ALLOWED_DOWNLOADS={'experiment.zip','results.csv','comparison.csv','head_metrics.csv','training_curves.csv','paired_comparisons.csv','comparison.svg','comparison.png','report.html','request.json','metric_audit.json','run.log'}

def dataset_folder(i):return WORK/'datasets'/ident(i)
def run_folder(i):return WORK/'runs'/ident(i)
def register_dataset(text,filename,synthetic=False):
 frame=csv_frame(text);info=profile(frame,filename);i=uuid.uuid4().hex[:12];folder=dataset_folder(i);folder.mkdir(parents=True)
 (folder/'input.csv').write_text(frame.to_csv(index=False),encoding='utf-8')
 info.update(id=i,created=now(),synthetic=synthetic,sha256=sha(folder/'input.csv'));save(folder/'profile.json',info);return info
def run_status(i):
 folder=run_folder(i);s=read(folder/'status.json');p=PROCESSES.get(i)
 if s['stage'] in ['preparing','training','evaluating','queued'] and p and p.poll() is not None:
  s.update(stage='failed',error='The worker stopped unexpectedly. Open the log for details.',updated=now());save(folder/'status.json',s)
 return s
def start_run(payload):
 with RUN_LOCK:
  # A finished worker may still be shutting down numerical-library threads.
  for i,p in PROCESSES.items():
   if p.poll() is None and read(run_folder(i)/'status.json').get('stage') in ['completed','failed']:
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
  if any(p.poll() is None for p in PROCESSES.values()):raise ValueError('An experiment is already running. Wait for it or stop it before starting another.')
  config=validate_config(payload.get('config',{}));schema=payload.get('schema',{});data=dataset_folder(payload.get('dataset_id'))
  frame=csv_frame((data/'input.csv').read_text(encoding='utf-8'));audit=validate_data(frame,schema,config['clients'])
  info=read(data/'profile.json');i=uuid.uuid4().hex[:12];folder=run_folder(i);folder.mkdir(parents=True)
  shutil.copy2(data/'input.csv',folder/'input.csv')
  source={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'app.json',ROOT/'worker.py',ROOT/'adapter.py',ROOT/'common.py',*sorted((ROOT/'engine').rglob('*.py'))]}
  request=dict(id=i,app=META['name'],version='1.0.0',created=now(),dataset_id=info['id'],filename=info['filename'],synthetic=info['synthetic'],config=config,schema=schema,input_sha256=sha(folder/'input.csv'),application_source_sha256=source,data_audit=audit,release_dp_claim=False)
  save(folder/'request.json',request);save(folder/'status.json',dict(id=i,name=config['name'],stage='queued',percent=0,done=0,total=len(config['methods'])*len(config['seeds']),round=0,rounds=config['rounds'],method='',created=request['created'],updated=now()))
  with (folder/'run.log').open('w',encoding='utf-8') as log:PROCESSES[i]=subprocess.Popen([sys.executable,'-u',str(ROOT/'worker.py'),str(folder)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  return read(folder/'status.json')

class Handler(BaseHTTPRequestHandler):
 server_version='ResearchStudio/1.0'
 def log_message(self,fmt,*args):pass
 def headers_common(self):
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('Cache-Control','no-store');self.send_header('X-Frame-Options','DENY')
  self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
 def reply(self,value,status=200):
  data=json.dumps(clean(value),allow_nan=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.headers_common();self.end_headers();self.wfile.write(data)
 def file(self,path,download=False):
  if not path.is_file():raise FileNotFoundError('File is not available yet.')
  self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(str(path))[0] or 'application/octet-stream');self.send_header('Content-Length',str(path.stat().st_size))
  if download:self.send_header('Content-Disposition','attachment; filename="'+path.name+'"')
  self.headers_common();self.end_headers()
  with path.open('rb') as f:shutil.copyfileobj(f,self.wfile)
 def gate(self,write=False):
  host=self.headers.get('Host','')
  if host not in [f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}']:raise PermissionError('Only the local application host is permitted.')
  origin=self.headers.get('Origin')
  if origin and origin not in [f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}']:raise PermissionError('Cross-origin requests are blocked.')
  if self.headers.get('Sec-Fetch-Site')=='cross-site':raise PermissionError('Cross-site requests are blocked.')
  if write and not secrets.compare_digest(self.headers.get('X-Research-Token',''),TOKEN):raise PermissionError('Refresh the application before submitting changes.')
 def do_GET(self):
  try:
   self.gate();path=urlparse(self.path).path;parts=path.strip('/').split('/')
   if path=='/api/bootstrap':return self.reply(dict(meta=META,defaults=defaults(),token=TOKEN,workspace=str(WORK)))
   if path=='/api/datasets':return self.reply([read(p) for p in sorted((WORK/'datasets').glob('*/profile.json'),key=lambda p:p.stat().st_mtime,reverse=True)])
   if path=='/api/runs':return self.reply([run_status(p.parent.name) for p in sorted((WORK/'runs').glob('*/status.json'),key=lambda p:p.stat().st_mtime,reverse=True)])
   if path=='/api/evidence':return self.reply(read(ROOT/'reference/evidence.json'))
   if path=='/api/sample':return self.file(ROOT/'sample_data.csv',True)
   if len(parts)==4 and parts[:2]==['api','runs']:
    folder=run_folder(parts[2]);what=parts[3]
    if what=='status':return self.reply(run_status(parts[2]))
    if what=='results':return self.reply(read(folder/'results.json'))
    if what=='request':return self.reply(read(folder/'request.json'))
    if what=='log':return self.reply({'text':(folder/'run.log').read_text(encoding='utf-8',errors='replace')[-20000:]})
   if len(parts)==3 and parts[0]=='download':
    if parts[2] not in ALLOWED_DOWNLOADS:raise PermissionError('This file is not a downloadable artifact.')
    return self.file(run_folder(parts[1])/parts[2],True)
   if len(parts)==2 and parts[0]=='reference':
    allowed={'paper.pdf','audit_report.json','reference_tables.zip'}
    if parts[1] not in allowed:raise FileNotFoundError('Unknown reference asset.')
    return self.file(ROOT/'reference'/parts[1],parts[1]!='paper.pdf')
   if path in ['/','/index.html']:return self.file(ROOT/'static/index.html')
   if path in ['/app.js','/style.css','/logo.svg']:return self.file(ROOT/'static'/path[1:])
   raise FileNotFoundError('Page not found.')
  except (ValueError,KeyError) as e:self.reply({'error':str(e)},400)
  except FileNotFoundError as e:self.reply({'error':str(e)},404)
  except PermissionError as e:self.reply({'error':str(e)},403)
  except (BrokenPipeError,ConnectionResetError):pass
  except Exception as e:self.reply({'error':str(e)},500)
 def do_POST(self):
  try:
   self.gate(True)
   length=int(self.headers.get('Content-Length','0'))
   if not 0<length<=70*1024*1024:raise ValueError('Request is too large or empty.')
   if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('Expected JSON request.')
   payload=json.loads(self.rfile.read(length));path=urlparse(self.path).path;parts=path.strip('/').split('/')
   if path=='/api/datasets/upload':return self.reply(register_dataset(payload['csv'],payload['filename']),201)
   if path=='/api/datasets/sample':return self.reply(register_dataset((ROOT/'sample_data.csv').read_text(),'synthetic_demo.csv',True),201)
   if path=='/api/validate':
    frame=csv_frame((dataset_folder(payload['dataset_id'])/'input.csv').read_text());return self.reply(validate_data(frame,payload['schema'],int(payload.get('clients',8))))
   if path=='/api/runs':return self.reply(start_run(payload),201)
   if len(parts)==4 and parts[:2]==['api','runs'] and parts[3]=='cancel':
    i=ident(parts[2]);p=PROCESSES.get(i)
    if not p or p.poll() is not None:raise ValueError('This experiment is no longer running.')
    p.terminate()
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
    s=read(run_folder(i)/'status.json');s.update(stage='cancelled',updated=now(),error='Stopped by the researcher. Clone the configuration to start a fresh experiment.');save(run_folder(i)/'status.json',s);return self.reply(s)
   raise FileNotFoundError('Unknown operation.')
  except (ValueError,KeyError,TypeError) as e:self.reply({'error':str(e)},400)
  except FileNotFoundError as e:self.reply({'error':str(e)},404)
  except PermissionError as e:self.reply({'error':str(e)},403)
  except (BrokenPipeError,ConnectionResetError):pass
  except Exception as e:self.reply({'error':str(e)},500)

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--port',type=int,default=META['port']);parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
 WORK.mkdir(parents=True,exist_ok=True)
 # A server singleton prevents concurrent workspace ownership and stale-state ambiguity.
 lock_path=WORK/'APP_LOCK.json'
 try:
  with lock_path.open('x') as f:json.dump({'pid':os.getpid(),'created':now()},f)
 except FileExistsError:
  print('A workspace lock exists. Close the existing app. If the previous process crashed, verify it is stopped, then delete workspace/APP_LOCK.json.');return 1
 server=None
 try:
  for p in (WORK/'runs').glob('*/status.json'):
   s=read(p)
   if s.get('stage') in ['preparing','training','evaluating','queued']:s.update(stage='interrupted',error='The previous application session ended. Clone to start a fresh study.');save(p,s)
  server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);server.daemon_threads=True
  url=f'http://127.0.0.1:{server.server_port}'
  print(f'\n{META["name"]} is ready at {url}\nKeep this window open. Press Ctrl+C to stop.\n',flush=True)
  if not args.no_browser:threading.Timer(1,lambda:webbrowser.open(url)).start()
  server.serve_forever()
 except KeyboardInterrupt:pass
 finally:
  for i,p in PROCESSES.items():
   if p.poll() is None:
    p.terminate()
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:p.kill();p.wait()
  if server:server.server_close()
  lock_path.unlink(missing_ok=True)
 return 0
if __name__=='__main__':sys.exit(main())
