"""Create an editable Word copy of the conference manuscript using native equations."""
from pathlib import Path
import re,subprocess
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent;P=ROOT/'paper';OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
s=(P/'DP_CAST_Rewritten.tex').read_text();title=re.search(r'\\title\{([^}]+)\}',s).group(1)
keys=re.findall(r'\\bibitem\{([^}]+)\}',s);refs={k:i+1 for i,k in enumerate(keys)}
aux=(P/'DP_CAST_Rewritten.aux').read_text();labels=dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}',aux))
s=s[s.index('\\begin{abstract}'):s.index('\\end{document}')]
s=re.sub(r'\\cite\{([^}]+)\}',lambda m:'['+', '.join(str(refs[k]) for k in m.group(1).split(','))+']',s)
s=re.sub(r'\\ref\{([^}]+)\}',lambda m:labels[m.group(1)],s)
for command in ['centering','balance','smallskip','footnotesize']:s=s.replace('\\'+command,'')
s=s.replace(r'\{-p_j\log p_j-(1-p_j)\log(1-p_j)\}', r'{\left[-p_j\log p_j-(1-p_j)\log(1-p_j)\right]}')
s=s.replace('\\begin{abstract}','\\section*{Abstract}').replace('\\end{abstract}','')
s=s.replace('\\begin{IEEEkeywords}','\\noindent\\textbf{Index terms:} ').replace('\\end{IEEEkeywords}','')
# Extract floats and number their captions using the compiled reference map.
def float_(m):
 kind,body=m.group(1),m.group(2);lab=re.search(r'\\label\{([^}]+)\}',body).group(1)
 cap=re.search(r'\\caption\{([^}]+)\}',body).group(1)
 body=re.sub(r'\\caption\{[^}]+\}','',body);body=re.sub(r'\\label\{[^}]+\}','',body)
 caption='\\noindent\\textbf{'+('Figure ' if kind.startswith('figure') else 'Table ')+labels[lab]+'. '+cap+'}\\par\n'
 if kind.startswith('figure'):return body+'\n'+caption
 return caption+body
s=re.sub(r'\\begin\{(figure\*?|table\*?)\}\[t\](.*?)\\end\{\1\}',float_,s,flags=re.S)
s=re.sub(r'\\includegraphics\[[^]]+\]\{figures/([^}]+)\.pdf\}',r'\\includegraphics[width=6.55in]{figures/\1.png}',s)
s=re.sub(r'\\label\{[^}]+\}','',s)
# Native math with explicit equation numbers, including each align row.
number=[0]
def equations(m):
 env,body=m.group(1),m.group(2)
 if env=='equation':
  number[0]+=1;return '\\['+body.strip()+'\\qquad ('+str(number[0])+')\\]'
 rows=body.strip().split('\\\\');out=[]
 for row in rows:
  if row.strip():number[0]+=1;out.append(row.strip()+'\\qquad ('+str(number[0])+')')
 return '\\[\\begin{aligned}'+('\\\\\n'.join(out))+'\\end{aligned}\\]'
s=re.sub(r'\\begin\{(equation|align)\}(.*?)\\end\{\1\}',equations,s,flags=re.S)
assert number[0]==19,number
for k in ['clip','AP','TV','erf']:s=s.replace('\\'+k,'\\operatorname{'+k+'}')
s=s.replace('\\begin{thebibliography}{20}','\\section*{References}').replace('\\end{thebibliography}','')
s=re.sub(r'\\bibitem\{([^}]+)\}',lambda m:'\\noindent ['+str(refs[m.group(1)])+'] ',s)
# Separate reference paragraphs; all original metadata and verified links remain.
s=s.replace('\n\\noindent [','\n\n\\noindent [')
header='''\\documentclass{article}
\\usepackage{amsmath,graphicx,booktabs,array}
\\title{'''+title+'''}
\\date{}
\\begin{document}
\\maketitle
\\begin{center}
Rebecca Adhiambo Okaka and Evanson Mwangi Karanja\\\\
Department of Computing\\\\
Isaac Nyabisa Oteyo\\\\
Department of Information Technology\\\\
Jomo Kenyatta University of Agriculture and Technology\\\\
Nairobi, Kenya
\\end{center}
'''
(P/'word_input.tex').write_text(header+s+'\n\\end{document}')
out=OUT/'DP_CAST_Rewritten.docx'
r=subprocess.run(['pandoc','word_input.tex','-f','latex','-o',str(out)],cwd=P,text=True,capture_output=True);(P/'word_conversion.log').write_text(r.stderr);r.check_returncode()
doc=Document(out);sec=doc.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=Inches(.72);sec.bottom_margin=Inches(.72);sec.left_margin=Inches(.75);sec.right_margin=Inches(.75)
for st in doc.styles:
 if st.type==1:
  st.font.name='Times New Roman';st.font.size=Pt(11);st.font.color.rgb=RGBColor(0,0,0)
  st.paragraph_format.line_spacing=1.02;st.paragraph_format.space_after=Pt(5)
for name,size,before,after in [('Title',17,0,9),('Heading 1',13,12,6),('Heading 2',11.5,9,5)]:
 st=next(st for st in doc.styles if st.name==name);st.font.size=Pt(size);st.font.bold=True;st.paragraph_format.space_before=Pt(before);st.paragraph_format.space_after=Pt(after);st.paragraph_format.keep_with_next=True
 if st.element.pPr is not None:
  for x in list(st.element.pPr):
   if x.tag==qn('w:pBdr'):st.element.pPr.remove(x)
# Preserve bibliography numbers that Pandoc treats as optional LaTeX arguments.
in_refs=False;ref_n=0;section_n=0
roman=['I','II','III','IV','V','VI','VII','VIII','IX','X']
for p in doc.paragraphs:
 if p.style.name=='Heading 1':
  if p.text=='References':in_refs=True;continue
  if p.text!='Abstract':
   p.text=roman[section_n]+'. '+p.text;section_n+=1
 elif in_refs and p.text.strip():
  ref_n+=1;r=p.add_run('['+str(ref_n)+'] ')
  p._p.remove(r._r);p._p.insert(1 if p._p.pPr is not None else 0,r._r)
assert ref_n==20,ref_n
for p in doc.paragraphs:
 p.paragraph_format.widow_control=True
 if p.style.name=='Title':p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 if p.text.startswith(('Table ','Figure ')):
  p.paragraph_format.keep_with_next=p.text.startswith('Table ');p.paragraph_format.space_before=Pt(6);p.paragraph_format.space_after=Pt(6)
  for run in p.runs:run.font.size=Pt(10)
 if re.match(r'^\[\d+\]',p.text):
  p.paragraph_format.left_indent=Inches(.28);p.paragraph_format.first_line_indent=Inches(-.28)
  for run in p.runs:run.font.size=Pt(10)
 if p._p.xpath('.//w:drawing'):
  p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
# Carefully size each numeric comparison table.
widths=[[3.3,2.25,1.45],[1.7,2.55,2.75],[1.1,1.45,1.45,1.45,1.55],[2.2,1.7,1.7,1.4],[1.2,.7,.8,.8,.8,.8,1.0,.9]]
assert len(doc.tables)==5,len(doc.tables)
for ti,t in enumerate(doc.tables):
 t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 pr=t._tbl.tblPr;borders=OxmlElement('w:tblBorders')
 for edge in ['top','left','bottom','right','insideH','insideV']:
  x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
 pr.append(borders)
 w=widths[ti];w=[v*7/sum(w) for v in w]
 for col,v in zip(t.columns,w):col.width=Inches(v)
 for ri,row in enumerate(t.rows):
  if ri==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
  row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
  for ci,cell in enumerate(row.cells):
   cell.width=Inches(w[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   cp=cell._tc.get_or_add_tcPr();margin=OxmlElement('w:tcMar')
   for edge,val in [('top','65'),('bottom','65'),('left','65'),('right','65')]:
    x=OxmlElement('w:'+edge);x.set(qn('w:w'),val);x.set(qn('w:type'),'dxa');margin.append(x)
   cp.append(margin)
   if ri==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E6EDF2');cp.append(sh)
   for p in cell.paragraphs:
    p.paragraph_format.space_after=Pt(0);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=1.02
    p.alignment=WD_ALIGN_PARAGRAPH.LEFT if ci==0 or ti==1 else WD_ALIGN_PARAGRAPH.CENTER
    for run in p.runs:run.font.size=Pt(9 if ti==4 else 10);run.font.bold=ri==0
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
doc.core_properties.title=title;doc.core_properties.author='Rebecca Adhiambo Okaka; Evanson Mwangi Karanja; Isaac Nyabisa Oteyo';doc.save(out)
print({'docx':str(out),'tables':len(doc.tables),'native_math_elements':len(doc.element.xpath('.//m:oMath')),'equations_numbered':number[0]})
