"""Recompute manuscript evidence from the two supplied result archives.
Run: python audit_evidence.py --evidence evidence --out derived
No training, data download, or unopened test evaluation occurs.
"""
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.special import ndtr
from sklearn.metrics import average_precision_score, roc_auc_score

ap=argparse.ArgumentParser();ap.add_argument('--evidence',type=Path,default=Path('evidence'));ap.add_argument('--out',type=Path,default=Path('derived'));args=ap.parse_args();args.out.mkdir(exist_ok=True,parents=True)
old=args.evidence/'results_development';new=args.evidence/'smoke';checks=[]
def check(name,actual,expected):
    ok=(not np.isfinite(actual) and (expected is None or not np.isfinite(expected))) or (expected is not None and np.isclose(actual,expected,rtol=1e-9,atol=1e-12))
    checks.append({'check':name,'passed':bool(ok)})
    if not ok:raise AssertionError((name,actual,expected))
def read(p):return json.loads(p.read_text())
def binary(y,p,t=.5):
    y=np.asarray(y);p=np.asarray(p);n=len(y);pos=int(y.sum());neg=n-pos;pred=p>=t
    tp=int(np.sum(pred&(y==1)));fp=int(np.sum(pred&(y==0)));fn=pos-tp;tn=neg-fp
    recall=tp/pos if pos else np.nan;sp=tn/neg if neg else np.nan
    ps=np.clip(p,1e-12,1-1e-12)
    return {'ap':float(average_precision_score(y,p)) if pos else np.nan,'auroc':float(roc_auc_score(y,p)) if pos and neg else np.nan,'brier':float(np.mean((p-y)**2)) if n else np.nan,'log_loss':float(-np.mean(y*np.log(ps)+(1-y)*np.log1p(-ps))) if n else np.nan,'recall':recall,'specificity':sp,'balanced_accuracy':(recall+sp)/2 if pos and neg else np.nan,'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else np.nan}
source_checks=[]
for folder,key,source in [(old,'sources',old/'executed_source'),(new,'source',new/'source')]:
    for name,sha in read(folder/'protocol_lock.json')[key].items():
        ok=hashlib.sha256((source/name).read_bytes()).hexdigest()==sha
        source_checks.append({'archive':folder.name,'file':name,'passed':ok})
        assert ok
old_rows=[];local_rows=[];ledger_rows=[]
for p in sorted((old/'runs').iterdir()):
    s=read(p/'training_summary.json');r=pd.read_csv(p/'rounds.csv');l=pd.read_csv(p/'ledger.csv');c=pd.read_csv(p/'controller_learning.csv')
    check(p.name+'/final_val',float(r.iloc[-1].validation_mean_head_ap),s['validation_mean_head_ap'])
    stored=pd.read_csv(p/'BENCHMARK_ONLY_NOT_PRIVATE/local_metrics.csv').set_index('client')
    for i in range(8):
        with np.load(p/f'BENCHMARK_ONLY_NOT_PRIVATE/client_{i}_local_predictions.npz') as z:v=binary(z['y'],z['p'])
        for k in ['ap','auroc']:check(p.name+f'/client{i}/'+k,v[k],stored.loc[i,k])
        local_rows.append({'method':s['method'],'client':i,**stored.loc[i].to_dict()})
    old_rows.append({'method':s['method'],'final_validation_ap':s['validation_mean_head_ap'],'best_validation_ap':r.validation_mean_head_ap.max(),'controller_updates':s['controller_updates'],'max_rho':s['max_recorded_rho'],'local_ap':s['benchmark_local_mean_ap'],'local_auroc':s['benchmark_local_mean_auroc']})
    for client,d in l.groupby('client'):
        spent=d.charged_rho.sum();recorded=d.cumulative_charged_rho.iloc[-1];check(p.name+f'/ledger{client}',spent,recorded)
        ledger_rows.append({'version':'development','method':s['method'],'client':client,'sum_rho':spent,'cap':s['rho_capacity'],'within_implemented_tolerance':bool(spent<=s['rho_capacity']*(1+1e-12))})
old_table=pd.DataFrame(old_rows);old_table.to_csv(args.out/'development_results.csv',index=False)
p=next((old/'runs').glob('*__dpcast'));d=pd.read_csv(p/'BENCHMARK_ONLY_NOT_PRIVATE/context_distortion.csv');pc=pd.read_csv(p/'protected_context.csv');learn=pd.read_csv(p/'controller_learning.csv');ledger=pd.read_csv(p/'ledger.csv');actions=pd.read_csv(p/'actions.csv');replay=pd.read_csv(p/'replay_index.csv')
merged=d.merge(pc[['round','client','coordinate','noise_sd']],on=['round','client','coordinate'],validate='one_to_one')
merged['expected_boundary']=ndtr(-merged.raw/merged.noise_sd)+ndtr((merged.raw-1)/merged.noise_sd)
merged['boundary']=(merged.protected<=0)|(merged.protected>=1)
bycoord=merged.groupby('coordinate').agg(mae=('absolute_error','mean'),boundary=('boundary','mean'),n=('boundary','size')).reset_index();bycoord.to_csv(args.out/'development_context.csv',index=False)
query=d.drop_duplicates(['round','client']);up=ledger[ledger.mechanism=='joint_encoder_head_update'];ratio=up.noise_sd/(up.sensitivity/2)
old_facts={'context_queries':len(query),'context_coordinates':len(d),'boundary_count':int(merged.boundary.sum()),'boundary_fraction':float(merged.boundary.mean()),'expected_boundary_fraction':float(merged.expected_boundary.mean()),'context_mae':float(d.absolute_error.mean()),'context_sd_min':float(pc.noise_sd.min()),'context_sd_max':float(pc.noise_sd.max()),'raw_action_changes':int(query.action_changed.sum()),'policy_frozen_disagreements':int((actions.greedy_trained!=actions.greedy_frozen).sum()),'first_active_round':int(learn[learn.updates>0].iloc[0]['round'])+1,'first_q_loss':float(learn.q_loss.dropna().iloc[0]),'last_q_loss':float(learn.q_loss.dropna().iloc[-1]),'mean_abs_weighted_gain':float((.6*learn.reward_gain).abs().mean()),'weighted_context_change':float(.1*learn.reward_context_change.mean()),'weighted_risk':float(.1*learn.reward_risk.mean()),'weighted_privacy':float(.1*learn.reward_privacy.mean()),'replay_gaps_over_one':int(((replay.next_round-replay.source_round)>1).sum()),'update_noise_sd_to_clip_min':float(ratio.min()),'update_noise_sd_to_clip_max':float(ratio.max()),'noise_rms_to_clip_min':float(ratio.min()*math.sqrt(18721)),'noise_rms_to_clip_max':float(ratio.max()*math.sqrt(18721)),'evaluation_noise_sd':float(ledger[ledger.mechanism=='local_evaluation'].noise_sd.iloc[0])}
new_rows=[];context_rows=[]
for p in sorted((new/'runs').iterdir()):
    s=read(p/'complete.json');stored=read(p/'test_metrics.json');account=read(p/'privacy_accounting.json')
    assert hashlib.sha256((p/'model.npz').read_bytes()).hexdigest()==s['model_sha256']
    with np.load(p/'test_predictions.npz') as z:
        vals=[binary(z['y'],prob,float(t)) for prob,t in zip(z['p'],z['thresholds'])]
        last=[binary(z['y'],prob) for prob in z['last_p']]
        ensemble=binary(z['y'],z['p'].mean(0),float(z['ensemble_threshold']))
    for k in vals[0]:
        a=np.array([v[k] for v in vals]);check(p.name+'/mean_'+k,float(np.nanmean(a)),stored['mean_'+k]);check(p.name+'/valid_'+k,int(np.isfinite(a).sum()),stored['valid_'+k])
        check(p.name+'/last_mean_'+k,float(np.nanmean([v[k] for v in last])),stored['last_mean_'+k]);check(p.name+'/ensemble_'+k,ensemble[k],stored['ensemble_'+k])
    check(p.name+'/worst_head_ap',min(v['ap'] for v in vals),stored['worst_head_ap']);check(p.name+'/head_ap_sd',np.std([v['ap'] for v in vals]),stored['head_ap_sd'])
    new_rows.append({k:stored[k] for k in ['method','selected_round','mean_ap','last_mean_ap','mean_auroc','mean_brier','mean_balanced_accuracy','mean_recall','mean_specificity','ensemble_ap']}|{'controller_updates':s['controller_updates'],'context_queries':s['context_queries'],'release_dimension':s['release_dimension'],'full_dimension':s['full_dimension'],'max_rho':account['max_spent']})
    c=read(p/'BENCHMARK_ONLY_NOT_PRIVATE/context_diagnostics.json')
    if c:
        raw=np.concatenate([v['raw'] for v in c]);dec=np.concatenate([v['decoded'] for v in c]);noisy=np.concatenate([v['noisy'] for v in c])
        context_rows.append({'method':s['method'],'queries':len(c),'coordinates':len(raw),'sd_min':min(v['noise_sd'] for v in c),'sd_max':max(v['noise_sd'] for v in c),'decoded_mae':float(np.abs(raw-dec).mean()),'constant_mae_same_queries':float(np.abs(raw-.5).mean()),'clip_mae_same_queries':float(np.abs(raw-np.clip(noisy,0,1)).mean()),'raw_noisy_boundary_fraction':float(((noisy<=0)|(noisy>=1)).mean()),'expected_boundary_fraction':float(np.mean([v['expected_boundary'] for v in c])),'decoded_min':float(dec.min()),'decoded_max':float(dec.max()),'tv_min':min(v['conditional_single_query_action_tv_bound'] for v in c),'tv_max':max(v['conditional_single_query_action_tv_bound'] for v in c)})
    l=pd.read_csv(p/'privacy_ledger.csv') if (p/'privacy_ledger.csv').stat().st_size>1 else pd.DataFrame()
    if len(l):
        for client,g in l.groupby('client'):
            spent=g.rho.sum();check(p.name+f'/ledger{client}',spent,account['rho_spent'][int(client)])
            ledger_rows.append({'version':'revised_smoke','method':s['method'],'client':client,'sum_rho':spent,'cap':account['rho_capacity'],'within_implemented_tolerance':bool(spent<=account['rho_capacity'])})
new_table=pd.DataFrame(new_rows);new_table.to_csv(args.out/'synthetic_results.csv',index=False);pd.DataFrame(context_rows).to_csv(args.out/'synthetic_context.csv',index=False);pd.DataFrame(local_rows).to_csv(args.out/'development_local_metrics.csv',index=False);pd.DataFrame(ledger_rows).to_csv(args.out/'ledger_checks.csv',index=False)
assert all(v['within_implemented_tolerance'] for v in ledger_rows)
report={'source_checks':source_checks,'checks':checks,'all_passed':all(v['passed'] for v in checks),'check_count':len(checks),'old_facts':old_facts,'evidence_scope':'4 Cervical development runs and 9 synthetic software-check runs; no new training','not_auditable_from_exports':['Development validation predictions are absent; final validation scores agree between logs and summaries only.','Raw input arrays are omitted from the standard smoke export; saved test predictions remain auditable.'],'comparison_delta_proposed_fixed_synthetic':float(new_table.set_index('method').loc['proposed','mean_ap']-new_table.set_index('method').loc['fixed','mean_ap'])}
(args.out/'audit_report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':len(checks),'source_files':len(source_checks),'all_passed':True,'old_facts':old_facts,'synthetic_context':context_rows},indent=2))
