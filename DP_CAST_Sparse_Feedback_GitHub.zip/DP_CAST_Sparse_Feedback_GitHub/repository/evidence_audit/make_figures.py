from pathlib import Path
import json,numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
ROOT=Path(__file__).parent; OUT=ROOT/'paper/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':8,'pdf.fonttype':42,'ps.fonttype':42})
colors={'fixed':'#1b6a9b','random':'#d08020','frozen':'#5b7965','dpcast':'#9c3e60'}
def save(fig,name):
 fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');fig.savefig(OUT/(name+'.png'),dpi=250,bbox_inches='tight');plt.close(fig)
# Protocol illustration is drawn exactly from the executed implementation.
fig,ax=plt.subplots(figsize=(7.05,3.15));ax.set_xlim(0,10);ax.set_ylim(-.15,4.5);ax.axis('off')
def box(x,y,w,h,s,fill='#edf3f6'):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.05,rounding_size=0.05',facecolor=fill,edgecolor='#35444f',linewidth=.7));ax.text(x+w/2,y+h/2,s,ha='center',va='center',fontsize=8.5)
def arrow(a,b,label=None,xy=None):
 ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#35444f','lw':1.0})
 if label:ax.text(*xy,label,fontsize=8,ha='center',va='center',bbox={'facecolor':'white','edgecolor':'none','pad':1})
box(.12,3.32,2.5,.8,'Public fit data\nPreprocessing\nWarm start and basis')
box(.12,1.55,2.5,1.05,'Trusted client\nPrivate data and head\nLocal training')
box(3.3,1.55,2.2,1.05,'Gaussian releases\nContext and clipping\nJoint model update\nFinal local evaluation')
box(6.18,1.55,3.45,1.05,'Server\nCached context and DQN\nEncoder and head proxies')
box(6.18,3.32,3.45,.8,'Public controller data\nAP reward')
box(6.18,.02,3.45,.8,'Selection then final test\nCheckpoint and threshold\nModel commitment')
arrow((1.37,3.32),(1.37,2.6));arrow((2.62,2.08),(3.3,2.08));arrow((5.5,2.08),(6.18,2.08));arrow((7.9,3.32),(7.9,2.6));arrow((7.9,1.55),(7.9,.82))
ax.plot([6.18,5.95,5.95,1.37],[1.8,1.8,1.0,1.0],color='#35444f',lw=1)
arrow((1.37,1.0),(1.37,1.55));ax.text(3.55,.66,'Public action and protected encoder',ha='center',fontsize=8)
ax.text(.1,4.28,'Client computation',fontsize=9,fontweight='bold');ax.text(6.18,4.28,'Observable server state',fontsize=9,fontweight='bold')
save(fig,'protocol')
# Earlier development trajectories.
fig,axs=plt.subplots(1,2,figsize=(7.05,2.45))
for method in ['fixed','random','frozen','dpcast']:
 p=next((ROOT/'evidence/results_development/runs').glob('*__'+method));d=pd.read_csv(p/'rounds.csv')
 axs[0].plot(d['round']+1,d.validation_mean_head_ap,color=colors[method],label={'dpcast':'Earlier DP-CAST'}.get(method,method.title()),lw=1.6)
p=next((ROOT/'evidence/results_development/runs').glob('*__dpcast'));d=pd.read_csv(p/'controller_learning.csv');axs[1].plot(d['round']+1,d.q_loss,color=colors['dpcast'],lw=1.8)
axs[0].set_ylabel('Mean validation AP');axs[0].set_ylim(.1836,.1883);axs[0].legend(loc='lower left',ncol=2,frameon=False,fontsize=7)
axs[1].set_ylabel('Mean minibatch Huber loss');axs[1].set_ylim(0,.55)
for a,t in zip(axs,['(a) Predictive score','(b) Controller optimization']):
 a.set_xlabel('Communication round');a.set_xticks([1,5,10,15,20]);a.set_title(t);a.spines[['top','right']].set_visible(False);a.grid(alpha=.15)
fig.tight_layout(w_pad=2);save(fig,'development')
# Decoder behavior on the exact same 24 scalar observations.
p=next((ROOT/'evidence/smoke/runs').glob('*_proposed_s*'));c=json.loads((p/'BENCHMARK_ONLY_NOT_PRIVATE/context_diagnostics.json').read_text());raw=np.array([v['raw'] for v in c]);decoded=np.array([v['decoded'] for v in c]);noisy=np.array([v['noisy'] for v in c]);
fig,axs=plt.subplots(1,2,figsize=(7.05,2.65))
for j,(label,col,mark) in enumerate([('Sensitivity score','#1b6a9b','o'),('Entropy','#9c3e60','s')]):axs[0].scatter(raw[:,j],decoded[:,j],s=25,label=label,color=col,marker=mark,alpha=.85)
axs[0].plot([0,1],[0,1],ls='--',color='gray',lw=.8,label='Identity');axs[0].axhline(.5,color='gray',lw=.7,alpha=.6);axs[0].set(xlim=(0,1.02),ylim=(0,1.02),xlabel='Raw context',ylabel='Decoded context',title='(a) Posterior shrinkage');axs[0].legend(frameon=False,fontsize=7,loc='upper left')
values=[np.abs(raw-np.clip(noisy,0,1)).mean(),np.abs(raw-.5).mean(),np.abs(raw-decoded).mean()]
axs[1].barh(['Direct clipping','Constant 0.5','Posterior mean'],values,color=['#a0acb6','#6f7d88','#1b6a9b'],height=.58);axs[1].invert_yaxis();axs[1].set(xlim=(0,.56),xlabel='Mean absolute error',title='(b) Same-query decoding audit')
for i,v in enumerate(values):axs[1].text(v+.012,i,f'{v:.4f}',va='center',fontsize=8)
for a in axs:a.spines[['top','right']].set_visible(False)
fig.tight_layout(w_pad=2);save(fig,'decoder')
