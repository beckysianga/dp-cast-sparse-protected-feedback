# Reproducibility package v1.0.0

Six-page manuscript, both implementations and notebooks, exact reported
configurations, all exported evidence for four Cervical development and nine
synthetic verification runs, source audits, figures, and reproduction tools.
Saved-output audit: 462 consistency checks, 21 source hashes, and nine model
hashes verified. The old secret seed/reference predictions and some raw input
arrays are absent as documented. No new training study was run during packaging.
