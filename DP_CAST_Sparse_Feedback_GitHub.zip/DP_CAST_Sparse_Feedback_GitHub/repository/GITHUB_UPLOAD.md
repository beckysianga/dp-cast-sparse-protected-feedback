# Upload this research repository to GitHub

Use a separate repository for each paper. Unzip the delivery first.
Upload the CONTENTS of `repository/`, so README.md appears at the GitHub root.
Uploading only the delivery ZIP would hide the source files from normal browsing.

## Recommended: GitHub Desktop (Windows or macOS)

1. Install GitHub Desktop from https://desktop.github.com/ and sign in.
2. Choose File > New repository. Use the suggested name below, and choose an
   empty location on your computer. Leave the initial README, Git ignore, and
   license options unset because the package supplies its own metadata.
3. Click Create repository, then open that new folder in File Explorer/Finder.
4. Copy ALL files and folders INSIDE the delivery's `repository/` folder into
   the new repository folder. Include `.gitignore` and `.gitattributes`.
   Do not copy the parent delivery folder, release-assets, or a generated
   `.venv`, `results`, or `reproduced` folder.
5. Return to GitHub Desktop, review the Changes list, enter the commit summary
   `Add manuscript, code, and reproducibility evidence`, and commit to main.
6. Click Publish repository. Choose public when you want readers to access it,
   or keep it private while you finish checking it. Click Publish repository.
7. Open the repository on GitHub and confirm that README.md, manuscript,
   code/experiment, evidence, requirements.txt, and tools are visible.
8. Follow the release instructions below when large result files are supplied.

No repository has been created or published by this delivery. The author can
choose the account, visibility, and code license during publication.

## Web upload alternative

Create a new repository on GitHub using the + menu, then New repository.
Choose the suggested name; leave automatic README/license/.gitignore creation
off. After creation, use "uploading an existing file" (or Add file > Upload
files). Upload the extracted repository contents while preserving directories.
Commit the uploaded files. Repeat as needed: browser upload accepts at most
100 files per batch and 25 MiB per file. These projects have many evidence files,
so Desktop is simpler. Never upload the large release assets as ordinary files.

## Versioned release

From the published repository, choose Releases > Draft a new release. Create
tag `v1.0.0`, target main, and title it `Reproducibility package v1.0.0`.
Use the supplied RELEASE_NOTES.md as the description. Attach the specified
large assets, if any, before publishing. GitHub-generated "Source code (zip)"
downloads contain the repository snapshot; they do not substitute for separate
release assets. Record the repository URL and release tag in your paper's
data/code availability statement after publication.

## Official instructions

- https://docs.github.com/en/desktop/overview/creating-your-first-repository-using-github-desktop
- https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository
- https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github

Suggested repository name: `dp-cast-sparse-protected-feedback`.

No separate large result assets are required for this paper. All reported evidence is inside the repository.
