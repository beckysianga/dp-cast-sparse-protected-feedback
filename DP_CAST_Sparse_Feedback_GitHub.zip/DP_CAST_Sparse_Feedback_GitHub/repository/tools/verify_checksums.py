"""Verify the immutable files listed in CHECKSUMS.json using only Python."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[1]

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def main():
    data=json.loads((ROOT/'CHECKSUMS.json').read_text())
    failures=[]
    for name,expected in data['files'].items():
        path=ROOT/name
        if not path.is_file():failures.append(name+': missing')
        elif path.stat().st_size!=expected['bytes'] or digest(path)!=expected['sha256']:
            failures.append(name+': changed')
    if failures:
        print('\n'.join(failures));return 1
    print(f"Verified {len(data['files'])} packaged repository files.")
    print('CHECKSUMS.json is excluded from its own inventory; results/reproduced are separate outputs.')
    return 0

if __name__=='__main__':sys.exit(main())
