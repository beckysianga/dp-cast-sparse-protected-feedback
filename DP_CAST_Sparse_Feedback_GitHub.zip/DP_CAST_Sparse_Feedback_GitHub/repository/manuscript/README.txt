DP CAST WITH SPARSE PROTECTED FEEDBACK FOR ADAPTIVE FEDERATED LEARNING
IConAECC 2026: six-page initial-review version

OVERLEAF
1. Choose New Project > Upload Project and upload the ZIP file.
2. Set the main document to main.tex and the compiler to pdfLaTeX.
3. Recompile. The verified layout is six US Letter pages with an IEEE
   two-column layout and 10-point body text.

FILES
main.tex        Complete editable manuscript, equations, and tables.
references.tex  All 20 references, included with LaTeX's thebibliography.
IEEEtran.cls    IEEE conference document class, version 1.8b (unmodified).
protocol.pdf    Figure 1: protocol and privacy boundary (vector PDF).
development.pdf Figure 2: Cervical development results (vector PDF).
decoder.pdf     Figure 3: synthetic decoding audit (vector PDF).
compiled/DP_CAST_IConAECC_2026_6_Pages.pdf
                The verified six-page paper for comparison.
README.txt      These instructions.

COMPILATION
The source was verified using pdfLaTeX, TeX Live 2023/Debian.
Choose TeX Live 2023 if available to match the validation environment.
Standard LaTeX packages are supplied by TeX Live/Overleaf. All project-specific
files are included. No BibTeX/Biber step, .bib file, external font, external
image download, or shell escape is needed.

For a local TeX installation, run twice from the project directory:
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex

The three figures are cropped vector artwork from the supplied manuscript.
Edit text, equations, and tables in main.tex; edit reference entries in
references.tex. Keep the figure filenames or update the corresponding
includegraphics commands when replacing them.

The included compiled PDF is named differently from main.pdf to avoid
conflicts with Overleaf's generated output. Check the page count after edits
or a change of TeX Live version. The PDF is prepared for review; it has not
been submitted to the conference or certified by IEEE PDF eXpress.

IEEEtran.cls retains its original copyright and LPPL licensing notices.

OVERLEAF HELP
https://docs.overleaf.com/getting-started/your-first-project
https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document
https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project
